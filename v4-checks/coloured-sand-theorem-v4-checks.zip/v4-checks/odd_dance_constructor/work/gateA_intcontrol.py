# Integrality control for Gate A: lattices that must NOT be Dist-stable (Grepy el Bailarin, PASO 1).
import sys; sys.path.insert(0,'work')
import explore_psi as X
from fractions import Fraction as Fr
from math import factorial
tot=fail=0
for p in (3,5):
    u=Fr(-1)
    for b in range(0,3):
        for r in range(1,p):
            for name,eps in (('eps=p',Fr(p)),('eps=p^2',Fr(p*p))):
                wts,F=X.Model(X.Delta(b),p,u,r,eps); tot+=1
                try:
                    E=X.recover_E(wts,F); v=X.min_val_divided_powers(E,p,max(wts)+2)[0]
                    ok = v>=0
                except ValueError: ok=False; v='no sl2'
                if not ok: fail+=1
                print('p',p,'b',b,'r',r,name,'min v_p E^(r):',v,flush=True)
        # wrap without p in Phi
        wts,F=X.Phi(X.Delta(b),p,u); n=len(wts); m=b+1
        for a in range(m):
            for k in range(n): F[k][(p-1)*m+a]/=p
        tot+=1
        try:
            E=X.recover_E(wts,F); v=X.min_val_divided_powers(E,p,max(wts)+2)[0]; vf=X.min_val_divided_powers(F,p,max(wts)+2)[0]
            ok = v>=0 and vf>=0
        except ValueError: ok=False; v=vf='no sl2'
        if not ok: fail+=1
        print('p',p,'b',b,'Phi without p: min v_p E^(r):',v,'F^(r):',vf,flush=True)
print('integrality control: lattices',tot,'non-Dist-stable',fail)
print('FIN-OK')
