# Gate B (Grepy el Bailarin, PASO 2): Theorem D_p. Moves (twist/split/last level) vs direct p-adic Smith form on L(lambda).
import sys, time; sys.path.insert(0,'work')
from oddlat import *
from collections import Counter

def matmul(A,B):
    n=len(A); m=len(B[0]); k=len(B)
    return [[sum(A[i][t]*B[t][j] for t in range(k)) for j in range(m)] for i in range(n)]
def prod(Ms):
    out=Ms[0]
    for M in Ms[1:]: out=matmul(out,M)
    return out

def moves(p,lam,i,e,control=None,cap=900):
    """Right side of Theorem D_p: returns (dict exponents>0, number of free summands), and M.
    control: None | 'nolast' (leading-digit level omitted) | 'p2' (twist payment divided by p^2)."""
    d,k,I=family(p,lam); u=-1
    P={}  # current payment function: floor -> R x R integer matrix (rows: generator slot, cols: relation slot)
    pay=lambda phi: [[p**e*(phi+i)]]
    R=1
    for t in range(k):
        r=d[t]; old=pay
        div = p*p if control=='p2' else p
        if r==0:
            def newpay(f,old=old,div=div):
                Q=prod([old(p*f+j) for j in range(p)])
                return [[(-1)**(p-1)*x//(div*u) if True else 0 for x in row] for row in Q]
        else:
            def newpay(f,old=old,r=r,R=R,div=div):
                QA=prod([old(p*f+j) for j in range(p)])
                QC=prod([old(p*f+r+j) for j in range(p)])
                K=prod([old(p*f+r+j) for j in range(p-r)])
                M=[[0]*(2*R) for _ in range(2*R)]
                for a in range(R):
                    for b in range(R):
                        M[a][b]=(-1)**(p-1)*QA[a][b]//(div*u)
                        M[R+a][R+b]=(-1)**(p-1)*QC[a][b]//(div*u)
                        M[R+a][b]=(-1)**(p-r)*K[a][b]//u
                return M
            R*=2
        cache={}
        def pay(f,newpay=newpay,cache=cache):
            if f not in cache: cache[f]=newpay(f)
            return cache[f]
    dk=d[k]
    if control=='nolast': Mfin=pay(0)
    else: Mfin=prod([pay(s) for s in range(dk)])
    out=Counter()
    for h in range(1,k): out[h]+=(p-1)*dk*p**(k-h-1)*2**len(I)
    if control!='nolast': out[k]+=(dk-1)*2**len(I)
    g,free=smith_p(Mfin,p,cap=cap)
    for x,c in g.items(): out[x+k]+=c
    zeros=len(Mfin)-sum(g.values())-free   # unit Smith entries of M give Z/p^k
    out[k]+=zeros
    return dict(sorted((a,c) for a,c in out.items() if c and a>0)), free

def direct(p,lam,i,e,cap=900):
    """Sparse p-adic Smith form of F + p^e(D+i) on L(lambda), modulo p^cap (independent of the moves)."""
    wts,F,E=L(p,lam); n=len(wts); P=p**cap
    cols={}; rows={}
    for c in range(n):
        d={}
        for k,v in F[c].items(): d[k]=d.get(k,0)+v
        d[c]=d.get(c,0)+p**e*((lam-wts[c])//2+i)
        d={k:v%P for k,v in d.items() if v%P}
        cols[c]=d
        for k,v in d.items(): rows.setdefault(k,{})[c]=v
    for r in range(n): rows.setdefault(r,{})
    ex=[]; alive_r=set(range(n)); alive_c=set(range(n))
    while alive_c:
        best=None
        for c in alive_c:
            col=cols[c]
            for r,v in col.items():
                val=vp(v,p)
                cost=(len(col)-1)*(len(rows[r])-1)
                key=(val,cost)
                if best is None or key<best[0]: best=(key,r,c)
            if best and best[0]==(0,0): break
        if best is None: ex+=['inf']*len(alive_c); break
        (val,_),r,c=best; ex.append(val)
        piv=cols[c][r]; uinv=pow(piv//p**val,-1,P)
        prow=dict(rows[r])   # row r entries: col -> value
        pcol=dict(cols[c])   # col c entries: row -> value
        # eliminate: for each row r2 in pcol (r2!=r): row_r2 -= (A[r2][c]/piv) * row_r
        for r2,a in pcol.items():
            if r2==r: continue
            f=(a//p**val)*uinv%P
            for c2,b in prow.items():
                if c2==c: continue
                nv=(rows[r2].get(c2,0)-f*b)%P
                if nv: rows[r2][c2]=nv; cols[c2][r2]=nv
                else:
                    rows[r2].pop(c2,None); cols[c2].pop(r2,None)
            rows[r2].pop(c,None)
        # remove row r and column c
        for c2 in prow: cols[c2].pop(r,None)
        for r2 in pcol: rows[r2].pop(c,None)
        del rows[r]; del cols[c]; alive_r.discard(r); alive_c.discard(c)
    hist=Counter(); free=0
    for x in ex:
        if x=='inf' or x>=cap-5: free+=1
        elif x>0: hist[x]+=1
    return dict(sorted(hist.items())), free

def in_proved_range(p,lam): return lam<=p*p+p-1

def seal(path):
    import subprocess
    lines=[]
    for p,lmax in ((3,80),(5,150)):
        for lam in range(p*p+p,lmax+1):
            for e in (1,2):
                for i in range(4):
                    a,fr=moves(p,lam,i,e)
                    lines.append('p=%d lam=%d e=%d i=%d : %s free=%d'%(p,lam,e,i,a,fr))
    return lines

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='seal':
        for ln in seal(None): print(ln)
        sys.exit(0)
    if mode=='run':
        p=int(sys.argv[2]); lo=int(sys.argv[3]); hi=int(sys.argv[4])
        sealed={}
        for ln in open('work/SEALED_1.txt'):
            if ln.startswith('p='): key,val=ln.split(' : '); sealed[key]=val.strip()
        tot=bad=hit=miss=0; cb={'nolast':0,'p2':0}; ctot=0
        for lam in range(lo,hi+1):
            for e in (1,2):
                for i in range(4):
                    b=direct(p,lam,i,e); a=moves(p,lam,i,e); tot+=1
                    if a!=b: bad+=1; print('THEOREM D_p FAIL',p,lam,e,i,'moves',a,'direct',b,flush=True)
                    key='p=%d lam=%d e=%d i=%d'%(p,lam,e,i)
                    if key in sealed:
                        if sealed[key]=='%s free=%d'%(b[0],b[1]): hit+=1
                        else: miss+=1; print('SEALED MISS',key,sealed[key],'direct',b,flush=True)
                    for ctl in ('nolast','p2'):
                        try: c=moves(p,lam,i,e,control=ctl)
                        except Exception as ex: c=('error',str(ex))
                        if c!=b: cb[ctl]+=1
                    ctot+=1
        print('run p',p,'lam in [%d,%d]'%(lo,hi),'cells',tot,'moves!=direct',bad,'sealed hits',hit,'misses',miss,'| controls (cells',ctot,') nolast differs',cb['nolast'],'p2 differs',cb['p2'],flush=True)
    if mode=='test':
        bad=tot=0
        for lam in range(0,12):
            for e in (1,2):
                for i in range(4):
                    a=moves(3,lam,i,e); b=direct(3,lam,i,e); tot+=1
                    if a!=b: bad+=1; print('DIFF',lam,e,i,a,b)
        print('test p=3 lambda<=11: cells',tot,'bad',bad,flush=True)
        lam=max(l for l in range(81) if dimT(3,l)==max(dimT(3,x) for x in range(81)))
        t0=time.time(); b=direct(3,lam,1,1); print('timing: lambda',lam,'dim',dimT(3,lam),'direct',round(time.time()-t0,1),'s',flush=True)
        t0=time.time(); a=moves(3,lam,1,1); print('timing: moves',round(time.time()-t0,2),'s; equal:',a==b,flush=True)
    print('FIN-OK')
