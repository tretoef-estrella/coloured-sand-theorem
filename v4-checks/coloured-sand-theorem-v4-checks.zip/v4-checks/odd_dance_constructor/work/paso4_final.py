# PASO 4(c) checks of the closed formula (Grepy el Bailarin). Only known/proved ranges.
import sys; sys.path.insert(0,'work'); sys.path.insert(0,'material/engines')
from collections import Counter
from math import comb
from paso4 import fit_rule
from gateA import expected_character
from oddlat import vp
import frontier_model2 as FM
import dst_alpha as DA

def mult_T(p,m):
    ch=Counter()
    for s in range(m+1): ch[m-2*s]+=comb(m,s)
    n={}
    for lam in range(m,-1,-2):
        c=ch.get(lam,0)
        if c<0: raise ValueError('negative multiplicity')
        if c:
            n[lam]=c
            for w,x in expected_character(p,lam).items(): ch[w]-=c*x
    if any(v for v in ch.values()): raise ValueError('character not exhausted')
    return n

def piece(p,m,c,e):
    tot=Counter(); free=0
    for lam,n in mult_T(p,m).items():
        ex,fr=fit_rule(p,lam,c+(m-lam)//2,e)
        for a,x in ex.items(): tot[a]+=n*x
        free+=n*fr
    return tot,free

def hamming(p,d,q):
    e=vp(q,p); tot=Counter(); free=0
    for j in range(d+1):
        mu=comb(d,j)*(q-2)**j
        if mu==0: continue
        g,fr=piece(p,d-j,j,e)
        for a,x in g.items(): tot[a]+=mu*x
        free+=mu*fr
    assert free==1, free
    return dict(sorted(tot.items()))

if __name__=='__main__':
    # (i) Theorem G
    tot=bad=0
    for p in (3,5,7,11):
        for lam in range(0,p*p+p):
            for e in (1,2,3):
                for i in range(5):
                    a,fr=fit_rule(p,lam,i,e); ex,free=FM.block_cf(p,lam,p**e,i,0)
                    b=dict(sorted(Counter(x for x in ex if x>0).items())); tot+=1
                    if a!=b or fr!=free: bad+=1
    print('closed formula vs Theorem G (block_cf): cells',tot,'bad',bad,flush=True)
    # (ii) p=2 vs DST
    tot=bad=0
    for lam in range(0,201):
        for al in (1,2,3,4):
            for i in range(7):
                a,fr=fit_rule(2,lam,i,al); g,fr2=DA.X_alpha(lam,i,al)
                b=dict(sorted((x,c) for x,c in g.items() if c and x>0)); tot+=1
                if a!=b or fr!=fr2: bad+=1
    print('closed formula at p=2 vs DST closed rule: cells',tot,'bad',bad,flush=True)
    # (iii) v3 §10 table, q=p=3
    table={5:(12,10,16,53,5),6:(38,37,36,117,24,16,6),7:(86,105,127,285,85,63,41),8:(250,211,286,1078,174,133,174,8),
           9:(942,412,624,3339,449,292,495,133,84,37,9),10:(3314,1388,1768,7310,1690,1364,1388,1392,316,190,74),
           11:(11035,4345,5127,11339,10099,4994,4432,7162,704,419,416)}
    bad=0
    for d,row in table.items():
        g=hamming(3,d,3); mx=max(g); ours=tuple(g.get(v,0) for v in range(1,mx+1))
        if ours!=row: bad+=1; print('TABLE DIFF d',d,ours,row,flush=True)
    print('assembled Syl_3 K(H(d,3)) vs v3 §10 table, d=5..11: rows',len(table),'bad',bad,flush=True)
    # (iv) Theorem B (p > d)
    def ballot(k,v): return v*comb(v+2*k,k)//(v+2*k)
    tot=bad=0
    for p in (5,7,11,13):
        for d in range(1,p):
            for q in (p,2*p,3*p,p*p):
                e=vp(q,p); pred=Counter()
                for v in range(1,d+1):
                    nv=sum(comb(d,j)*(q-2)**j*ballot(kk,v) for j in range(d+1) for kk in range(d+1) if j+2*kk==d+1-v and (j,kk)!=(0,0))
                    if nv: pred[e*v]+=nv
                g=hamming(p,d,q); tot+=1
                if g!=dict(sorted(pred.items())): bad+=1
    print('assembled Syl_p K(H(d,q)) vs Theorem B (p>d): cells',tot,'bad',bad,flush=True)
    print('Syl_3 K(H(12,3)) by the closed formula:',hamming(3,12,3),flush=True)
    print('FIN-OK')
