# Sanity checks of oddlat.py (Grepy el Bailarin, PASO 1).
import sys; sys.path.insert(0,'work')
from oddlat import *
import explore_psi as X
from fractions import Fraction as Fr
tot=bad=0
for p in (3,5,7):
    for lam in range(0, 400):
        if dimT(p,lam)>200: continue
        Lt=L(p,lam); tot+=1
        b=check_sl2(Lt)
        if b: bad+=1; print('SL2 FAIL',p,lam,b)
print('sl2 relations: lattices',tot,'bad',bad,flush=True)
# E formula vs recovered
tot=bad=0
for p in (3,5,7):
    for lam in range(0,200):
        if dimT(p,lam)>60: continue
        wts,F,E=L(p,lam); n=len(wts)
        Fd=[[Fr(F[c].get(r,0)) for c in range(n)] for r in range(n)]
        Er=X.recover_E(wts,Fd); tot+=1
        ok=all(Er[r][c]==E[c].get(r,0) for r in range(n) for c in range(n))
        if not ok: bad+=1; print('E MISMATCH',p,lam)
print('E formula = E recovered from (F,H): lattices',tot,'bad',bad,flush=True)
# lambda=12 table, p=3
tab={0:({1:8,7:1,10:1,12:1},1),1:({1:8,9:2,13:2},0),2:({1:8,9:2,13:2},0),3:({1:8,8:1,10:1,12:1,14:1},0)}
for c in range(4):
    g=Y(3,12,c,1); print('lambda=12 p=3 e=1 i=%d:'%c,g,'table',tab[c],'OK' if g==tab[c] else 'DIFF',flush=True)
for c in (1,2):
    print('lambda=12 p=3 e=2 i=%d:'%c,Y(3,12,c,2),flush=True)
print('FIN-OK')
