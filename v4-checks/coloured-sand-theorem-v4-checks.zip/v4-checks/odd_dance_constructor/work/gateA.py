# Gate A (Grepy el Bailarin, PASO 1). Run: python3 work/gateA.py struct P [lo hi]  |  python3 work/gateA.py compare
import sys; sys.path.insert(0,'work'); sys.path.insert(0,'material/engines')
from oddlat import *
from collections import Counter
def expected_character(p,lam):
    d,k,I=family(p,lam)
    ch=Counter({0:1})
    def mul(ch,poly):
        out=Counter()
        for a,x in ch.items():
            for b,y in poly.items(): out[a+b]+=x*y
        return out
    for t in range(k):
        pt=p**t
        ch=mul(ch,Counter({(p-1-2*j)*pt:1 for j in range(p)}))
        if d[t]: ch=mul(ch,Counter({d[t]*pt:1,-d[t]*pt:1}))
    pk=p**k
    ch=mul(ch,Counter({(d[k]-1-2*j)*pk:1 for j in range(d[k])}))
    return Counter({a:x for a,x in ch.items() if x})
def struct(p,lo,hi):
    tot=bad_rel=bad_ch=bad_F=bad_E=0; worstF=worstE=10**9
    for lam in range(lo,hi):
        if dimT(p,lam)>600: continue
        Lt=L(p,lam); wts,F,E=Lt; tot+=1
        if check_sl2(Lt): bad_rel+=1; print('REL FAIL',p,lam,flush=True)
        if Counter(wts)!=expected_character(p,lam): bad_ch+=1; print('CHAR FAIL',p,lam,flush=True)
        if len(wts)!=dimT(p,lam): bad_ch+=1; print('DIM FAIL',p,lam,flush=True)
        vF=divided_power_integrality(F,p,lam+1)[0]; vE=divided_power_integrality(E,p,lam+1)[0]
        worstF=min(worstF,vF); worstE=min(worstE,vE)
        if vF<0: bad_F+=1; print('F NONINTEGRAL',p,lam,flush=True)
        if vE<0: bad_E+=1; print('E NONINTEGRAL',p,lam,flush=True)
    print('struct p',p,'lambda in [%d,%d)'%(lo,hi),'lattices',tot,'sl2-bad',bad_rel,'char-bad',bad_ch,'F^(r)-bad',bad_F,'E^(r)-bad',bad_E,'min v_p F^(r)',worstF,'min v_p E^(r)',worstE,flush=True)
def Lbad(p,lam,mode):
    # control lattices: the outermost move altered. mode 'nop': wrap without p ; mode 'eps0': Psi without coupling
    n1=lam+1
    if n1<p: return Delta(lam)
    d0=n1%p; b=n1//p-1; N=L(p,b)
    if mode=='eps0':
        return Psi(d0,N,p,eps=0) if d0 else Phi(N,p)
    # 'nop': rebuild with the wrap coefficient p*u replaced by u (F only matters for Y)
    wts,F,E=(Phi(N,p) if d0==0 else Psi(d0,N,p))
    m=len(N[0]); F2=[]
    for c,col in enumerate(F):
        d={}
        for k,v in col.items():
            # wrap entries are exactly those landing on position j=0 of a string from position j=p-1 with factor p*u
            d[k]=v
        F2.append(d)
    # identify wrap columns: basis index layout of Phi/Psi: strings of length p, blocks of size m
    if d0==0:
        for a in range(m):
            col=F2[(p-1)*m+a]
            for k in list(col): col[k]//=p
    else:
        for a in range(m):
            for base in (0,p*m):
                col=F2[base+(p-1)*m+a]
                for k in list(col):
                    if base==0 and k==p*m+(p-d0)*m+a: continue   # keep the coupling p*C_{p-r}
                    col[k]//=p
    return wts,F2,E
def compare():
    import frontier_model2 as FM
    tot=bad=0
    for p in (3,5,7):
        for lam in range(0,p*p+p):
            Lt=L(p,lam)
            for e in (1,2,3):
                for i in range(0,5):
                    g,fr=Y(p,lam,i,e,Lt); ex,free=FM.block_cf(p,lam,p**e,i,0)
                    exd=dict(Counter(x for x in ex if x>0)); tot+=1
                    if not (g==dict(sorted(exd.items())) and fr==free):
                        bad+=1; print('CMP FAIL',p,lam,e,i,g,fr,exd,free,flush=True)
    print('Y_p(L(lambda)) vs block_cf (Theorem G): cells',tot,'bad',bad,flush=True)
    tab={0:({1:8,7:1,10:1,12:1},1),1:({1:8,9:2,13:2},0),2:({1:8,9:2,13:2},0),3:({1:8,8:1,10:1,12:1,14:1},0)}
    tb=0
    for c in range(4):
        g=Y(3,12,c,1)
        if g!=tab[c]: tb+=1
        print('table 2.4 c=%d:'%c,g,'expected',tab[c],flush=True)
    print('table 2.4 cells 4 bad',tb,flush=True)
    for mode in ('nop','eps0'):
        tot=bad=0
        for p in (3,5,7):
            for lam in range(p-1,p*p+p):
                Lt=Lbad(p,lam,mode)
                for e in (1,2,3):
                    for i in range(0,5):
                        g,fr=Y(p,lam,i,e,Lt); ex,free=FM.block_cf(p,lam,p**e,i,0)
                        exd=dict(sorted(Counter(x for x in ex if x>0).items())); tot+=1
                        if not (g==exd and fr==free): bad+=1
        print('CONTROL',mode,'cells',tot,'bad',bad,flush=True)
if __name__=='__main__':
    if sys.argv[1]=='struct':
        p=int(sys.argv[2]); lo=int(sys.argv[3]) if len(sys.argv)>3 else 0; hi=int(sys.argv[4]) if len(sys.argv)>4 else 3000
        struct(p,lo,hi)
    else: compare()
    print('FIN-OK')
