# Print the E-action of the eps=1 model M_r(Delta(b)) in its model basis (Grepy el Bailarin, PASO 1).
import sys; sys.path.insert(0,'work')
from explore_psi import *
p=int(sys.argv[1]); r=int(sys.argv[2]); b=int(sys.argv[3])
u=Fr(factorial(p-1))
wts,F=Model(Delta(b),p,u,r,Fr(1)); E=recover_E(wts,F); m=b+1
name=lambda i: ('A' if i<p*m else 'C')+'%d n%d'%((i%(p*m))//m,(i%(p*m))%m)
for i in range(len(wts)):
    terms=[(name(k),E[k][i]) for k in range(len(wts)) if E[k][i]]
    print('E',name(i),'=',' + '.join('%s*%s'%(c,nm) for nm,c in terms))
print('FIN-OK')
