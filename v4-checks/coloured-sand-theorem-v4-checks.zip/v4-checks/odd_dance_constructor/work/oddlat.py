# oddlat.py — explicit Z_p-lattices for the tilting modules of SL_2 (Grepy el Bailarin, PASO 1).
# A lattice is (wts, F, E): wts[i] = weight of basis vector i; F, E sparse: list of dicts {row: int} (column i = image of e_i).
# Constructions (u = -1, a unit congruent to -1 mod p):
#   Delta(lam); Phi(N) (digit 0: lattice form of St (x) N^[1]); Psi(r, N), 1<=r<=p-1 (digit r: lattice form of T(p-1+r) (x) N^[1]).
#   L(p, lam): the dance lattice built from the base-p digits of lam+1, ending on Delta(d_k - 1).
from math import factorial
U = -1

def vp(x, p):
    if x == 0: return 10**9
    v = 0
    while x % p == 0: x //= p; v += 1
    return v

def add(d, k, v):
    if v:
        d[k] = d.get(k, 0) + v
        if d[k] == 0: del d[k]

def Delta(lam):
    n = lam + 1
    wts = [lam - 2*s for s in range(n)]
    F = [({s+1: s+1} if s < lam else {}) for s in range(n)]
    E = [({s-1: lam - s + 1} if s > 0 else {}) for s in range(n)]
    return wts, F, E

def compose(A, B):
    # (A B) column i = A applied to column i of B
    out = []
    for col in B:
        d = {}
        for k, v in col.items():
            for k2, v2 in A[k].items(): add(d, k2, v*v2)
        out.append(d)
    return out

def Phi(N, p, u=U):
    wN, FN, EN = N; m = len(wN); XN = compose(FN, EN)
    idx = lambda j, a: j*m + a
    n = p*m; wts = [0]*n; F = [None]*n; E = [None]*n
    for j in range(p):
        for a in range(m):
            i = idx(j, a); w = wN[a]
            wts[i] = p*w + p - 1 - 2*j
            d = {}
            if j < p-1: d[idx(j+1, a)] = 1
            else:
                for c, v in FN[a].items(): add(d, idx(0, c), p*u*v)
            F[i] = d
            d = {}
            if j >= 1:
                for c, v in XN[a].items(): add(d, idx(j-1, c), p*p*v)
                add(d, idx(j-1, a), j*(p*w + p - j))
            else:
                # (p/u) b_{p-1} E n ; u = +-1 so p/u = p*u
                for c, v in EN[a].items(): add(d, idx(p-1, c), p*u*v)
            E[i] = d
    return wts, F, E

def Psi(r, N, p, u=U, eps=1):
    # eps = coupling F(A_{p-1}n) = pu A_0 Fn + p*eps C_{p-r} n (eps=1 is the lattice; other eps only for controls, E then wrong)
    assert 1 <= r <= p-1 and u in (1, -1)
    wN, FN, EN = N; m = len(wN); XN = compose(FN, EN)
    A = lambda j, a: j*m + a
    C = lambda j, a: p*m + j*m + a
    pu_inv = p*u  # p/u for u = +-1
    n = 2*p*m; wts = [0]*n; F = [None]*n; E = [None]*n
    for j in range(p):
        for a in range(m):
            w = wN[a]
            iA, iC = A(j, a), C(j, a)
            wts[iA] = p*w + p - 1 + r - 2*j
            wts[iC] = p*w + p - 1 - r - 2*j
            # F
            d = {}
            if j < p-1: d[A(j+1, a)] = 1
            else:
                for c, v in FN[a].items(): add(d, A(0, c), p*u*v)
                add(d, C(p-r, a), p*eps)
            F[iA] = d
            d = {}
            if j < p-1: d[C(j+1, a)] = 1
            else:
                for c, v in FN[a].items(): add(d, C(0, c), p*u*v)
            F[iC] = d
            # E on A_j n
            d = {}
            if j == 0:
                for c, v in EN[a].items():
                    add(d, A(p-1, c), pu_inv*v); add(d, C(p-1-r, c), -(p-r)*pu_inv*v)
            else:
                for c, v in XN[a].items(): add(d, A(j-1, c), p*p*v)
                add(d, A(j-1, a), j*(p*w + p + r - j))
                if j <= r:
                    for c, v in EN[a].items(): add(d, C(p+j-1-r, c), r*pu_inv*v)
                else:
                    for c, v in XN[a].items(): add(d, C(j-1-r, c), r*p*p*v)
            E[iA] = d
            # E on C_j n
            d = {}
            if j == 0:
                add(d, A(r-1, a), r)
                for c, v in EN[a].items(): add(d, C(p-1, c), pu_inv*v)
            else:
                for c, v in XN[a].items(): add(d, C(j-1, c), p*p*v)
                if j <= p-r:
                    add(d, C(j-1, a), j*(p*w + p - r - j)); add(d, A(j+r-1, a), r)
                else:
                    add(d, C(j-1, a), j*(p*w + p - r - j) + r*p)
                    for c, v in FN[a].items(): add(d, A(j+r-1-p, c), r*p*u*v)
            E[iC] = d
    return wts, F, E

def digits(n, p):
    d = []
    while n: d.append(n % p); n //= p
    return d

def L(p, lam, u=U):
    n1 = lam + 1
    if n1 < p: return Delta(lam)
    d0 = n1 % p; b = n1 // p - 1
    N = L(p, b, u)
    return Phi(N, p, u) if d0 == 0 else Psi(d0, N, p, u)

def family(p, lam):
    d = digits(lam + 1, p); k = len(d) - 1
    I = [t for t in range(k) if d[t]]
    return d, k, I

def dimT(p, lam):
    d, k, I = family(p, lam); return d[k] * p**k * 2**len(I)

def check_sl2(Lat):
    wts, F, E = Lat; n = len(wts); bad = 0
    for i in range(n):
        # [E,F] e_i = H e_i
        d = {}
        for k, v in F[i].items():
            for k2, v2 in E[k].items(): add(d, k2, v*v2)
        for k, v in E[i].items():
            for k2, v2 in F[k].items(): add(d, k2, -v*v2)
        add(d, i, -wts[i])
        if d: bad += 1
        for k in F[i]:
            if wts[k] != wts[i] - 2: bad += 1
        for k in E[i]:
            if wts[k] != wts[i] + 2: bad += 1
    return bad

def divided_power_integrality(X, p, rmax):
    # min over r>=1 and basis vectors of v_p(X^r e_i) - v_p(r!) ; X integral sparse
    n = len(X); worst = 10**9; where = None
    vf = [0]*(rmax+2)
    for r in range(1, rmax+2): vf[r] = vf[r-1] + vp(r, p)
    for i in range(n):
        col = {i: 1}
        for r in range(1, rmax+1):
            new = {}
            for k, v in col.items():
                for k2, v2 in X[k].items(): add(new, k2, v*v2)
            col = new
            if not col: break
            for k, v in col.items():
                s = vp(v, p) - vf[r]
                if s < worst: worst, where = s, (r, i, k)
    return worst, where

def relation_matrix(Lat, p, e, i, lam):
    # G = F + p^e (D + i), D = floor (lam - w)/2 ; returns dense integer matrix (rows = coordinates, cols = images)
    wts, F, E = Lat; n = len(wts)
    M = [[0]*n for _ in range(n)]
    for c in range(n):
        for k, v in F[c].items(): M[k][c] += v
        M[c][c] += p**e * ((lam - wts[c])//2 + i)
    return M

def smith_p(M, p, cap=400):
    # exact p-adic Smith form modulo p^cap; returns (Counter-like dict of exponents >0, number of 'inf' (zero) divisors)
    P = p**cap; n = len(M); A = [[x % P for x in r] for r in M]
    rows = list(range(n)); cols = list(range(n)); ex = []
    while rows:
        best = None
        for r in rows:
            Ar = A[r]
            for c in cols:
                x = Ar[c]
                if x:
                    v = vp(x, p)
                    if best is None or v < best[0]:
                        best = (v, r, c)
                        if v == 0: break
            if best and best[0] == 0: break
        if best is None: ex += ['inf']*len(rows); break
        v, r, c = best; ex.append(v)
        uinv = pow(A[r][c] // p**v, -1, P)
        Ar = A[r]
        for r2 in rows:
            if r2 != r and A[r2][c]:
                f = (A[r2][c] // p**v) * uinv % P
                A2 = A[r2]
                for j in cols:
                    if Ar[j]: A2[j] = (A2[j] - f*Ar[j]) % P
        rows.remove(r); cols.remove(c)
    hist = {}
    free = 0
    for x in ex:
        if x == 'inf': free += 1
        elif x >= cap - 5: free += 1   # beyond precision: reported as 'inf' (caller must keep cap large)
        elif x > 0: hist[x] = hist.get(x, 0) + 1
    return dict(sorted(hist.items())), free

def Y(p, lam, i, e, Lat=None):
    if Lat is None: Lat = L(p, lam)
    return smith_p(relation_matrix(Lat, p, e, i, lam), p)
