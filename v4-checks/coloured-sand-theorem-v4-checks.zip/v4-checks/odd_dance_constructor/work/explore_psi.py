# Exploration (Grepy el Bailarin, PASO 1). Exact rationals.
# A "graded F-lattice" is (weights, F) with F a dense matrix in a Z_p-basis (columns = images).
# E is recovered over Q from F and H (unique on a finite-dim sl2-module) via primitive vectors.
# Then integrality of E^(r), F^(r) in the given basis is tested (Dist-stability of the lattice).
from fractions import Fraction as Fr
from math import factorial, comb
import sys

def vp(x, p):
    x = Fr(x)
    if x == 0: return 10**9
    n, d, v = x.numerator, x.denominator, 0
    while n % p == 0: n //= p; v += 1
    while d % p == 0: d //= p; v -= 1
    return v

def zeros(n, m): return [[Fr(0)]*m for _ in range(n)]
def matmul(A, B):
    n, k, m = len(A), len(B), len(B[0]) if B else 0
    C = zeros(n, m)
    for i in range(n):
        Ai = A[i]; Ci = C[i]
        for t in range(k):
            a = Ai[t]
            if a:
                Bt = B[t]
                for j in range(m):
                    if Bt[j]: Ci[j] += a*Bt[j]
    return C
def matvec(A, v): return [sum((A[i][j]*v[j] for j in range(len(v)) if v[j]), Fr(0)) for i in range(len(A))]

def kernel(M, ncols):
    # kernel of M (rows x ncols) over Q, returns list of vectors
    A = [r[:] for r in M]; piv = []; r = 0
    for c in range(ncols):
        pr = next((i for i in range(r, len(A)) if A[i][c] != 0), None)
        if pr is None: continue
        A[r], A[pr] = A[pr], A[r]
        inv = 1/A[r][c]; A[r] = [x*inv for x in A[r]]
        for i in range(len(A)):
            if i != r and A[i][c] != 0:
                f = A[i][c]; A[i] = [a - f*b for a, b in zip(A[i], A[r])]
        piv.append(c); r += 1
        if r == len(A): break
    free = [c for c in range(ncols) if c not in piv]; out = []
    for fc in free:
        v = [Fr(0)]*ncols; v[fc] = Fr(1)
        for i, pc in enumerate(piv): v[pc] = -A[i][fc]
        out.append(v)
    return out

def inverse(M):
    n = len(M); A = [M[i][:] + [Fr(int(i == j)) for j in range(n)] for i in range(n)]
    for c in range(n):
        pr = next((i for i in range(c, n) if A[i][c] != 0), None)
        if pr is None: raise ValueError('singular')
        A[c], A[pr] = A[pr], A[c]
        inv = 1/A[c][c]; A[c] = [x*inv for x in A[c]]
        for i in range(n):
            if i != c and A[i][c] != 0:
                f = A[i][c]; A[i] = [a - f*b for a, b in zip(A[i], A[c])]
    return [r[n:] for r in A]

def recover_E(wts, F):
    n = len(wts); cols = []; images = []
    for w in sorted(set(wts), reverse=True):
        if w < 0: break
        idx = [i for i in range(n) if wts[i] == w]
        # F^{w+1} restricted to V_w
        vecs = []
        for i in idx:
            v = [Fr(0)]*n; v[i] = Fr(1)
            for _ in range(w+1): v = matvec(F, v)
            vecs.append(v)
        M = [[vecs[c][r] for c in range(len(idx))] for r in range(n)]
        for kv in kernel(M, len(idx)):
            v = [Fr(0)]*n
            for c, i in enumerate(idx): v[i] = kv[c]
            chain = [v]
            for k in range(w): chain.append(matvec(F, chain[-1]))
            base = len(cols)
            for k in range(w+1):
                cols.append(chain[k])
                images.append((base+k-1, k*(w-k+1)) if k >= 1 else None)
    if len(cols) != n: raise ValueError('Lefschetz fails: %d vs %d' % (len(cols), n))
    B = [[cols[c][r] for c in range(n)] for r in range(n)]
    Bi = inverse(B)
    Ead = zeros(n, n)
    for c, im in enumerate(images):
        if im: Ead[im[0]][c] = Fr(im[1])
    return matmul(matmul(B, Ead), Bi)

def min_val_divided_powers(X, p, rmax):
    n = len(X); P = [[Fr(int(i == j)) for j in range(n)] for i in range(n)]; worst = 10**9; where = None
    for r in range(1, rmax+1):
        P = matmul(X, P)
        if all(all(x == 0 for x in row) for row in P): break
        fr = factorial(r)
        for i in range(n):
            for j in range(n):
                if P[i][j]:
                    v = vp(P[i][j]/fr, p)
                    if v < worst: worst, where = v, (r, i, j)
    return worst, where

# ---------- models ----------
def Delta(b):
    n = b+1; F = zeros(n, n)
    for s in range(b): F[s+1][s] = Fr(s+1)
    return [b-2*s for s in range(n)], F

def Phi(N, p, u):
    wN, FN = N; m = len(wN); n = p*m
    idx = lambda j, a: j*m + a
    wts = [0]*n; F = zeros(n, n)
    for j in range(p):
        for a in range(m):
            wts[idx(j, a)] = p*wN[a] + p - 1 - 2*j
            if j < p-1: F[idx(j+1, a)][idx(j, a)] = Fr(1)
            else:
                for c in range(m):
                    if FN[c][a]: F[idx(0, c)][idx(j, a)] += p*u*FN[c][a]
    return wts, F

def Model(N, p, u, r, eps):
    # A_j n (weights pw+p-1+r-2j), C_j n (pw+p-1-r-2j)
    wN, FN = N; m = len(wN); n = 2*p*m
    A = lambda j, a: j*m + a
    C = lambda j, a: p*m + j*m + a
    wts = [0]*n; F = zeros(n, n)
    for j in range(p):
        for a in range(m):
            wts[A(j, a)] = p*wN[a] + p - 1 + r - 2*j
            wts[C(j, a)] = p*wN[a] + p - 1 - r - 2*j
            if j < p-1:
                F[A(j+1, a)][A(j, a)] = Fr(1); F[C(j+1, a)][C(j, a)] = Fr(1)
            else:
                for c in range(m):
                    if FN[c][a]:
                        F[A(0, c)][A(j, a)] += p*u*FN[c][a]; F[C(0, c)][C(j, a)] += p*u*FN[c][a]
                F[C(p-r, a)][A(j, a)] += p*eps
    return wts, F

def check(name, L, p):
    wts, F = L
    try: E = recover_E(wts, F)
    except ValueError as ex:
        print(name, 'dim', len(wts), 'NO sl2 structure over Q:', ex, flush=True); return False
    vF = min_val_divided_powers(F, p, max(wts)+2)
    vE = min_val_divided_powers(E, p, max(wts)+2)
    print(name, 'dim', len(wts), 'min v_p F^(r):', vF[0], 'min v_p E^(r):', vE[0], vE[1] if vE[0] < 0 else '', flush=True)
    return vF[0] >= 0 and vE[0] >= 0

if __name__ == '__main__':
    for p in (3, 5):
        u = Fr(factorial(p-1))
        for b in range(0, 3):
            check('p%d Phi(Delta(%d))' % (p, b), Phi(Delta(b), p, u), p)
            for r in range(1, p):
                for eps in (1, 0):
                    check('p%d r%d eps%d Model(Delta(%d))' % (p, r, eps, b), Model(Delta(b), p, u, r, Fr(eps)), p)
    print('FIN-OK')
