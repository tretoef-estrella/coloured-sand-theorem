# PASO 4 (Grepy el Bailarin): closed form of M_p, deficit law, cost form, and the Smith form of M_p.
# Only cells already computed in Gate B (p=3 lam<=80, p=5 lam<=150, e in {1,2}, i<=3) or in the proved range are used here,
# unless a sealed file is given.
import sys; sys.path.insert(0,'work')
from fractions import Fraction as Fr
from collections import Counter
from oddlat import vp, family, smith_p
import gateB

def sp(n,p):
    s=0
    while n: s+=n%p; n//=p
    return s
def kap(a,b,p): return (sp(a,p)+sp(b,p)-sp(a+b,p))//(p-1)   # number of carries of a+b in base p (Kummer)

def qpoly(p,lam):
    """q_k^{d_k} as dict mask->int over the dancers (bit j <-> I[j]); q_0=1, q_{t+1}=q_t^p - [t in I] y_t q_t^{p-d_t}."""
    d,k,I=family(p,lam); pos={t:j for j,t in enumerate(I)}
    def mul(a,b):
        out={}
        for m1,c1 in a.items():
            for m2,c2 in b.items():
                if m1&m2: continue
                out[m1|m2]=out.get(m1|m2,0)+c1*c2
        return {m:c for m,c in out.items() if c}
    def pw(a,n):
        out={0:1}
        for _ in range(n): out=mul(out,a)
        return out
    q={0:1}
    for t in range(k):
        new=pw(q,p)
        if d[t]:
            y={1<<pos[t]:1}; term=mul(y,pw(q,p-d[t]))
            for m,c in term.items(): new[m]=new.get(m,0)-c
            new={m:c for m,c in new.items() if c}
        q=new
    return pw(q,d[k]),d,k,I

def closed_M(p,lam,i,e):
    """M_p from the windows theorem: M_{DD'} = (-1)^{d_k-1}/(d_k-1)! * [(c^(k))^{d_k}]_{D\\D'} * prod_{d=o_D}^{o_D'+d_k p^k-1} p^e(i+d)."""
    Q,d,k,I=qpoly(p,lam); u=-1
    a=Fr(-1,p)                       # (-1)^{p-1} u^{-1} p^{-1}, p odd, u=-1
    gam={t:Fr(-((-1)**d[t]))*Fr(-p)**(1+d[t]*(p**t-1)//(p-1)) for t in I}   # y_t / x_t
    R=1<<len(I); K=d[k]*p**k
    o=lambda mask: sum(d[I[j]]*p**I[j] for j in range(len(I)) if mask>>j&1)
    from math import factorial
    pref=Fr((-1)**(d[k]-1),factorial(d[k]-1))*a**(d[k]*(p**k-1)//(p-1))
    M=[[Fr(0)]*R for _ in range(R)]
    for D in range(R):
        for D2 in range(R):
            if D2 & ~D: continue
            Dl=D & ~D2
            c=Q.get(Dl,0)
            if c==0: continue
            g=Fr(1)
            for j in range(len(I)):
                if Dl>>j&1: g*=gam[I[j]]
            w=1
            for dd in range(o(D),o(D2)+K): w*=p**e*(i+dd)
            M[D][D2]=pref*c*g*w
    return M

def recursion_M(p,lam,i,e):
    # the moves' Mfin (without the unit (-1)^{d_k-1}/(d_k-1)!), in gateB's slot order (bit j <-> j-th split <-> I[j])
    d,k,I=family(p,lam); u=-1
    pay=lambda phi: [[p**e*(phi+i)]]; R=1
    for t in range(k):
        r=d[t]; old=pay
        if r==0:
            def newpay(f,old=old):
                Q=gateB.prod([old(p*f+j) for j in range(p)]); return [[(-1)**(p-1)*x//(p*u) for x in row] for row in Q]
        else:
            def newpay(f,old=old,r=r,R=R):
                QA=gateB.prod([old(p*f+j) for j in range(p)]); QC=gateB.prod([old(p*f+r+j) for j in range(p)]); K=gateB.prod([old(p*f+r+j) for j in range(p-r)])
                M=[[0]*(2*R) for _ in range(2*R)]
                for a_ in range(R):
                    for b_ in range(R):
                        M[a_][b_]=(-1)**(p-1)*QA[a_][b_]//(p*u); M[R+a_][R+b_]=(-1)**(p-1)*QC[a_][b_]//(p*u); M[R+a_][b_]=(-1)**(p-r)*K[a_][b_]//u
                return M
            R*=2
        cache={}
        def pay(f,newpay=newpay,cache=cache):
            if f not in cache: cache[f]=newpay(f)
            return cache[f]
    from math import factorial
    Mf=gateB.prod([pay(s) for s in range(d[k])])
    return [[Fr((-1)**(d[k]-1),factorial(d[k]-1))*x for x in row] for row in Mf]

def cost(p,lam,i,e,D,D2):
    """Predicted v_p(M_{DD'}) by the cost form (i>=1): eK + kap(m,K) + R_m(D) - R_{m+K}(D') + gamma(D\\D')."""
    d,k,I=family(p,lam); K=d[k]*p**k; m=i-1
    nxt={}
    for j,t in enumerate(I): nxt[t]=I[j+1] if j+1<len(I) else k
    h={t:nxt[t]-t for t in I}
    setof=lambda mask:[I[j] for j in range(len(I)) if mask>>j&1]
    o=lambda E: sum(d[t]*p**t for t in E)
    Rr=lambda mu,E: sum(h[t]-e*d[t]*p**t for t in E)-kap(mu,o(E),p)
    Dl=setof(D & ~D2)
    g=0 if not Dl else sum(h[u] for u in I if u not in Dl and u>min(Dl))
    return e*K+kap(m,K,p)+Rr(m,setof(D))-Rr(m+K,setof(D2))+g

def deficit_check(p,lam):
    Q,d,k,I=qpoly(p,lam); bad=0
    for mask,c in Q.items():
        if mask==0:
            if c!=1: bad+=1
            continue
        Dl=[I[j] for j in range(len(I)) if mask>>j&1]
        if vp(c,p)!=k-len(Dl)-min(Dl): bad+=1
    # every nonempty subset must have a nonzero coefficient
    if len(Q)!=1<<len(I): bad+=1
    return bad

def frvp(x,p):
    x=Fr(x)
    if x==0: return 10**9
    return vp(x.numerator,p)-vp(x.denominator,p)

def int_fit(xs):
    blocks=[]
    for x in xs:
        blocks.append([x,1])
        while len(blocks)>=2 and blocks[-2][0]*blocks[-1][1] <= blocks[-1][0]*blocks[-2][1]:
            s_,c_=blocks.pop(); blocks[-1][0]+=s_; blocks[-1][1]+=c_
    out=[]
    for S,n in blocks:
        q,r=divmod(S,n); out+=[q+1]*r+[q]*(n-r)
    return out

def rulers(p,lam,e):
    d,k,I=family(p,lam); K=d[k]*p**k
    nxt={}
    for j,t in enumerate(I): nxt[t]=I[j+1] if j+1<len(I) else k
    h={t:nxt[t]-t for t in I}
    o=lambda E: sum(d[t]*p**t for t in E)
    R=lambda mu,E: sum(h[t]-e*d[t]*p**t for t in E)-kap(mu,o(E),p)
    Rs=lambda E: sum(h[t]-e*d[t]*p**t for t in E)-((k-min(E)) if E else 0)
    return d,k,I,K,R,Rs

def fit_rule(p,lam,i,e):
    # conjectured big summands of Y_p(lam,i,e): k + eK + kap(i-1,K) + intfit(x_D) (i>=1); i=0: free + k + eK + intfit(x#_D), D != empty
    d,k,I,K,R,Rs=rulers(p,lam,e)
    dancers=[[I[j] for j in range(len(I)) if mask>>j&1] for mask in range(1<<len(I))]   # o-order = mask order
    comp=lambda D:[t for t in I if t not in D]
    out=Counter()
    for h_ in range(1,k): out[h_]+=(p-1)*d[k]*p**(k-h_-1)*2**len(I)
    out[k]+=(d[k]-1)*2**len(I)
    if i>=1:
        m=i-1; xs=[R(m,D)-R(m+K,comp(D)) for D in dancers]
        for y in int_fit(xs): out[k+e*K+kap(m,K,p)+y]+=1
        free=0
    else:
        xs=[Rs(D)-Rs(comp(D)) for D in dancers[1:]]
        for y in int_fit(xs): out[k+e*K+y]+=1
        free=1
    return dict(sorted((a,c) for a,c in out.items() if c and a>0)),free

def seal2_cells():
    cells=[]
    for lam in range(81,401):
        for e in (1,3):
            for i in (0,1,4,10): cells.append((3,lam,e,i))
    for lam in range(151,701):
        for e in (1,2):
            for i in (0,3,7): cells.append((5,lam,e,i))
    for lam in range(56,601):
        for e in (1,3):
            for i in (0,2,5): cells.append((7,lam,e,i))
    for lam in range(132,1500,7):
        for e in (1,2):
            for i in (0,1,13): cells.append((11,lam,e,i))
    for lam in range(182,2400,11):
        for i in (0,4): cells.append((13,lam,1,i))
    return cells

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='check2':
        P=int(sys.argv[2]); hit=miss=0; worst=[]
        lo=int(sys.argv[3]) if len(sys.argv)>3 else 0; hi=int(sys.argv[4]) if len(sys.argv)>4 else 10**9
        for ln in open('work/SEALED_2.txt'):
            if not ln.startswith('p=%d '%P): continue
            key,val=ln.split(' : '); f=dict(x.split('=') for x in key.split())
            p,lam,e,i=int(f['p']),int(f['lam']),int(f['e']),int(f['i'])
            if not (lo<=lam<=hi): continue
            a,fr=gateB.moves(p,lam,i,e,cap=2*e*(lam+1)+200)
            if '%s free=%d'%(a,fr)==val.strip(): hit+=1
            else: miss+=1; print('SEALED_2 MISS',key,'sealed',val.strip(),'Theorem D_p',a,fr,flush=True)
        print('SEALED_2 p=%d lam in [%d,%d]: hits %d misses %d'%(P,lo,min(hi,10**6),hit,miss),flush=True)
        sys.exit(0)
    if mode=='direct2':
        from oddlat import dimT
        want=set()
        for lam in range(81,401,9): want.add((3,lam))
        for lam in range(151,701,23): want.add((5,lam))
        for lam in range(56,601,31): want.add((7,lam))
        hit=miss=0; n=0
        for ln in open('work/SEALED_2.txt'):
            if not ln.startswith('p='): continue
            key,val=ln.split(' : '); f=dict(x.split('=') for x in key.split())
            p,lam,e,i=int(f['p']),int(f['lam']),int(f['e']),int(f['i'])
            if (p,lam) not in want or dimT(p,lam)>1300: continue
            b=gateB.direct(p,lam,i,e,cap=2*e*(lam+1)+200); n+=1
            if '%s free=%d'%(b[0],b[1])==val.strip(): hit+=1
            else: miss+=1; print('DIRECT vs SEALED_2 MISS',key,val.strip(),b,flush=True)
        print('direct sparse Smith on L(lambda) vs SEALED_2 (sample, dim<=1300): cells',n,'hits',hit,'misses',miss,flush=True)
        sys.exit(0)
    if mode=='seal2':
        for (p,lam,e,i) in seal2_cells():
            a,fr=fit_rule(p,lam,i,e)
            print('p=%d lam=%d e=%d i=%d : %s free=%d'%(p,lam,e,i,a,fr))
        sys.exit(0)
    if mode=='fit':
        res=Counter(); fails=[]
        for p,lmax in ((3,80),(5,150),(7,55)):
            for lam in range(0,lmax+1):
                d,k,I=family(p,lam)
                for e in (1,2):
                    for i in range(4):
                        a=gateB.moves(p,lam,i,e); b=fit_rule(p,lam,i,e)
                        key=(p,len(I))
                        res[key,'tot']+=1
                        if a!=b: res[key,'bad']+=1; fails.append((p,lam,e,i,a,b))
        for key in sorted(set(k_ for k_,_ in res)):
            print('fit rule p=%d |I|=%d: cells %d, fit != Theorem D_p: %d'%(key[0],key[1],res[key,'tot'],res[key,'bad']),flush=True)
        for f in fails[:40]: print('FAIL',f,flush=True)
    if mode=='windows':
        tot=bad=0; dtot=dbad=0; ctot=cbad=0
        cells=[(3,l) for l in range(0,81)]+[(5,l) for l in range(0,151)]+[(7,l) for l in range(0,56)]
        for p,lam in cells:
            dtot+=1; dbad+=deficit_check(p,lam)
            for e in (1,2):
                for i in range(4):
                    A=closed_M(p,lam,i,e); B=recursion_M(p,lam,i,e); tot+=1
                    if A!=B: bad+=1; print('WINDOWS FAIL',p,lam,e,i,flush=True)
                    if i>=1:
                        R=len(A)
                        for D in range(R):
                            for D2 in range(R):
                                if D2 & ~D: continue
                                ctot+=1
                                if frvp(A[D][D2],p)!=cost(p,lam,i,e,D,D2): cbad+=1
        print('windows theorem: cells',tot,'closed form != recursion',bad,flush=True)
        print('deficit law v_p(a_k(Delta)) = k-|Delta|-min(Delta): families',dtot,'bad',dbad,flush=True)
        print('cost form (i>=1): entries',ctot,'bad',cbad,flush=True)
    print('FIN-OK')
