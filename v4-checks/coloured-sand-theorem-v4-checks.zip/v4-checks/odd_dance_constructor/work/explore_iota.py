# Equivariant maps iota: Model_r(N) -> V (x) Model_{r-1}(N) (r>=2) or V (x) Phi(N) (r=1); N = Delta(b).
import sys; sys.path.insert(0,'work')
from explore_psi import *
def VTensor(L):
    w,F=L; m=len(w); n=2*m
    wts=[0]*n; G=zeros(n,n)
    for e in range(2):
        for a in range(m):
            i=e*m+a; wts[i]=w[a]+(1 if e==0 else -1)
            # F(b0 x)=b1 x + b0 Fx ; F(b1 x)= b1 Fx
            for c in range(m):
                if F[c][a]: G[e*m+c][i]+=F[c][a]
            if e==0: G[m+a][i]+=1
    return wts,G
def equivariant_maps(X,Z):
    wx,FX=X; wz,FZ=Z; nx,nz=len(wx),len(wz)
    unk=[(i,j) for i in range(nz) for j in range(nx) if wz[i]==wx[j]]
    pos={u:k for k,u in enumerate(unk)}
    rows=[]
    # (iota FX - FZ iota)[i][j] = sum_k iota[i][k] FX[k][j] - sum_k FZ[i][k] iota[k][j]
    for i in range(nz):
        for j in range(nx):
            if wz[i]!=wx[j]-2: continue
            row=[Fr(0)]*len(unk)
            for k in range(nx):
                if FX[k][j] and (i,k) in pos: row[pos[(i,k)]]+=FX[k][j]
            for k in range(nz):
                if FZ[i][k] and (k,j) in pos: row[pos[(k,j)]]-=FZ[i][k]
            if any(row): rows.append(row)
    ker=kernel(rows,len(unk))
    out=[]
    for v in ker:
        M=zeros(nz,nx)
        for (i,j),k in pos.items(): M[i][j]=v[k]
        out.append(M)
    return out
if __name__=='__main__':
    p=int(sys.argv[1]); r=int(sys.argv[2]); b=int(sys.argv[3]); u=Fr(factorial(p-1))
    N=Delta(b); X=Model(N,p,u,r,Fr(1))
    Y=Model(N,p,u,r-1,Fr(1)) if r>=2 else Phi(N,p,u)
    Z=VTensor(Y); maps=equivariant_maps(X,Z); m=b+1
    print('dim Hom =',len(maps))
    nmX=lambda i: ('A' if i<p*m else 'C')+'%d.n%d'%((i%(p*m))//m,(i%(p*m))%m)
    my=len(Y[0])
    def nmZ(i):
        e=i//my; k=i%my
        if r>=2: return 'b%d(x)%s'%(e,('A' if k<p*m else 'C')+'%d.n%d'%((k%(p*m))//m,(k%(p*m))%m))
        return 'b%d(x)b%d.n%d'%(e,k//m,k%m)
    for t,M in enumerate(maps):
        print('--- map',t)
        for j in range(len(X[0])):
            if j%m==0 or True:
                if (j%(p*m))//m!=0: continue
                terms=[(nmZ(i),M[i][j]) for i in range(len(Z[0])) if M[i][j]]
                print(nmX(j),'->',' + '.join('%s*%s'%(c,nm) for nm,c in terms))
    print('FIN-OK')
