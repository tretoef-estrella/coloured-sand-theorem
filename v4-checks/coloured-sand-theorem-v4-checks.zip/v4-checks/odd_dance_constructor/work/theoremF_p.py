# Numerical check of the odd-p version of DST Theorem 7.8 (Theorem F) and Lemmas 7.7, 7.9 (Grepy el Bailarin, PASO 4).
# House H = (I, k, ell, e, d): I subset of [0,k), digits d[t] in [1,p-1] for t in I, 0 <= ell < p^k.
import sys, itertools
from fractions import Fraction as Fr
def sp(n,p):
    s=0
    while n: s+=n%p; n//=p
    return s
def kap(a,b,p): return (sp(a,p)+sp(b,p)-sp(a+b,p))//(p-1)
def digit(n,t,p): return (n//p**t)%p
def run_p1(n,t,p,maxlen):
    c=0
    while c<maxlen and digit(n,t+c,p)==p-1: c+=1
    return c
def pav(xs):
    blocks=[]
    for x in xs:
        blocks.append([Fr(x),1])
        while len(blocks)>=2 and blocks[-2][0]*blocks[-1][1] <= blocks[-1][0]*blocks[-2][1]:
            s_,c_=blocks.pop(); blocks[-1][0]+=s_; blocks[-1][1]+=c_
    out=[]
    for S,n in blocks: out+=[S/n]*n
    return out
class House:
    def __init__(s,p,I,k,ell,e,d):
        s.p,s.I,s.k,s.ell,s.e,s.d=p,list(I),k,ell,e,d
        s.N=1<<len(s.I)
        nxt={}
        for j,t in enumerate(s.I): nxt[t]=s.I[j+1] if j+1<len(s.I) else k
        s.h={t:nxt[t]-t for t in s.I}
    def setof(s,mask): return [s.I[j] for j in range(len(s.I)) if mask>>j&1]
    def o(s,mask): return sum(s.d[t]*s.p**t for t in s.setof(mask))
    def R(s,mask): return sum(s.h[t]-s.e*s.d[t]*s.p**t for t in s.setof(mask))-kap(s.ell,s.o(mask),s.p)
    def J(s,mask): return 1 if s.ell+s.o(mask)>=s.p**s.k else 0
    def gam(s,mask):
        D=s.setof(mask)
        if not D: return 0
        return sum(s.h[u] for u in s.I if u not in D and u>min(D))
    def x(s,mask): return s.R(mask)-s.R((s.N-1)^mask)
    def chat(s,a,b): return s.R(a)-s.R(b)+s.gam(a&~b)
bad=Counter=None
from collections import Counter
stats=Counter()
def theoremF(H):
    """Returns V (dict mask->int) built as in the proof; asserts every intermediate claim; returns (V, yhat, J)."""
    p,I,k,ell,e,d=H.p,H.I,H.k,H.ell,H.e,H.d
    N=H.N
    xs=[H.x(m) for m in range(N)]
    fit=pav(xs)
    if any(z.denominator!=1 for z in fit): stats['fit not integral']+=1
    yhat=[int(z) for z in fit] if all(z.denominator==1 for z in fit) else None
    J=[H.J(m) for m in range(N)]
    if not I:
        return {0:0},[0],J
    c=max(I); Ip=[t for t in I if t!=c]; Hp=House(p,Ip,c,ell%p**c,e,d)
    Vp,yp,Jp=theoremF(Hp)
    Np=Hp.N; cbit=1<<(len(I)-1)   # c is the last (largest) digit -> top bit
    hc=k-c; lc=digit(ell,c,p); theta=p-lc
    kappa=1+min(run_p1(ell,c+1,p,hc-1),hc-1); sat=1 if kappa==hc else 0
    if theta==1: T='OR'
    elif theta<=d[c]: T='DIG'
    elif theta==d[c]+1: T='AND'
    else: T='NEV'
    stats['type '+T]+=1
    tau=hc-e*d[c]*p**c-(kappa if T in ('OR','DIG') else 0)
    # Lemma 7.7_p
    for D0 in range(Np):
        okR1 = H.R(D0)==Hp.R(D0)-(kappa*Jp[D0] if T=='OR' else 0)
        okR2 = H.R(D0|cbit)==tau+Hp.R(D0)-(kappa*Jp[D0] if T=='AND' else 0)
        okJ1 = J[D0]==((sat*Jp[D0]) if T=='OR' else 0)
        okJ2 = J[D0|cbit]==sat*((1 if T in ('OR','DIG') else 0)+(Jp[D0] if T=='AND' else 0))
        if not (okR1 and okR2 and okJ1 and okJ2): stats['Lemma 7.7_p FAIL']+=1
    # walk: X1 = yp + d1
    d1=[-tau-(kappa*Jp[D0] if T=='OR' else 0)+(kappa*Jp[(Np-1)^D0] if T=='AND' else 0) for D0 in range(Np)]
    X1=[yp[D0]+d1[D0] for D0 in range(Np)]
    X2=[-X1[(Np-1)^D0] for D0 in range(Np)]
    cand=[max(v,0) for v in X1]+[min(v,0) for v in X2]
    if yhat is None or cand!=yhat: stats['gluing (yhat = [max(X1,0),min(X2,0)]) FAIL']+=1
    # (Lambda_p)
    oI=H.o(N-1)
    if yhat and max(abs(v) for v in yhat)>e*oI: stats['Lambda_p FAIL']+=1
    # (Cut): first dancer b with J=1 is a strict cut of fit(x)
    bs=[m for m in range(N) if J[m]]
    if bs:
        b=bs[0]
        if b==0: stats['J(empty)=1 ??']+=1
        else:
            left=pav(xs[:b]); right=pav(xs[b:])
            if left+right!=fit or not fit[b-1]>fit[b]: stats['Cut FAIL']+=1
    # potential
    vq={}
    for D0 in range(Np):
        vq[D0]=Vp[D0]-(kappa*Jp[D0] if T=='OR' else 0)
        vq[D0|cbit]=tau+Vp[D0]-(kappa*Jp[D0] if T=='AND' else 0)
    if X1[Np-1]>0:
        V=dict(vq)
    else:
        F1=[D0 for D0 in range(Np) if X1[D0]<=0]
        if F1!=list(range(F1[0],Np)): stats['F1 not final segment']+=1
        f=F1[0]; F=set(F1)|{(N-1)^D0 for D0 in F1}
        c3=vq[f]; c4=vq[(N-1)^f]
        lo=c3; hi=c4
        if f>0:
            pr=f-1; ps=(N-1)^pr
            lo=max(lo,vq[ps]); hi=min(hi,vq[pr])
        if lo>hi: stats['empty interval for c_F']+=1
        cF=lo
        V={m:(cF if m in F else vq[m]) for m in range(N)}
    # checks (E),(M),(G)
    for D in range(N):
        if yhat is None or V[D]-V[(N-1)^D]!=yhat[D]: stats['(E) FAIL']+=1; break
    for D in range(N-1):
        if V[D]<V[D+1]: stats['(M) FAIL']+=1; break
    for a in range(N):
        for b in range(N):
            if b!=a and (b & ~a)==0 and V[a]-V[b]>H.chat(a,b): stats['(G) FAIL']+=1
    return V,yhat,J
def houses(p,kmax,sample=None):
    import random
    rnd=random.Random(12345)
    for k in range(0,kmax+1):
        for r in range(0,k+1):
            for I in itertools.combinations(range(k),r):
                digs=list(itertools.product(range(1,p),repeat=len(I)))
                if sample and len(digs)>sample: digs=rnd.sample(digs,sample)
                ells=range(p**k)
                if sample and p**k>sample*4: ells=rnd.sample(list(ells),sample*4)
                for dg in digs:
                    d=dict(zip(I,dg))
                    for ell in ells:
                        for e in (1,2):
                            yield House(p,I,k,ell,e,d)
if __name__=='__main__':
    tot=0
    for p,kmax,sample in ((3,4,None),(5,3,None),(7,3,12)):
        n0=tot
        for H in houses(p,kmax,sample):
            theoremF(H); tot+=1
        print('p',p,'houses',tot-n0,flush=True)
    print('houses checked',tot)
    for key,v in sorted(stats.items()): print(' ',key,v)
    fails=sum(v for key,v in stats.items() if not key.startswith('type'))
    print('total failures',fails)
    print('FIN-OK')
