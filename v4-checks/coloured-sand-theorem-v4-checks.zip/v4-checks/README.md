# The Coloured Sand Theorem, version 4 — record of the checks of Theorems I and J

- `odd_dance_constructor/`: the report that found and proved Theorems I and J (Theorem D_p, the lattices, the moves, the Smith form), with every script, log and sealed prediction file (`work/SEALED_1.txt`, md5 0a9c3442e54c54c8cc880d9b2bc070b0; `work/SEALED_2.txt`, md5 2f931de9eb3933c51a4ff3efb03274ab); and the auditor's grading.
- `odd_dance_independent_reading/`: the cold reading of that report by a separate reader with no access to the audit, verdict «holds with corrections»; `checks/THEOREM_F_ODD_P.md` is the floor of the Smith form for odd p written out line by line; its engines, logs and sealed predictions (`checks/K3_PREDICTIONS.txt`); and the auditor's grading.
- `v3_cold_reading/`: the cold reading of version 3, whose corrections are listed in §13 of the paper, and the auditor's grading.

All readers are instances of the AI system Claude (Anthropic). Third-party papers downloaded during the readings are not included. The code and logs of versions 1–3 are in `coloured-sand-theorem-code-and-logs.zip` and at https://github.com/tretoef-estrella/coloured-sand-theorem.
