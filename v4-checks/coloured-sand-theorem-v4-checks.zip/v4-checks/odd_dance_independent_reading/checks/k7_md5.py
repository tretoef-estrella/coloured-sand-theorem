# K7: md5 of the sealed files against the values printed in material/REPORT_ODD_DANCE.md; cell counts per prime.
import hashlib, re, collections
rep = open('material/REPORT_ODD_DANCE.md', encoding='utf-8').read()
claimed = {'SEALED_1.txt': '0a9c3442e54c54c8cc880d9b2bc070b0', 'SEALED_2.txt': '2f931de9eb3933c51a4ff3efb03274ab'}
for f, h in claimed.items():
    d = open('material/' + f, 'rb').read()
    m = hashlib.md5(d).hexdigest()
    print(f, 'md5', m, 'claimed', h, 'printed-in-report', rep.count(h), 'MATCH' if m == h else 'MISMATCH')
    lines = d.decode('utf-8').splitlines()
    print('  header:', lines[0][:120])
    cells = [l for l in lines if l.startswith('p=')]
    cnt = collections.Counter(int(re.match(r'p=(\d+)', l).group(1)) for l in cells)
    print('  cells', len(cells), dict(sorted(cnt.items())))
    keys = [l.split(':')[0].strip() for l in cells]
    print('  duplicate cell keys', len(keys) - len(set(keys)))
