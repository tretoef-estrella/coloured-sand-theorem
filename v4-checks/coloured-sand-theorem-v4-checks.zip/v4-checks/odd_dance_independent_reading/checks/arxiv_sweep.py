# arxiv_sweep.py — run a list of arXiv API queries (3.5 s apart), save the raw XML and a readable list per
# query in checks/lit/, and print a summary (total hits, titles).  Data only; nothing is executed.
import sys, re, time, subprocess, urllib.parse, json
qs = json.load(open(sys.argv[1]))
tag = sys.argv[2]
out = []
for n, q in enumerate(qs, 1):
    url = 'https://export.arxiv.org/api/query?' + urllib.parse.urlencode({'search_query': q, 'max_results': 200})
    path = f'lit/{tag}_{n:02d}.xml'
    r = subprocess.run(['curl', '-sS', '-m', '90', '-L', url, '-o', path, '-w', '%{http_code}'], capture_output=True, text=True)
    s = open(path, encoding='utf-8', errors='replace').read()
    tot = re.search(r'<opensearch:totalResults[^>]*>(\d+)', s)
    tot = tot.group(1) if tot else 'ERR'
    items = []
    for e in re.findall(r'<entry>(.*?)</entry>', s, re.S):
        t = ' '.join(re.search(r'<title>(.*?)</title>', e, re.S).group(1).split())
        i = re.search(r'<id>(.*?)</id>', e).group(1).split('/abs/')[-1]
        au = re.findall(r'<name>(.*?)</name>', e)
        d = re.search(r'<published>(.*?)</published>', e).group(1)[:10]
        items.append(f'{i} | {d} | {"; ".join(au[:4])}{" et al." if len(au) > 4 else ""} | {t}')
    open(f'lit/{tag}_{n:02d}.txt', 'w').write(f'query: {q}\ntotal: {tot}\n' + '\n'.join(items) + '\n')
    print(f'[{tag}_{n:02d}] http {r.stdout} total {tot} :: {q}')
    for it in items[:60]:
        print('    ' + it[:200])
    sys.stdout.flush()
    time.sleep(3.5)
