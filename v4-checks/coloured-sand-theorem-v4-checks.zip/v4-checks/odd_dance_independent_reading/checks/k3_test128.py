import subprocess, sys
from collections import Counter
from k3 import predicted, fmt, direct
def run128(p, M, m, c, q):
    out = subprocess.run(['./psmith128', str(p), str(M), str(m), str(c), str(q)], capture_output=True, text=True)
    ex = Counter(); ge = None; tm = None
    for l in out.stdout.splitlines():
        a, b = l.split()
        if a == 'ge_M': ge = int(b)
        elif a == 'time': tm = float(b)
        else: ex[int(a)] += int(b)
    return +Counter({a: k for a, k in ex.items() if a >= 1}), ge, tm
bad = 0; n = 0
for m in (5, 8, 9, 10, 11):
    for (c, q) in ((0, 3), (1, 3), (2, 9), (5, 6), (1, 27), (4, 54), (7, 3), (1, 81)):
        d128, ge, tm = run128(3, 79, m, c, q)
        pr = predicted(m, c, q, 3)
        ok = (d128 == pr) and ge == (1 if c == 0 else 0)
        n += 1; bad += (not ok)
        print(f'm={m} c={c} q={q}: psmith128 {fmt(d128)} ge_M={ge} t={tm}s | formula {"==" if d128 == pr else "!="}')
        sys.stdout.flush()
print(f'test128: {n} cells, {bad} disagreements')
