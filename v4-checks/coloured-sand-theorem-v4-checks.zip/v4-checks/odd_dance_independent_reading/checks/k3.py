# k3.py — K3: direct Smith forms of q(c+H)+U on B_m (checks/psmith, never through L(lam)) against the
# report's closed formula (Theorem TOTAL, checks/k4_formula.py), predictions written BEFORE computing.
import sys, subprocess, time, re, hashlib
from collections import Counter
from k4_formula import Y_total, Y_theoremG, n_lambda, vp

PSMITH = './psmith'


def predicted(m, c, q, p, Yfun=Y_total):
    e = vp(q, p)
    tot = Counter(); free = 0
    for lam, nl in n_lambda(m, p).items():
        G, fr = Yfun(lam, c + (m - lam) // 2, e, p)
        for a, k in G.items():
            tot[a] += k * nl
        free += fr * nl
    # Z_p^[c=0] + Syl_p X_q(m,c)  ->  remove the one free summand of c = 0
    assert free == (1 if c == 0 else 0), (m, c, q, p, free)
    return +tot


def run_psmith(p, M, m, c, q, inv_E=None):
    args = [PSMITH, str(p), str(M), str(m), str(c), str(q)] + (['inv', str(inv_E)] if inv_E is not None else [])
    out = subprocess.run(args, capture_output=True, text=True)
    if out.returncode != 0:
        raise RuntimeError(out.stderr)
    ex = Counter(); ge = None; tm = None
    for l in out.stdout.splitlines():
        a, b = l.split()
        if a == 'ge_M':
            ge = int(b)
        elif a == 'time':
            tm = float(b)
        else:
            ex[int(a)] += int(b)
    return ex, ge, tm


def exponent_bound(m, c, q, p):
    """E with p^E (q(c+H)+U)^{-1} integral: max over s,k of v_p(prod_{i=0}^k q(c+s+i)) - v_p(k!)."""
    E = 0
    for s in range(m + 1):
        for k in range(m - s + 1):
            v = sum(vp(q * (c + s + i), p) for i in range(k + 1)) - sum(vp(i, p) for i in range(1, k + 1))
            E = max(E, v)
    return E


def direct(m, c, q, p, M):
    """Syl_p X_q(m,c) directly; uses the inverse matrix when some exponent may be >= M."""
    if p != 2 and M > 39:
        global PSMITH
        old = PSMITH; PSMITH = './psmith128'
        try:
            ex, ge, tm = run_psmith(p, M, m, c, q)
        finally:
            PSMITH = old
        syl = Counter({a: k for a, k in ex.items() if a >= 1})
        if ge != (1 if c == 0 else 0):
            raise RuntimeError(f'exponents >= M={M} (ge_M={ge}) with the 128-bit engine')
        return +syl, f'psmith128 M={M} {tm}s ge_M={ge}'
    ex, ge, tm = run_psmith(p, M, m, c, q)
    syl = Counter({a: k for a, k in ex.items() if a >= 1})
    free_expected = 1 if c == 0 else 0
    info = f'normal run {tm}s ge_M={ge}'
    if ge == free_expected:
        return +syl, info
    if c == 0:
        raise RuntimeError(f'c = 0 with exponents >= M={M}: not handled ({info})')
    E = exponent_bound(m, c, q, p)
    if E >= 2 * M - 1:
        raise RuntimeError(f'E = {E} too large for M = {M}')
    exi, gei, tmi = run_psmith(p, M, m, c, q, inv_E=E)
    # exponents of p^E M^{-1} are E - a_i; a_i >= M come from b = E - a_i <= E - M < M
    big = Counter()
    for b, k in exi.items():
        if E - b >= M:
            big[E - b] += k
    # consistency on the overlap [E-M+1, M-1]: both runs see these exponents
    over_n = Counter({a: k for a, k in syl.items() if a >= E - M + 1})
    over_i = Counter({E - b: k for b, k in exi.items() if E - M + 1 <= E - b <= M - 1})
    if +over_n != +over_i:
        raise RuntimeError(f'overlap inconsistency {dict(over_n)} vs {dict(over_i)}')
    if sum(big.values()) != ge:
        raise RuntimeError(f'count of large exponents {sum(big.values())} != ge_M {ge}')
    syl.update(big)
    return +syl, info + f'; inverse run E={E} {tmi}s'


def fmt(G):
    return '{' + ', '.join(f'{a}: {k}' for a, k in sorted(G.items())) + '}'


def now():
    return subprocess.run(['date'], capture_output=True, text=True).stdout.strip()


if __name__ == '__main__':
    mode = sys.argv[1]
    t0 = time.time()
    if mode == 'validate':
        # proved range: p = 3, m <= 11 (Theorem G); p = 2, m <= 9 (DST / Theorem H): compare direct with
        # the closed formula AND with Theorem G (p = 3).
        bad = 0; n = 0
        for (p, M, m, c, q) in [(3, 39, m, c, q) for m in (5, 8, 9, 10, 11) for (c, q) in ((0, 3), (1, 3), (2, 9), (5, 6), (1, 27))] + \
                               [(2, 62, m, c, q) for m in (4, 6, 8, 9) for (c, q) in ((0, 2), (1, 4), (3, 8), (2, 12))]:
            d, info = direct(m, c, q, p, M)
            pr = predicted(m, c, q, p)
            ok = (d == pr)
            if p == 3:
                ok = ok and (predicted(m, c, q, p, Y_theoremG) == d)
            n += 1; bad += (not ok)
            print(f'p={p} m={m} c={c} q={q}: direct {fmt(d)} | formula {"==" if d == pr else "!="} | {info}')
            sys.stdout.flush()
        print(f'validate: {n} cells, {bad} disagreements')
    elif mode == 'validate_inv':
        # force the inverse path: small precision M = 20 (p = 3) or M = 24 (p = 2), proved range
        bad = 0; n = 0
        for (p, M, m, c, q) in [(3, 20, m, c, q) for m in (9, 10, 11) for (c, q) in ((1, 27), (2, 9), (4, 54), (7, 3))] + \
                               [(2, 24, m, c, q) for m in (8, 9) for (c, q) in ((3, 8), (1, 16))]:
            d, info = direct(m, c, q, p, M)
            pr = predicted(m, c, q, p)
            ok = (d == pr) and (p != 3 or predicted(m, c, q, p, Y_theoremG) == d)
            n += 1; bad += (not ok)
            print(f'p={p} M={M} m={m} c={c} q={q}: direct {fmt(d)} | formula {"==" if d == pr else "!="} | {info}')
            sys.stdout.flush()
        print(f'validate_inv: {n} cells, {bad} disagreements')
    elif mode == 'predict':
        out = sys.argv[2]
        cells = [tuple(int(x) for x in c.split(':')) for c in sys.argv[3:]]   # p:m:c:q
        lines = [f'K3 PREDICTIONS — Grepy el Jurado — written {now()}, before any direct computation of these cells.',
                 'Prediction = the report\'s closed formula (Theorem TOTAL, checks/k4_formula.py Y_total) assembled over '
                 'n_lam(m): Syl_p X_q(m,c) as {exponent: count}.']
        for (p, m, c, q) in cells:
            lines.append(f'p={p} m={m} c={c} q={q} : {fmt(predicted(m, c, q, p))}')
        txt = '\n'.join(lines) + '\n'
        open(out, 'w').write(txt)
        print(txt); print('md5', hashlib.md5(txt.encode()).hexdigest())
    elif mode == 'compute':
        path = sys.argv[2]; sel = sys.argv[3:]   # optional filters p:m:c:q
        pred = {}
        for l in open(path):
            mm = re.match(r'p=(\d+) m=(\d+) c=(\d+) q=(\d+) : \{(.*)\}', l)
            if mm:
                p, m, c, q = map(int, mm.groups()[:4])
                g = Counter()
                for kv in filter(None, mm.group(5).split(',')):
                    a, k = kv.split(':'); g[int(a)] += int(k)
                pred[(p, m, c, q)] = +g
        for key, g in pred.items():
            if sel and ':'.join(map(str, key)) not in sel:
                continue
            p, m, c, q = key
            import os
            M = int(os.environ.get('K3_M', 79 if p == 3 else 62))
            t = time.time()
            try:
                d, info = direct(m, c, q, p, M)
            except RuntimeError as ex:
                print(f'p={p} m={m} c={c} q={q}: ERROR {ex}'); sys.stdout.flush(); continue
            verdict = 'AGREES' if d == g else 'DISAGREES'
            print(f'p={p} m={m} c={c} q={q}: {verdict}; direct {fmt(d)}; predicted {fmt(g)}; {info}; wall {time.time()-t:.1f}s; {now()}')
            sys.stdout.flush()
    print(f'[{time.time() - t0:.1f}s]')
