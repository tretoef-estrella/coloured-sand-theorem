/* psmith.c — Grepy el Jurado, COLOURED_SAND_2, K3.
   Exact p-adic Smith form (over Z_(p)) of the operator  q(c+H)+U  on the Boolean lattice B_m
   (rows/columns = subsets of [m] as bitmasks; column S has q(c+|S|) at row S and 1 at rows S+{x}),
   or of  p^E * (q(c+H)+U)^{-1}  (closed form of [CS3] Lemma 4) for the large exponents.
   Arithmetic modulo N = p^M (N < 2^63), dense uint64 storage, level-by-level elimination:
   at level v all remaining entries are divisible by p^v and have been divided by p^v; unit pivots
   (Markowitz-like choice) are eliminated; when none is left the remaining block is divided by p.
   An exponent v is reliable iff v < M.  Remaining rows at level M are reported as ">=M" (this
   includes zero invariant factors, i.e. free summands).
   usage: psmith p M m c q [inv E]
   output: lines "exp count", then "ge_M count", and timing. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

typedef unsigned __int128 u128;
static uint64_t N, P;
static int MM;

static inline uint64_t mulmod(uint64_t a, uint64_t b) { return (uint64_t)(((u128)a * b) % N); }
static inline uint64_t submod(uint64_t a, uint64_t b) { return a >= b ? a - b : a + N - b; }
static uint64_t powmod(uint64_t a, uint64_t e) { uint64_t r = 1 % N; while (e) { if (e & 1) r = mulmod(r, a); a = mulmod(a, a); e >>= 1; } return r; }
/* inverse of a unit mod N = p^M: Newton iteration x <- x(2 - a x), starting from inverse mod p */
static uint64_t invmod(uint64_t a) {
    uint64_t ap = a % P, x = 1;
    /* inverse mod p by Fermat */
    { uint64_t r = 1, b = ap, e = P - 2; while (e) { if (e & 1) r = (r * b) % P; b = (b * b) % P; e >>= 1; } x = r; }
    for (int it = 0; it < 7; it++) { uint64_t t = mulmod(a, x); x = mulmod(x, submod(2 % N, t)); }
    return x;
}
static int vp_u(uint64_t x) { if (x == 0) return 1000; int v = 0; while (x % P == 0) { x /= P; v++; } return v; }
static uint64_t reduce_ll(long long x) { long long r = x % (long long)N; if (r < 0) r += (long long)N; return (uint64_t)r; }

int main(int argc, char **argv) {
    if (argc < 6) { fprintf(stderr, "usage: psmith p M m c q [inv E]\n"); return 1; }
    P = strtoull(argv[1], 0, 10); MM = atoi(argv[2]); int m = atoi(argv[3]); long long c = atoll(argv[4]); long long q = atoll(argv[5]);
    int inv = (argc >= 8 && strcmp(argv[6], "inv") == 0); int E = inv ? atoi(argv[7]) : 0;
    N = 1; for (int i = 0; i < MM; i++) { if (N > (uint64_t)9.2e18 / P) { fprintf(stderr, "p^M too large\n"); return 1; } N *= P; }
    int n = 1 << m;
    clock_t t0 = clock();
    uint64_t *a = calloc((size_t)n * n, sizeof(uint64_t));
    if (!a) { fprintf(stderr, "alloc failed\n"); return 1; }
    if (!inv) {
        for (int S = 0; S < n; S++) {
            int s = __builtin_popcount(S);
            a[(size_t)S * n + S] = reduce_ll(q * (c + s));
            for (int x = 0; x < m; x++) if (!(S >> x & 1)) a[(size_t)(S | 1 << x) * n + S] = 1;
        }
    } else {
        /* (M^{-1})_{T,S} = (-1)^k k! prod_{i=0}^{k} 1/(q(c+s+i)), S subset T, |T| = s + k.
           entry of p^E M^{-1}: p^{E - v} * unit, v = v_p(prod q(c+s+i)) - v_p(k!). */
        static uint64_t val[64][64]; static int ok[64][64];
        for (int s = 0; s <= m; s++) for (int k = 0; s + k <= m; k++) {
            int v = 0; uint64_t unit = 1;
            /* numerator (-1)^k k!, denominator prod q(c+s+i) */
            for (int i = 1; i <= k; i++) { long long x = i; while (x % (long long)P == 0) { x /= P; v--; } unit = mulmod(unit, reduce_ll(x)); }
            uint64_t den = 1;
            for (int i = 0; i <= k; i++) { long long x = q * (c + s + i); if (x == 0) { fprintf(stderr, "singular (c=0)\n"); return 1; } while (x % (long long)P == 0) { x /= P; v++; } den = mulmod(den, reduce_ll(x)); }
            if (k & 1) unit = submod(0, unit);
            unit = mulmod(unit, invmod(den));
            int ex = E - v; if (ex < 0) { fprintf(stderr, "E too small: s=%d k=%d needs %d\n", s, k, v); return 1; }
            val[s][k] = ex >= MM ? 0 : mulmod(unit, powmod(P, ex)); ok[s][k] = 1;
        }
        for (int T = 0; T < n; T++) for (int S = T; ; S = (S - 1) & T) {
            int s = __builtin_popcount(S), k = __builtin_popcount(T) - s;
            a[(size_t)T * n + S] = val[s][k];
            if (S == 0) break;
        }
    }
    char *rowact = malloc(n), *colact = malloc(n);
    memset(rowact, 1, n); memset(colact, 1, n);
    int *rowcnt = calloc(n, sizeof(int)), *colcnt = calloc(n, sizeof(int));
    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) if (a[(size_t)i * n + j]) { rowcnt[i]++; colcnt[j]++; }
    int *cnt = calloc(MM + 1, sizeof(int)); int remaining = n; int level = 0;
    int *nzc = malloc(sizeof(int) * n); int *order = malloc(sizeof(int) * n);
    long long npiv = 0;
    while (remaining > 0 && level < MM) {
        int found_any = 1;
        while (found_any && remaining > 0) {
            found_any = 0;
            /* order active columns by colcnt (counting sort) */
            int no = 0;
            for (int j = 0; j < n; j++) if (colact[j]) order[no++] = j;
            /* simple insertion by buckets */
            {
                int maxc = 0; for (int t = 0; t < no; t++) if (colcnt[order[t]] > maxc) maxc = colcnt[order[t]];
                int *b = calloc(maxc + 2, sizeof(int)); int *tmp = malloc(sizeof(int) * (no + 1));
                for (int t = 0; t < no; t++) b[colcnt[order[t]] + 1]++;
                for (int t = 1; t <= maxc + 1; t++) b[t] += b[t - 1];
                for (int t = 0; t < no; t++) tmp[b[colcnt[order[t]]]++] = order[t];
                memcpy(order, tmp, sizeof(int) * no); free(b); free(tmp);
            }
            for (int oi = 0; oi < no; oi++) {
                int j = order[oi]; if (!colact[j]) continue;
                int best = -1, bc = 1 << 30;
                for (int r = 0; r < n; r++) if (rowact[r]) { uint64_t x = a[(size_t)r * n + j]; if (x && x % P) { if (rowcnt[r] < bc) { bc = rowcnt[r]; best = r; } } }
                if (best < 0) continue;
                int i = best; found_any = 1; npiv++;
                uint64_t *ri = a + (size_t)i * n;
                uint64_t pinv = invmod(ri[j]);
                int nn = 0; for (int k = 0; k < n; k++) if (colact[k] && k != j && ri[k]) nzc[nn++] = k;
                for (int r = 0; r < n; r++) {
                    if (!rowact[r] || r == i) continue;
                    uint64_t *rr = a + (size_t)r * n;
                    if (!rr[j]) continue;
                    uint64_t f = mulmod(rr[j], pinv);
                    rr[j] = 0; rowcnt[r]--; colcnt[j]--;
                    for (int t = 0; t < nn; t++) {
                        int k = nzc[t]; uint64_t old = rr[k];
                        uint64_t nw = submod(old, mulmod(f, ri[k]));
                        rr[k] = nw;
                        if (!old && nw) { rowcnt[r]++; colcnt[k]++; }
                        else if (old && !nw) { rowcnt[r]--; colcnt[k]--; }
                    }
                }
                /* deactivate row i and column j */
                for (int k = 0; k < n; k++) if (colact[k] && ri[k]) colcnt[k]--;
                rowact[i] = 0; colact[j] = 0; remaining--; cnt[level]++;
            }
        }
        if (remaining == 0) break;
        /* divide the remaining block by p */
        level++;
        for (int r = 0; r < n; r++) if (rowact[r]) { uint64_t *rr = a + (size_t)r * n; for (int k = 0; k < n; k++) if (colact[k] && rr[k]) { uint64_t x = rr[k]; if (x % P) { fprintf(stderr, "BUG: non-divisible entry at level %d\n", level); return 2; } rr[k] = x / P; if (!rr[k]) { rowcnt[r]--; colcnt[k]--; } } }
        fprintf(stderr, "level %d reached, remaining %d, pivots so far %lld, %.1fs\n", level, remaining, npiv, (double)(clock() - t0) / CLOCKS_PER_SEC);
    }
    for (int v = 0; v < MM; v++) if (cnt[v]) printf("%d %d\n", v, cnt[v]);
    printf("ge_M %d\n", remaining);
    printf("time %.1f\n", (double)(clock() - t0) / CLOCKS_PER_SEC);
    return 0;
}
