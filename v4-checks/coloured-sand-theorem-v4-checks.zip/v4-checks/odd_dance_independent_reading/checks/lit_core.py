# lit_core.py — CORE API v3 (api.core.ac.uk, no key) with exact-phrase boolean queries.
import json, subprocess, sys, time, urllib.parse
qs = json.load(open(sys.argv[1])); tag = sys.argv[2]
for k, q in enumerate(qs, 1):
    url = 'https://api.core.ac.uk/v3/search/works/?' + urllib.parse.urlencode({'q': q, 'limit': 40})
    s = subprocess.run(['curl', '-sS', '-L', '-m', '60', url], capture_output=True, text=True).stdout
    open(f'lit/{tag}_{k:02d}_core.json', 'w').write(s)
    try:
        d = json.loads(s)
        print(f'[CORE] {q}: total {d.get("totalHits")}')
        for r in d.get('results', [])[:40]:
            print(f'     {r.get("yearPublished")} | {(r.get("title") or "")[:130]} | {r.get("doi") or ""} | {r.get("arxivId") or ""}')
    except Exception:
        print(f'[CORE] {q}: ERR {s[:200]}')
    sys.stdout.flush(); time.sleep(6)
