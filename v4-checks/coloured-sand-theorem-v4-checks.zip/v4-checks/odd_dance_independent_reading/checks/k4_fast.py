# k4_fast.py — faster route for large lam: M_p by the windows formula (Theorem 4.1, = moves entrywise in
# k4_windows.log), scaled to an integer matrix, exact p-adic Smith form modulo p^B (B > every finite exponent).
import sys, time, random
from fractions import Fraction
from math import lcm
from collections import Counter
from k4_mp import M_windows, M_moves, smith_padic
from k4_formula import Fam, Y_total, vp
from k4_run import group_from_M

INF = float('inf')

def smith_mod(Mint, p, B):
    """p-adic Smith exponents of an integer matrix, computed mod p^B; exponents >= B reported as INF."""
    N = p ** B
    A = [[x % N for x in row] for row in Mint]
    n = len(A); rows = list(range(n)); cols = list(range(n)); ex = []
    def v(x):
        if x == 0: return INF
        c = 0
        while x % p == 0: x //= p; c += 1
        return c
    while rows:
        best = None
        for r in rows:
            for c in cols:
                if A[r][c]:
                    vv = v(A[r][c])
                    if best is None or vv < best[0]:
                        best = (vv, r, c)
                        if vv == 0: break
            if best is not None and best[0] == 0: break
        if best is None:
            ex += [INF] * len(rows); break
        vv, r0, c0 = best
        ex.append(vv)
        u = A[r0][c0] // p ** vv
        uinv = pow(u, -1, N)
        for r in rows:
            if r != r0 and A[r][c0]:
                f = (A[r][c0] // p ** vv) * uinv % N   # exact: v(A[r][c0]) >= vv
                A[r] = [(A[r][c] - f * A[r0][c]) % N for c in range(n)]
        rows.remove(r0); cols.remove(c0)
    return sorted(ex)

def group_fast(lam, i, e, p):
    F = Fam(lam, p)
    M, Ds = M_windows(lam, i, e, p)
    den = 1
    for row in M:
        for x in row:
            if x: den = lcm(den, Fraction(x).denominator)
    s = vp(den, p)
    Mint = [[int(Fraction(x) * den) for x in row] for row in M]
    # B: larger than every finite exponent: sum of diagonal valuations (rows with nonzero diagonal)
    B = 1 + sum(vp(Mint[x][x], p) for x in range(len(Ds)) if Mint[x][x]) + 2
    ex = smith_mod(Mint, p, B)
    G = F.small(); free = 0
    for vv in ex:
        if vv == INF: free += 1
        else: G[F.k + vv - s] += 1
    return +G, free

def group_fast2(lam, i, e, p):
    """same as group_fast, but modulo p^B with B = 2*(largest diagonal valuation) + 20, certified by
    sum of exponents == v_p(det M) (M triangular, i >= 1); falls back to group_fast otherwise."""
    if i == 0:
        return group_fast(lam, i, e, p)
    F = Fam(lam, p)
    M, Ds = M_windows(lam, i, e, p)
    den = 1
    for row in M:
        for x in row:
            if x: den = lcm(den, Fraction(x).denominator)
    s = vp(den, p)
    Mint = [[int(Fraction(x) * den) for x in row] for row in M]
    diag = [vp(Mint[x][x], p) for x in range(len(Ds))]
    B = 2 * max(diag) + 20
    ex = smith_mod(Mint, p, B)
    if INF in ex or sum(ex) != sum(diag):
        return group_fast(lam, i, e, p)
    G = F.small()
    for vv in ex:
        G[F.k + vv - s] += 1
    return +G, 0

if __name__ == '__main__':
    mode = sys.argv[1]; t0 = time.time()
    if mode == 'crosscheck':   # fast route == moves route on a sample of large cells
        random.seed(7); bad = 0; n = 0
        cells = [(3, lam) for lam in range(242, 401)] + [(5, lam) for lam in range(125, 400)] + [(7, lam) for lam in range(49, 400)]
        for p, lam in random.sample(cells, int(sys.argv[2])):
            for e, i in ((1, 0), (2, 1), (3, 82)):
                n += 1
                if group_fast(lam, i, e, p) != group_from_M(lam, i, e, p, 'moves'):
                    bad += 1; print('DIFF', p, lam, e, i)
        print(f'fast(windows+mod Smith) vs moves+exact Smith: {n} cells, {bad} differences')
    elif mode == 'fit2':
        p = int(sys.argv[2]); lo = int(sys.argv[3]); hi = int(sys.argv[4])
        ES = [int(x) for x in sys.argv[5].split(',')]; IS = [int(x) for x in sys.argv[6].split(',')]
        n = 0; bad = 0
        for lam in range(lo, hi + 1):
            for e in ES:
                for i in IS:
                    n += 1
                    a, b = group_fast2(lam, i, e, p), Y_total(lam, i, e, p)
                    if a != b:
                        bad += 1
                        if bad <= 20: print('MISMATCH', p, lam, e, i)
            print(f'  progress lam={lam} cells={n} mismatches={bad} [{time.time()-t0:.0f}s]'); sys.stdout.flush()
        print(f'p={p} lam {lo}..{hi} e {ES} i {IS}: cells {n}, Smith(M_p)+small == closed formula in {n - bad}, mismatches {bad}')
    elif mode == 'fit':
        p = int(sys.argv[2]); lo = int(sys.argv[3]); hi = int(sys.argv[4])
        ES = [int(x) for x in sys.argv[5].split(',')]; IS = [int(x) for x in sys.argv[6].split(',')]
        n = 0; bad = 0
        for lam in range(lo, hi + 1):
            if lam % 10 == 0:
                print(f'  progress lam={lam} cells={n} mismatches={bad} [{time.time()-t0:.0f}s]'); sys.stdout.flush()
            for e in ES:
                for i in IS:
                    n += 1
                    a, b = group_fast(lam, i, e, p), Y_total(lam, i, e, p)
                    if a != b:
                        bad += 1
                        if bad <= 20: print('MISMATCH', p, lam, e, i, sorted(a[0].items()), a[1], sorted(b[0].items()), b[1])
        print(f'p={p} lam {lo}..{hi} e {ES} i {IS}: cells {n}, Smith(M_p)+small == closed formula in {n - bad}, mismatches {bad}')
    print(f'[{time.time() - t0:.1f}s]')
