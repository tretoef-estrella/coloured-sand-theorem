import time
from k4_run import group_from_M
from k4_formula import Y_total, Fam
for p, lam in ((3, 120), (3, 241), (3, 364), (3, 400), (5, 300), (7, 300)):
    F = Fam(lam, p)
    t = time.time(); G = group_from_M(lam, 243, 3, p); dt = time.time() - t
    print(p, lam, 'digits', F.d, '|I|', len(F.I), f'{dt:.2f}s', G == Y_total(lam, 243, 3, p))
