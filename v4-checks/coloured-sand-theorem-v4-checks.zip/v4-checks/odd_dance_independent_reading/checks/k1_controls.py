# k1_controls.py — K1 controls.  For the printed lattice and for deliberately wrong ones:
#  'p2'  : F(A_{p-1} n) = pu A_0(Fn) + p^2 C_{p-r} n   (coupling p -> p^2), printed E kept
#  '0'   : F(A_{p-1} n) = pu A_0(Fn)                    (no coupling), printed E kept
#  'nop' : twist without p: F(b_{p-1} n) = u b_0(Fn), E(b_0 n) = (1/u) b_{p-1}(En)
# For each: (i) sl2 relations with the printed E; (ii) E recovered from (F, H) alone over Q
# (Lemma 1.0: unique if it exists) and the p-integrality of all its divided powers.
import sys
from lat import L, dimT, digits
from k1 import check_relations, recover_E, frac_integrality, divided_power_integrality

DIMCAP = int(sys.argv[1]) if len(sys.argv) > 1 else 60
for p in (3, 5, 7):
    for lam in range(0, 400):
        if dimT(lam, p) > DIMCAP:
            continue
        d = digits(lam + 1, p); k = len(d) - 1
        has_split = any(d[t] for t in range(k))
        has_twist = any(d[t] == 0 for t in range(k))
        variants = [('printed', dict())]
        if has_split:
            variants += [('coupling p^2', dict(coupling='p2')), ('coupling 0', dict(coupling='0')),
                         ('coupling p^2 outer', dict(coupling='p2', outer_only=True)),
                         ('coupling 0 outer', dict(coupling='0', outer_only=True))]
        if has_twist:
            variants += [('twist without p', dict(wrap_p=False))]
        for name, kw in variants:
            if name.endswith('outer') and d[0] == 0:
                continue  # outermost move is a twist: the coupling control is vacuous there
            lat = L(lam, p, **kw)
            br = check_relations(lat)
            st, Er = recover_E(lat)
            info = ''
            if st == 'unique':
                mv = frac_integrality(lat[0], Er, p)
                same = all({k_: v for k_, v in Er[i].items()} == {k_: v for k_, v in lat[1][i].items()}
                           for i in range(len(lat[0])))
                info = f'min v_p(E_rec^(r)) = {mv}; E_rec == printed E: {same}'
            fint = divided_power_integrality(lat, p)['F'][0]
            print(f'p={p} lam={lam} dim={len(lat[0])} digits={d} [{name}]: printed-E relation failures {br}; '
                  f'min v_p(F^(r)) = {fint}; E from (F,H): {st} {info}')
            sys.stdout.flush()
