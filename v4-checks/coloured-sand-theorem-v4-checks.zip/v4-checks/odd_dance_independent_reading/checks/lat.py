# lat.py — Grepy el Jurado, COLOURED_SAND_2.  My own implementation of the lattices of
# material/REPORT_ODD_DANCE.md, Definitions 1.1 (Phi_p) and 1.3 (Psi_r), built EXACTLY as printed,
# with u = -1.  A lattice is stored as (wts, E, F): wts[i] = weight of basis vector i, and
# E, F = dict-of-columns sparse integer matrices: E[i] = {k: coeff} means E(v_i) = sum coeff * v_k.
# Exact Python integers throughout.  Options let the controls change the coupling of Psi_r.

from math import factorial

U = -1  # the unit u of the report


def delta(lam):
    """Weyl lattice Delta_A(lam): e_s = F^(s) v, F e_s = (s+1) e_{s+1}, E e_s = (lam-s+1) e_{s-1}."""
    n = lam + 1
    wts = [lam - 2 * s for s in range(n)]
    F = [dict() for _ in range(n)]
    E = [dict() for _ in range(n)]
    for s in range(n):
        if s + 1 < n:
            F[s][s + 1] = s + 1
        if s >= 1:
            E[s][s - 1] = lam - s + 1
    return wts, E, F


def apply(M, vec):
    """M (list of dict columns) applied to a sparse vector {i: c}."""
    out = {}
    for i, c in vec.items():
        for k, d in M[i].items():
            out[k] = out.get(k, 0) + c * d
    return {k: v for k, v in out.items() if v != 0}


def X_of(N):
    """X = F E on N, as list of dict columns."""
    wts, E, F = N
    return [apply(F, E[i]) for i in range(len(wts))]


def phi(N, p, wrap_p=True):
    """Definition 1.1.  Basis b_j n_i -> index j*n + i.  wrap_p=False is the control 'twist without p'."""
    wts, E, F = N
    n = len(wts)
    X = X_of(N)
    pu = p * U if wrap_p else U
    p_over_u = p // U if wrap_p else 1 // U  # p/u with u = -1 is -p
    W = [0] * (p * n)
    FF = [dict() for _ in range(p * n)]
    EE = [dict() for _ in range(p * n)]
    idx = lambda j, i: j * n + i
    for i in range(n):
        w = wts[i]
        for j in range(p):
            W[idx(j, i)] = p * w + p - 1 - 2 * j
            # F
            if j <= p - 2:
                FF[idx(j, i)] = {idx(j + 1, i): 1}
            else:
                FF[idx(j, i)] = {idx(0, k): pu * c for k, c in F[i].items()}
            # E
            if j >= 1:
                g = {k: p * p * c for k, c in X[i].items()}
                g[i] = g.get(i, 0) + j * (p * w + p - j)
                EE[idx(j, i)] = {idx(j - 1, k): c for k, c in g.items() if c != 0}
            else:
                EE[idx(j, i)] = {idx(p - 1, k): p_over_u * c for k, c in E[i].items()}
    return W, EE, FF


def psi(N, p, r, coupling='p'):
    """Definition 1.3 (split, digit r, 1 <= r <= p-1).  Basis A_j n_i -> j*n+i, C_j n_i -> (p+j)*n+i.
    coupling: 'p' (as printed), 'p2' (p^2 instead of p), '0' (no coupling) — the latter two are controls,
    which change ONLY the coupling term of F(A_{p-1} n) and keep the printed E."""
    wts, E, F = N
    n = len(wts)
    X = X_of(N)
    pu = p * U
    pou = p // U  # p/u = -p
    cpl = {'p': p, 'p2': p * p, '0': 0}[coupling]
    A = lambda j, i: j * n + i
    C = lambda j, i: (p + j) * n + i
    size = 2 * p * n
    W = [0] * size
    FF = [dict() for _ in range(size)]
    EE = [dict() for _ in range(size)]

    def add(d, k, c):
        if c != 0:
            d[k] = d.get(k, 0) + c
            if d[k] == 0:
                del d[k]

    for i in range(n):
        w = wts[i]
        En = E[i]
        Fn = F[i]
        Xn = X[i]
        for j in range(p):
            W[A(j, i)] = p * w + p - 1 + r - 2 * j
            W[C(j, i)] = p * w + p - 1 - r - 2 * j
            # F on A_j
            d = {}
            if j <= p - 2:
                add(d, A(j + 1, i), 1)
            else:
                for k, c in Fn.items():
                    add(d, A(0, k), pu * c)
                add(d, C(p - r, i), cpl)
            FF[A(j, i)] = d
            # F on C_j
            d = {}
            if j <= p - 2:
                add(d, C(j + 1, i), 1)
            else:
                for k, c in Fn.items():
                    add(d, C(0, k), pu * c)
            FF[C(j, i)] = d
            # g^A_j, g^C_j acting on n_i (as dicts)
            gA = {k: p * p * c for k, c in Xn.items()}
            gA[i] = gA.get(i, 0) + j * (p * w + p + r - j)
            gC = {k: p * p * c for k, c in Xn.items()}
            gC[i] = gC.get(i, 0) + j * (p * w + p - r - j)
            # E on A_j
            d = {}
            if j == 0:
                for k, c in En.items():
                    add(d, A(p - 1, k), pou * c)
                    add(d, C(p - 1 - r, k), -(p - r) * pou * c)
            elif 1 <= j <= r:
                for k, c in gA.items():
                    add(d, A(j - 1, k), c)
                for k, c in En.items():
                    add(d, C(p + j - 1 - r, k), r * pou * c)
            else:  # r+1 <= j <= p-1
                for k, c in gA.items():
                    add(d, A(j - 1, k), c)
                for k, c in Xn.items():
                    add(d, C(j - 1 - r, k), r * p * p * c)
            EE[A(j, i)] = d
            # E on C_j
            d = {}
            if j == 0:
                add(d, A(r - 1, i), r)
                for k, c in En.items():
                    add(d, C(p - 1, k), pou * c)
            elif 1 <= j <= p - r:
                for k, c in gC.items():
                    add(d, C(j - 1, k), c)
                add(d, A(j + r - 1, i), r)
            else:  # p-r+1 <= j <= p-1
                for k, c in gC.items():
                    add(d, C(j - 1, k), c)
                add(d, C(j - 1, i), r * p)
                for k, c in Fn.items():
                    add(d, A(j + r - 1 - p, k), r * pu * c)
            EE[C(j, i)] = d
    return W, EE, FF


def digits(x, p):
    d = []
    while x:
        d.append(x % p)
        x //= p
    return d  # little endian


def L(lam, p, coupling='p', wrap_p=True, outer_only=False):
    """Theorem 1.6: L(lam) = Delta(lam) if lam+1 < p; else lam+1 = d0 + p(b+1),
    Phi_p(L(b)) if d0 == 0, Psi_{d0}(L(b)) otherwise.  Controls: coupling / wrap_p apply to the
    outermost move only if outer_only, else to all moves."""
    if lam + 1 < p:
        return delta(lam)
    d0 = (lam + 1) % p
    b = (lam + 1) // p - 1
    inner = L(b, p, coupling=('p' if outer_only else coupling), wrap_p=(True if outer_only else wrap_p),
              outer_only=outer_only)
    if d0 == 0:
        return phi(inner, p, wrap_p=wrap_p)
    return psi(inner, p, d0, coupling=coupling)


def dimT(lam, p):
    d = digits(lam + 1, p)
    k = len(d) - 1
    I = [t for t in range(k) if d[t] != 0]
    return d[k] * p ** k * 2 ** len(I)


def vp(x, p):
    if x == 0:
        return 10 ** 9
    v = 0
    while x % p == 0:
        x //= p
        v += 1
    return v


def vp_fact(r, p):
    v, q = 0, p
    while q <= r:
        v += r // q
        q *= p
    return v
