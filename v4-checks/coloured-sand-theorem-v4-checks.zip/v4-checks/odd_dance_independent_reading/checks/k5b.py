from k4_formula import syl_hamming
G, free = syl_hamming(12, 3, 3)
print('Syl_3 K(H(12,3)) by my closed formula:', dict(sorted(G.items())), 'free', free)
rep = {1: 36952, 2: 10078, 3: 10319, 4: 14727, 5: 51128, 6: 13871, 7: 12101, 8: 24210, 9: 2619, 10: 1267, 11: 1843, 12: 67, 13: 12}
print('report PASO 4(c) illustration equal:', dict(G) == rep)
# rows of [CS3] §10 (d = 5..11, q = 3) from the closed formula
cs3 = {5: (12,10,16,53,5), 6: (38,37,36,117,24,16,6), 7: (86,105,127,285,85,63,41), 8: (250,211,286,1078,174,133,174,8),
       9: (942,412,624,3339,449,292,495,133,84,37,9), 10: (3314,1388,1768,7310,1690,1364,1388,1392,316,190,74),
       11: (11035,4345,5127,11339,10099,4994,4432,7162,704,419,416)}
for d, row in cs3.items():
    G, _ = syl_hamming(d, 3, 3)
    mine = tuple(G.get(a, 0) for a in range(1, max(G) + 1))
    print(d, 'CS3 §10 row reproduced:', mine == row)
