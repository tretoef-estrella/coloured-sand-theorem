# k6.py — K6: the odd-p Theorem F numerically, in houses H = (I, k, l, e, (d_t)), with my own code.
# For every house: Lemma 7.6_p gates (window types OR/DIG/AND/NEV, kappa_t, sat_t) vs the direct carry
# count; Lemma 7.7_p (R_H, J_H on both halves from H'; the shift d_1); the gluing
# yhat_H = [max(X_1,0), min(X_2,0)]; (Lambda_p) |yhat_H| <= e*o_I; (Cut) strict at the first dancer with J = 1
# and at its mirror; Lemma 7.9_p (integral real fits: house, penalty cells, l = p^k - 1 without first dancer);
# the potential V built by MY proof (checks/THEOREM_F_ODD_P.md, steps 1-8): (E), (M), (G), junction bound,
# central-flat interval non-empty; and Theorem U's conclusion T(r) >= Y(r) by brute-force min-cost matchings.
import sys, itertools, time, os
CONTROL = os.environ.get('K6_CONTROL', '')
from fractions import Fraction
from collections import Counter
from functools import lru_cache
from k4_formula import carries, int_antitonic_fit, real_antitonic_fit

STATS = Counter()


class House:
    def __init__(self, I, k, l, e, d, p):
        self.I = tuple(sorted(I)); self.k = k; self.l = l; self.e = e; self.d = dict(d); self.p = p
        nxt = {}
        for a, t in enumerate(self.I):
            nxt[t] = self.I[a + 1] if a + 1 < len(self.I) else k
        self.h = {t: nxt[t] - t for t in self.I}
        Ds = []
        for mask in range(1 << len(self.I)):
            Ds.append(frozenset(self.I[j] for j in range(len(self.I)) if mask >> j & 1))
        Ds.sort(key=self.o)
        self.D = Ds; self.Iset = frozenset(self.I)
        self.pos = {D: x for x, D in enumerate(Ds)}

    def o(self, E):
        return sum(self.d[t] * self.p ** t for t in E)

    def R(self, E):
        return sum(self.h[t] - self.e * self.d[t] * self.p ** t for t in E) - carries(self.l, self.o(E), self.p)

    def J(self, E):
        return 1 if self.l + self.o(E) >= self.p ** self.k else 0

    def gamma(self, Dl):
        if not Dl:
            return 0
        mn = min(Dl)
        return sum(self.h[u] for u in self.I if u not in Dl and u > mn)

    def x(self):
        return [self.R(D) - self.R(self.Iset - D) for D in self.D]

    def chat(self, a, b):
        return self.R(a) - self.R(b) + self.gamma(a - b)

    def window(self, t):
        """type, kappa_t, sat_t of the window W_t (Lemma 7.6_p)."""
        p = self.p
        lt = (self.l // p ** t) % p
        theta = p - lt
        r_next = 0
        u = t + 1
        while u < self.k and (self.l // p ** u) % p == p - 1:
            r_next += 1; u += 1
        kap = 1 + min(r_next, self.h[t] - 1)
        sat = 1 if kap == self.h[t] else 0
        dt = self.d[t]
        if theta == 1:
            typ = 'OR'
        elif 2 <= theta <= dt:
            typ = 'DIG'
        elif theta == dt + 1:
            typ = 'AND'
        else:
            typ = 'NEV'
        return typ, kap, sat


def H_prime(H):
    c = max(H.I)
    I2 = [t for t in H.I if t != c]
    return House(I2, c, H.l % H.p ** c, H.e, {t: H.d[t] for t in I2}, H.p), c


def check_gates(H):
    """R_H and J_H from the window rule of Lemma 7.6_p, carry by carry, vs the direct definitions."""
    bad = 0
    for E in H.D:
        c = 0; tot = 0
        for t in H.I:
            typ, kap, sat = H.window(t)
            dd = 1 if t in E else 0
            makes = {'OR': dd or c, 'DIG': (0 if CONTROL == 'gate' else dd), 'AND': dd and c, 'NEV': 0}[typ]
            if makes:
                tot += kap
            c = 1 if (makes and sat) else 0
        if tot != carries(H.l, H.o(E), H.p):
            bad += 1
        if c != H.J(E):
            bad += 1
    return bad


def potential(H, memo):
    """V by the proof of Theorem F_p (steps 1-8).  Returns dict dancer -> int, and records failures."""
    key = (H.I, H.k, H.l, H.e, tuple(sorted(H.d.items())), H.p)
    if key in memo:
        return memo[key]
    if not H.I:
        V = {frozenset(): 0}
        memo[key] = V
        return V
    Hp, c = H_prime(H)
    Vp = potential(Hp, memo)
    typ, kap, sat = H.window(c)
    STATS['type ' + typ] += 1
    h = H.k - c
    tau = h - H.e * H.d[c] * H.p ** c - (kap if typ in (('OR',) if CONTROL == 'tau' else ('OR', 'DIG')) else 0)
    Jp = Hp.J
    yp = dict(zip(Hp.D, int_antitonic_fit(Hp.x())))
    # Lemma 7.7_p identities
    for D0 in Hp.D:
        rH0 = H.R(D0); rH1 = H.R(D0 | {c})
        if rH0 != Hp.R(D0) - (kap if typ == 'OR' else 0) * Jp(D0):
            STATS['FAIL L7.7 R first half'] += 1
        if rH1 != tau + Hp.R(D0) - (kap if typ == 'AND' else 0) * Jp(D0):
            STATS['FAIL L7.7 R second half'] += 1
        if H.J(D0) != (1 if typ == 'OR' else 0) * sat * Jp(D0):
            STATS['FAIL L7.7 J first half'] += 1
        if H.J(D0 | {c}) != sat * ((1 if typ in ('OR', 'DIG') else 0) + (1 if typ == 'AND' else 0) * Jp(D0)):
            STATS['FAIL L7.7 J second half'] += 1
    def d1(D0):
        return -tau - (kap if typ == 'OR' else 0) * Jp(D0) + (kap if typ == 'AND' else 0) * Jp(Hp.Iset - D0)
    # d_1 non-increasing in o-order
    seq = [d1(D0) for D0 in Hp.D]
    if any(seq[j] < seq[j + 1] for j in range(len(seq) - 1)):
        STATS['FAIL d1 monotone'] += 1
    if any(seq[j] > H.e * H.d[c] * H.p ** c for j in range(len(seq))):
        STATS['FAIL d1 <= e d_c p^c'] += 1
    # first half of x_H = x_H' + d1
    xH = dict(zip(H.D, H.x()))
    for D0 in Hp.D:
        if xH[D0] != Hp.x()[Hp.pos[D0]] + d1(D0):
            STATS['FAIL first half of x_H'] += 1
    # gluing
    X1 = {D0: yp[D0] + d1(D0) for D0 in Hp.D}
    yH = dict(zip(H.D, int_antitonic_fit(H.x())))
    for D0 in Hp.D:
        if yH[D0] != max(X1[D0], 0):
            STATS['FAIL gluing first half'] += 1
        if yH[H.Iset - D0] != min(-X1[D0], 0):
            STATS['FAIL gluing second half'] += 1
    # inherited potential v'
    vp_ = {}
    for D0 in Hp.D:
        vp_[D0] = Vp[D0] - (kap if typ == 'OR' else 0) * Jp(D0)
        vp_[D0 | {c}] = tau + Vp[D0] - (kap if typ == 'AND' else 0) * Jp(D0)
    # (G) for v' with slack h on same-half arrows
    for a in H.D:
        for b in H.D:
            if b < a:
                slack = h if ((c in a) == (c in b)) else 0
                if H.chat(a, b) < vp_[a] - vp_[b] + slack:
                    STATS['FAIL (G) for v\' with slack'] += 1
    Ip = Hp.Iset
    # junction bound
    if vp_[frozenset({c})] - vp_[Ip] != -X1[Ip]:
        STATS['FAIL junction identity'] += 1
    if -X1[Ip] > h - H.e:
        STATS['FAIL junction bound h - e'] += 1
    if X1[Ip] > 0:
        V = dict(vp_)
        STATS['no central flat'] += 1
    else:
        STATS['central flat'] += 1
        first = Hp.D  # first half in o-order
        F1 = [D0 for D0 in first if X1[D0] <= 0]
        # F1 must be a final segment containing I'
        if F1 != first[len(first) - len(F1):] or Ip not in F1:
            STATS['FAIL F1 final segment'] += 1
        f = F1[0]
        c3 = vp_[f]; c4 = vp_[H.Iset - f]
        lo = c3; hi = c4
        idx = first.index(f)
        if idx > 0:
            pp = first[idx - 1]
            hi = min(hi, vp_[pp]); lo = max(lo, vp_[H.Iset - pp])
        if lo > hi:
            STATS['FAIL central interval empty'] += 1
        cF = lo
        Fset = set(F1) | {H.Iset - D0 for D0 in F1}
        V = {D: (cF if D in Fset else vp_[D]) for D in H.D}
    # checks of (E), (M), (G)
    for D in H.D:
        if V[D] - V[H.Iset - D] != yH[D]:
            STATS['FAIL (E)'] += 1
    vs = [V[D] for D in H.D]
    if any(vs[j] < vs[j + 1] for j in range(len(vs) - 1)):
        STATS['FAIL (M)'] += 1
    for a in H.D:
        for b in H.D:
            if b < a and V[a] - V[b] > H.chat(a, b):
                STATS['FAIL (G)'] += 1
    memo[key] = V
    return V


def check_cut_lambda_integrality(H):
    x = H.x()
    z = real_antitonic_fit(x)
    y = int_antitonic_fit(x)
    oI = H.o(H.Iset)
    if any(abs(v) > H.e * oI for v in y):
        STATS['FAIL (Lambda_p)'] += 1
    if any(v.denominator != 1 for v in z):
        STATS['FAIL integrality house'] += 1
    # cut at first dancer with J = 1 and its mirror, strict
    N = len(H.D)
    bpos = next((j for j, D in enumerate(H.D) if H.J(D)), None)
    if bpos is not None:
        STATS['houses with a J-boundary'] += 1
        for b in (bpos, N - bpos):
            if not (0 < b < N):
                continue
            z1 = real_antitonic_fit(x[:b]); z2 = real_antitonic_fit(x[b:])
            if z1 + z2 != z:
                STATS['FAIL (Cut) not a cut'] += 1
            if not z[b - 1] > z[b]:
                STATS['FAIL (Cut) not strict'] += 1
    # penalty cells
    for Pr, Pc in ((1, 0), (0, 1), (2, 0), (0, 3), (3, 0)):
        xc = [x[j] - Pr * H.J(D) + Pc * H.J(H.Iset - D) for j, D in enumerate(H.D)]
        zc = real_antitonic_fit(xc)
        if any(v.denominator != 1 for v in zc):
            STATS['FAIL integrality penalty cell'] += 1
        # integer fit of the cell = yhat_H + penalty shift (Lemma 7.2(b) as used in Thm 7.10)
        yc = int_antitonic_fit(xc)
        if yc != [y[j] - Pr * H.J(D) + Pc * H.J(H.Iset - D) for j, D in enumerate(H.D)]:
            STATS['FAIL penalty shift'] += 1
    return y


def min_cost_matchings(H, cost):
    """T(r) for r = 0..N: least total cost of r-matchings beta (beta(a) subset of a), by successive shortest
    paths (Bellman-Ford) on the bipartite graph rows -> cols."""
    N = len(H.D)
    INF = float('inf')
    # nodes: 0 source, 1..N rows, N+1..2N cols, 2N+1 sink
    S, T = 0, 2 * N + 1
    edges = {}
    def add(u, v, c):
        edges[(u, v)] = [1, c]
        edges.setdefault((v, u), [0, -c])
    for a in range(N):
        add(S, 1 + a, 0)
        add(N + 1 + a, T, 0)
        for b in range(N):
            if H.D[b] <= H.D[a]:
                add(1 + a, N + 1 + b, cost(H.D[a], H.D[b]))
    adj = {}
    for (u, v) in edges:
        adj.setdefault(u, []).append(v)
    out = [0]; total = 0
    for r in range(N):
        dist = [INF] * (2 * N + 2); prev = [None] * (2 * N + 2); dist[S] = 0
        for _ in range(2 * N + 2):
            changed = False
            for (u, v), (cap, c) in edges.items():
                if cap > 0 and dist[u] + c < dist[v]:
                    dist[v] = dist[u] + c; prev[v] = u; changed = True
            if not changed:
                break
        if dist[T] == INF:
            break
        total += dist[T]; out.append(total)
        v = T
        while v != S:
            u = prev[v]; edges[(u, v)][0] -= 1; edges[(v, u)][0] += 1; v = u
    return out


def check_theoremU(H, y, Pr=0, Pc=0):
    N = len(H.D)
    cost = lambda a, b: H.chat(a, b) - Pr * H.J(a) + Pc * H.J(b)
    T = min_cost_matchings(H, cost)
    yc = int_antitonic_fit([H.x()[j] - Pr * H.J(D) + Pc * H.J(H.Iset - D) for j, D in enumerate(H.D)])
    Y = [0]
    for r in range(1, N + 1):
        Y.append(sum(yc[N - r:]))
    for r in range(N + 1):
        if T[r] < Y[r]:
            STATS['FAIL T(r) >= Y(r)'] += 1
    # also the natural sums U(r) and the golden matching value (ceiling side): U(r) >= Y(r)
    xc = [H.x()[j] - Pr * H.J(D) + Pc * H.J(H.Iset - D) for j, D in enumerate(H.D)]
    for r in range(N + 1):
        if sum(xc[N - r:]) < Y[r]:
            STATS['FAIL U(r) >= Y(r)'] += 1


def houses(p, k):
    for nI in range(0, k + 1):
        for I in itertools.combinations(range(k), nI):
            for ds in itertools.product(range(1, p), repeat=nI):
                for l in range(p ** k):
                    yield I, dict(zip(I, ds)), l


if __name__ == '__main__':
    t0 = time.time()
    plan = [(3, k) for k in range(1, 5)] + [(5, k) for k in range(1, 4)]
    if len(sys.argv) > 1:
        plan = [tuple(int(v) for v in s.split(':')) for s in sys.argv[1:]]
    nh = 0; nU = 0
    memo = {}
    for p, k in plan:
        for e in (1, 2):
            for I, d, l in houses(p, k):
                H = House(I, k, l, e, d, p)
                nh += 1
                STATS['FAIL gates'] += check_gates(H)
                y = check_cut_lambda_integrality(H)
                potential(H, memo)
                if len(H.D) <= 8 and (nh % 3 == 0):
                    check_theoremU(H, y); nU += 1
                    check_theoremU(H, y, 1, 0); check_theoremU(H, y, 0, 2)
        print(f'p={p} k={k} done: houses so far {nh}, Theorem U brute-force houses {nU}, '
              f'{dict(sorted(STATS.items()))} [{time.time() - t0:.0f}s]')
        sys.stdout.flush()
    fails = {k_: v for k_, v in STATS.items() if k_.startswith('FAIL') and v}
    print('TOTAL houses', nh, 'failures', fails if fails else 'none')
