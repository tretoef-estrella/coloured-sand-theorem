# lit_oa_authors.py — OpenAlex: find an author by name, list all works, filter titles by keywords.
import json, subprocess, sys, time, urllib.parse, re
names = json.load(open(sys.argv[1])); kw = re.compile(sys.argv[2], re.I)
def get(u): return json.loads(subprocess.run(['curl','-sS','-m','60',u],capture_output=True,text=True).stdout)
for name, hint in names:
    a = get('https://api.openalex.org/authors?' + urllib.parse.urlencode({'search': name, 'per-page': 10}))
    cands = [r for r in a.get('results', []) if re.search(hint, json.dumps(r.get('last_known_institutions') or r.get('affiliations') or '') + ' ' + json.dumps(r.get('topics', [])[:5]), re.I)] or a.get('results', [])[:1]
    if not cands:
        print(f'[{name}] not found'); continue
    au = cands[0]; aid = au['id'].split('/')[-1]
    works = []; cursor = '*'
    while cursor:
        r = get('https://api.openalex.org/works?' + urllib.parse.urlencode({'filter': f'author.id:{aid}', 'per-page': 200, 'cursor': cursor}))
        works += r.get('results', []); cursor = r.get('meta', {}).get('next_cursor')
        if not r.get('results'): break
        time.sleep(0.4)
    hits = [w for w in works if kw.search(w.get('display_name') or '')]
    print(f'[{name}] OpenAlex author {aid} ({au.get("display_name")}), works {len(works)}, keyword hits {len(hits)}')
    for w in sorted(hits, key=lambda w: w.get('publication_year') or 0):
        print(f'     {w.get("publication_year")} | {(w.get("display_name") or "")[:140]}')
    sys.stdout.flush(); time.sleep(1)
