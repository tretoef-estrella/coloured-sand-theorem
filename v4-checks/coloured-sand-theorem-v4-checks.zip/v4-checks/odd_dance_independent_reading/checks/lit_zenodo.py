# lit_zenodo.py — Zenodo records API with exact-phrase queries (size 25).
import json, subprocess, sys, time, urllib.parse
qs = json.load(open(sys.argv[1])); tag = sys.argv[2]
for k, q in enumerate(qs, 1):
    url = 'https://zenodo.org/api/records?' + urllib.parse.urlencode({'q': q, 'size': 25})
    s = subprocess.run(['curl', '-sS', '-L', '-m', '60', '-H', 'Accept: application/json', url], capture_output=True, text=True).stdout
    open(f'lit/{tag}_{k:02d}_zenodo.json', 'w').write(s)
    try:
        d = json.loads(s); res = d.get('hits', {}).get('hits', [])
        print(f'[Zenodo] {q}: total {d.get("hits",{}).get("total")}')
        for r in res:
            m = r.get('metadata', {})
            print(f'     {m.get("publication_date","")} | {(m.get("title") or "")[:120]} | {r.get("doi","")} | {"; ".join(c.get("name","") for c in m.get("creators",[])[:2])}')
    except Exception:
        print(f'[Zenodo] {q}: ERR {s[:200]}')
    sys.stdout.flush(); time.sleep(2)
