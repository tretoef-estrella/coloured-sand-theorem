# k2.py — K2: L(lam) (x) F_p = T(lam) WITHOUT Donkin's tensor product theorem.
# For M = L(lam) (x) F_p (checks/lat.py, exact integers reduced mod p):
#  (a) M has a Delta-filtration: greedy — take the top weight mu of the current quotient, the vectors of weight mu
#      generate (via F^(k)) a submodule of dimension (mu+1)*n (n = their number mod the previous submodule), i.e.
#      a copy of Delta(mu)^n; repeat.  Success is a Delta-filtration (sufficient condition).
#  (b) M has a nabla-filtration: (a) for the contravariant dual (E^(r) -> F^(r)^T, F^(r) -> E^(r)^T).
#  (c) M is indecomposable: End_Dist(M) (maps preserving weight spaces and commuting with E^(p^t), F^(p^t) for all
#      p^t <= 2 lam, which generate Dist(SL_2) over F_p with the weights) is local: its kernel K of the character
#      phi -> (phi on the 1-dim top weight space) is nilpotent (K^j computed until 0).
# Then M is an indecomposable tilting module with highest weight lam (multiplicity one), hence M = T(lam) by the
# classification of tilting modules (Ringel; Donkin; Jantzen RAGS E.6 = Heidersdorf-Wenzl arXiv:1912.09457 Prop 5.1).
# Also recorded: dim End (Tubbenhauer-Wedrich predict 2^{|I|}) and the Jordan type of f.
# Controls: M (+) L(lam-2) (x) F_p must fail (c); the Weyl module Delta(lam) (x) F_p must fail (b) when not simple.
import sys, time
import numpy as np
import flint
from lat import L, delta, apply, vp, vp_fact, digits, dimT

def dp_matrix(lat, X, r, p):
    """matrix (dense numpy, mod p) of X^(r) = X^r / r! (X = 'E' or 'F'), from exact integer powers."""
    wts, E, F = lat
    M = E if X == 'E' else F
    n = len(wts)
    out = np.zeros((n, n), dtype=np.int64)
    v_f = vp_fact(r, p)
    f_unit = 1
    for x in range(2, r + 1):
        while x % p == 0: x //= p
        f_unit = f_unit * x % p
    inv = pow(f_unit, p - 2, p)
    for i in range(n):
        v = {i: 1}
        for _ in range(r):
            v = apply(M, v)
            if not v: break
        for k, c in v.items():
            q, rem = divmod(c, p ** v_f)
            if rem: raise RuntimeError('non-integral divided power')
            out[k, i] = (q % p) * inv % p
    return out

def dp_all(lat, X, maxk, p):
    """[I, X^(1), ..., X^(maxk)] mod p, by iterating X on each basis vector once (exact integers)."""
    wts, E, F = lat
    M = E if X == 'E' else F
    n = len(wts)
    outs = [np.eye(n, dtype=np.int64)] + [np.zeros((n, n), dtype=np.int64) for _ in range(maxk)]
    units = [1] * (maxk + 1); vfs = [0] * (maxk + 1)
    u = 1
    for r in range(1, maxk + 1):
        x = r
        while x % p == 0: x //= p
        u = u * x % p; units[r] = pow(u, p - 2, p); vfs[r] = vp_fact(r, p)
    for i in range(n):
        v = {i: 1}
        for r in range(1, maxk + 1):
            v = apply(M, v)
            if not v: break
            for k, c in v.items():
                q, rem = divmod(c, p ** vfs[r])
                if rem: raise RuntimeError('non-integral divided power')
                outs[r][k, i] = (q % p) * units[r] % p
    return outs

def rank_mod_p(vectors, p):
    if not vectors: return 0
    A = flint.nmod_mat(len(vectors), len(vectors[0]), [int(x) for v in vectors for x in v], p)
    return A.rank()

def delta_filtration(wts, Fdp, p):
    """greedy; Fdp[k] = matrix of F^(k) mod p (k = 0..max).  Returns (success, list of (mu, n))."""
    n = len(wts)
    S = []  # basis vectors (lists) of the current submodule
    rS = 0
    factors = []
    remaining_weights = sorted(set(wts), reverse=True)
    while rS < n:
        # top weight of the quotient
        mu = None
        for w in sorted(set(wts), reverse=True):
            idx = [i for i in range(n) if wts[i] == w]
            basis_w = [[1 if j == i else 0 for j in range(n)] for i in idx]
            if rank_mod_p(S + basis_w, p) > rS:
                mu = w; break
        # vectors of weight mu independent mod S
        idx = [i for i in range(n) if wts[i] == mu]
        chosen = []; cur = list(S); rc = rS
        for i in idx:
            e_i = [1 if j == i else 0 for j in range(n)]
            if rank_mod_p(cur + [e_i], p) > rc:
                cur.append(e_i); rc += 1; chosen.append(i)
        new = []
        for i in chosen:
            for k in range(0, mu + 1):
                if k >= len(Fdp): break
                new.append([int(x) for x in Fdp[k][:, i]])
        r_new = rank_mod_p(S + new, p)
        nn = len(chosen)
        if mu < 0 or r_new - rS != (mu + 1) * nn:
            return False, factors + [('FAIL at', mu, nn, r_new - rS)]
        factors.append((mu, nn))
        S = S + new
        # keep S small: re-extract a basis
        A = flint.nmod_mat(len(S), n, [int(x) for v in S for x in v], p)
        R, rk = A.rref()
        S = [[int(R[a, b]) for b in range(n)] for a in range(rk)]
        rS = rk
    return True, factors

def end_algebra(wts, gens, p):
    """basis of End_Dist(M) over F_p: block-diagonal maps commuting with every generator matrix in gens."""
    n = len(wts)
    blocks = {}
    for i, w in enumerate(wts):
        blocks.setdefault(w, []).append(i)
    unk = {}
    for w, idx in blocks.items():
        for a in idx:
            for b in idx:
                unk[(a, b)] = len(unk)   # phi[a, b]
    rows = []
    for G in gens:
        # (G phi - phi G)[r, c] = 0 for all r, c ; phi[a,b] nonzero only within blocks
        nzG = [(r, c) for r, c in zip(*np.nonzero(G))]
        colsG = {}
        for r, c in nzG:
            colsG.setdefault(c, []).append(r)
        rowsG = {}
        for r, c in nzG:
            rowsG.setdefault(r, []).append(c)
        # entry (r, c): sum_k G[r,k] phi[k,c] - sum_k phi[r,k] G[k,c]
        targets = set()
        for r, c in nzG:
            for k in blocks[wts[c]]:
                targets.add((r, k))
            for k in blocks[wts[r]]:
                targets.add((k, c))
        for (r, c) in targets:
            eq = {}
            for k in rowsG.get(r, []):
                if wts[k] == wts[c]:
                    u = unk[(k, c)]; eq[u] = (eq.get(u, 0) + int(G[r, k])) % p
            for k in colsG.get(c, []):
                if wts[r] == wts[k]:
                    u = unk[(r, k)]; eq[u] = (eq.get(u, 0) - int(G[k, c])) % p
            eq = {u: v for u, v in eq.items() if v}
            if eq: rows.append(eq)
    m = len(unk)
    if not rows:
        null = [np.eye(m, dtype=np.int64)[i] for i in range(m)]
    else:
        A = flint.nmod_mat(len(rows), m, p)
        for a, eq in enumerate(rows):
            for u, v in eq.items():
                A[a, u] = v
        X, nul = A.nullspace()
        null = [np.array([int(X[r, c]) for r in range(m)], dtype=np.int64) for c in range(nul)]
    mats = []
    for vec in null:
        Phi = np.zeros((n, n), dtype=np.int64)
        for (a, b), u in unk.items():
            Phi[a, b] = vec[u] % p
        mats.append(Phi)
    return mats

def is_local(mats, top, p):
    """End local iff K = {phi : phi(top) = 0} is nilpotent; returns (local, dim End, nilpotency index)."""
    n = mats[0].shape[0]
    # character chi(phi) = phi[top, top]; basis of K: phi - chi(phi)/chi(phi0) phi0
    chi = [int(P[top, top]) % p for P in mats]
    piv = next((j for j, c in enumerate(chi) if c), None)
    if piv is None:
        return False, len(mats), None
    inv = pow(chi[piv], p - 2, p)
    Kb = [(P - (c * inv % p) * mats[piv]) % p for j, (P, c) in enumerate(zip(mats, chi)) if j != piv]
    def span_basis(Ms):
        if not Ms: return []
        A = flint.nmod_mat(len(Ms), n * n, [int(x) for Mx in Ms for x in Mx.flatten()], p)
        R, rk = A.rref()
        return [np.array([int(R[a, b]) for b in range(n * n)], dtype=np.int64).reshape(n, n) for a in range(rk)]
    Kj = span_basis(Kb); j = 1
    while Kj and j < 64:
        Kj = span_basis([(A_ @ B_) % p for A_ in Kj for B_ in Kb])
        j += 1
    return (not Kj), len(mats), j

def jordan_type_f(Fm, p):
    """sizes of Jordan blocks of a nilpotent matrix mod p: from ranks of powers."""
    n = Fm.shape[0]
    ranks = [n]; P = np.eye(n, dtype=np.int64)
    while ranks[-1] > 0:
        P = (P @ Fm) % p
        ranks.append(flint.nmod_mat(n, n, [int(x) for x in P.flatten()], p).rank())
    # number of blocks of size >= k is ranks[k-1] - ranks[k]
    ge = [ranks[k - 1] - ranks[k] for k in range(1, len(ranks))]
    sizes = {}
    for k in range(1, len(ge) + 1):
        exact = ge[k - 1] - (ge[k] if k < len(ge) else 0)
        if exact: sizes[k] = exact
    return sizes

def analyse(lat, lam, p, label):
    wts, E, F = lat
    n = len(wts)
    maxk = max(wts) - min(wts)
    Fdp = dp_all(lat, 'F', maxk, p)
    okD, facD = delta_filtration(wts, Fdp, p)
    Edp = dp_all(lat, 'E', maxk, p)
    okN, facN = delta_filtration(wts, [X.T.copy() for X in Edp], p)   # dual: F acts as E^T
    gens = []
    t = 1
    while t <= maxk:
        gens.append(Edp[t]); gens.append(Fdp[t]); t *= p
    mats = end_algebra(wts, gens, p)
    top = wts.index(max(wts))
    loc, dimEnd, nil = is_local(mats, top, p)
    jt = jordan_type_f(Fdp[1], p)
    return okD, facD, okN, facN, loc, dimEnd, nil, jt

if __name__ == '__main__':
    t0 = time.time()
    plan = {3: list(range(12, 51)), 5: list(range(30, 46)), 7: list(range(56, 63))}
    if len(sys.argv) > 2:
        plan = {int(sys.argv[2]): list(range(int(sys.argv[3]), int(sys.argv[4]) + 1))}
    DIMCAP = int(sys.argv[1]) if len(sys.argv) > 1 else 220
    tot = 0; good = 0
    for p, lams in plan.items():
        for lam in lams:
            if dimT(lam, p) > DIMCAP: continue
            lat = L(lam, p)
            okD, facD, okN, facN, loc, dimEnd, nil, jt = analyse(lat, lam, p, 'L')
            d = digits(lam + 1, p); k = len(d) - 1; nI = sum(1 for t in range(k) if d[t])
            tilting_indec = okD and okN and loc and max(lat[0]) == lam and lat[0].count(lam) == 1
            tot += 1; good += tilting_indec
            print(f'p={p} lam={lam} dim={len(lat[0])} digits={d}: Delta-filt {okD} {facD} | nabla-filt {okN} | End local {loc} '
                  f'(dim End {dimEnd}, 2^|I| = {2**nI}, K nilpotent at step {nil}) | Jordan type of f {jt} | '
                  f'=> {"TILTING, INDECOMPOSABLE => T(lam)" if tilting_indec else "NOT identified"}  [{time.time()-t0:.0f}s]')
            sys.stdout.flush()
    print(f'K2: {good}/{tot} lattices identified as T(lam) without Donkin')
    # controls
    for p, lam in ((3, 12), (3, 14), (5, 31)):
        a = L(lam, p); b = L(lam - 2, p)
        n1 = len(a[0])
        wts = a[0] + b[0]
        E = a[1] + [{k + n1: c for k, c in col.items()} for col in b[1]]
        F = a[2] + [{k + n1: c for k, c in col.items()} for col in b[2]]
        okD, facD, okN, facN, loc, dimEnd, nil, jt = analyse((wts, E, F), lam, p, 'sum')
        print(f'CONTROL direct sum L({lam}) + L({lam-2}), p={p}: Delta {okD}, nabla {okN}, End local {loc} (must be False), dim End {dimEnd}')
        W = delta(lam)
        okD, facD, okN, facN, loc, dimEnd, nil, jt = analyse(W, lam, p, 'weyl')
        print(f'CONTROL Weyl module Delta({lam}) mod {p}: Delta {okD}, nabla {okN} (must be False), End local {loc}')
        sys.stdout.flush()
