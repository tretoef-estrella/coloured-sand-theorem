# k1.py — K1: the lattices of Definitions 1.1 / 1.3 as printed (checks/lat.py), for p in {3,5,7} and
# every lam with dim T(lam) <= DIMCAP.  Checks: sl2 relations; character = Donkin product; rank;
# integrality of E^(r), F^(r) for ALL r by exact integer powers (weight-block products);
# controls: coupling p -> p^2 and p -> 0 (all split moves), and the twist without p.
import sys, time
from lat import L, dimT, digits, vp, vp_fact, apply
from fractions import Fraction

DIMCAP = int(sys.argv[2]) if len(sys.argv) > 2 else 300
PS = [int(x) for x in sys.argv[1].split(',')] if len(sys.argv) > 1 else [3, 5, 7]


def donkin_char(lam, p):
    d = digits(lam + 1, p)
    k = len(d) - 1
    ch = {0: 1}
    def mul(a, b):
        out = {}
        for x, c in a.items():
            for y, e in b.items():
                out[x + y] = out.get(x + y, 0) + c * e
        return {x: c for x, c in out.items() if c}
    def chi(n, s):  # chi_n(z^s)
        return {s * (n - 2 * j): 1 for j in range(n + 1)}
    for t in range(k):
        ch = mul(ch, chi(p - 1, p ** t))
        if d[t]:
            ch = mul(ch, {d[t] * p ** t: 1, -d[t] * p ** t: 1})
    ch = mul(ch, chi(d[k] - 1, p ** k))
    return ch


def check_relations(lat):
    wts, E, F = lat
    n = len(wts)
    bad = 0
    for i in range(n):
        ef = apply(E, F[i]); fe = apply(F, E[i])
        com = dict(ef)
        for k, c in fe.items():
            com[k] = com.get(k, 0) - c
        com = {k: c for k, c in com.items() if c}
        if com != ({i: wts[i]} if wts[i] else {}):
            bad += 1
        for k in E[i]:
            if wts[k] != wts[i] + 2:
                bad += 1
        for k in F[i]:
            if wts[k] != wts[i] - 2:
                bad += 1
    return bad


def blocks(lat):
    """weight -> list of indices; E-blocks and F-blocks as small dense lists."""
    wts, E, F = lat
    byw = {}
    for i, w in enumerate(wts):
        byw.setdefault(w, []).append(i)
    pos = {}
    for w, idx in byw.items():
        for a, i in enumerate(idx):
            pos[i] = a
    def blk(M, w, dw):
        src = byw.get(w, []); dst = byw.get(w + dw, [])
        B = [[0] * len(src) for _ in dst]
        for b, i in enumerate(src):
            for k, c in M[i].items():
                B[pos[k]][b] = c
        return B
    return byw, blk


def matmul(A, B):
    if not A or not B:
        return []
    n, m, l = len(A), len(B), len(B[0])
    return [[sum(A[i][k] * B[k][j] for k in range(m)) for j in range(l)] for i in range(n)]


def divided_power_integrality(lat, p):
    """min over r>=1 and entries of v_p(entry of X^r) - v_p(r!), for X = E and X = F; +inf if all zero.
    Also returns the number of (r, start weight) blocks with a negative value (non-integral)."""
    wts, E, F = lat
    byw, blk = blocks(lat)
    ws = sorted(byw)
    res = {}
    for name, M, dw in (('E', E, 2), ('F', F, -2)):
        mn = 10 ** 9; nbad = 0; nchk = 0
        Bk = {w: blk(M, w, dw) for w in ws}
        for w0 in ws:
            P = None; w = w0; r = 0
            while True:
                if w + dw not in byw:
                    break
                B = Bk[w]
                P = B if P is None else matmul(B, P)
                r += 1; w += dw
                vf = vp_fact(r, p)
                nz = [x for row in P for x in row if x]
                if not nz:
                    break
                nchk += 1
                v = min(vp(x, p) for x in nz) - vf
                mn = min(mn, v)
                if v < 0:
                    nbad += 1
        res[name] = (mn, nbad, nchk)
    return res


def recover_E(lat):
    """Solve E F - F E = H, E raising weights by 2, over Q (exact).  Returns (status, E) with status in
    {'none', 'unique', 'nonunique'}."""
    import sympy
    wts, _, F = lat
    byw = {}
    for i, w in enumerate(wts):
        byw.setdefault(w, []).append(i)
    unk = {}
    for w, idx in byw.items():
        if w + 2 in byw:
            for i in idx:
                for k in byw[w + 2]:
                    unk[(k, i)] = len(unk)
    rows = []; rhs = []
    n = len(wts)
    for i in range(n):
        # (EF - FE)(v_i) = wts[i] v_i ; coefficient on each v_j of weight wts[i]
        acc = {}
        for k, c in F[i].items():          # E F v_i = sum_k c E v_k
            for j in byw.get(wts[k] + 2, []):
                key = (j, unk[(j, k)])
                acc.setdefault(j, {}); acc[j][unk[(j, k)]] = acc[j].get(unk[(j, k)], 0) + c
        for j0 in byw.get(wts[i] + 2, []):   # F E v_i = sum_{j0} E[j0,i] F v_j0
            for j, c in F[j0].items():
                acc.setdefault(j, {}); u_ = unk[(j0, i)]; acc[j][u_] = acc[j].get(u_, 0) - c
        for j in byw[wts[i]]:
            rows.append(acc.get(j, {})); rhs.append(wts[i] if j == i else 0)
    m = len(unk)
    if m == 0:
        return ('unique' if all(r == 0 for r in rhs) else 'none'), [dict() for _ in range(len(wts))]
    import flint
    nr = len(rows)
    Aug = flint.fmpq_mat(nr, m + 1)
    for a in range(nr):
        for b_, c in rows[a].items():
            Aug[a, b_] = c
        Aug[a, m] = rhs[a]
    R, rk = Aug.rref()
    # inconsistent iff some pivot sits in the last column
    piv_cols = []
    for a in range(rk):
        for b_ in range(m + 1):
            if R[a, b_] != 0:
                piv_cols.append(b_); break
    if m in piv_cols:
        return 'none', None
    if len(piv_cols) < m:
        return 'nonunique', None
    n = len(wts)
    sol = [None] * m
    for a, b_ in enumerate(piv_cols):
        sol[b_] = R[a, m]
    Erec = [dict() for _ in range(n)]
    for (k, i), u_ in unk.items():
        if sol[u_] != 0:
            q = sol[u_]
            Erec[i][k] = Fraction(int(q.p), int(q.q))
    return 'unique', Erec


def frac_integrality(lat_wts, Erec, p):
    """min v_p over r and entries of E^r / r! for a rational E (dict columns of Fractions)."""
    n = len(lat_wts)
    mn = 10 ** 9
    P = [dict(Erec[i]) for i in range(n)]
    r = 1
    while any(P[i] for i in range(n)):
        f = 1
        for x in range(2, r + 1):
            f *= x
        for i in range(n):
            for k, c in P[i].items():
                q = c / f
                v = vp(q.numerator, p) - vp(q.denominator, p)
                mn = min(mn, v)
        # P <- E * P
        Q = [dict() for _ in range(n)]
        for i in range(n):
            for k, c in P[i].items():
                for j, d in Erec[k].items():
                    Q[i][j] = Q[i].get(j, 0) + c * d
            Q[i] = {j: c for j, c in Q[i].items() if c != 0}
        P = Q; r += 1
    return mn


if __name__ == '__main__':
    t0 = time.time()
    for p in PS:
        lams = [lam for lam in range(0, 5000) if dimT(lam, p) <= DIMCAP]
        nlat = 0; tot_bad_rel = 0; tot_bad_char = 0; tot_bad_int = 0; minv = {'E': 10**9, 'F': 10**9}
        for lam in lams:
            lat = L(lam, p)
            wts = lat[0]
            nlat += 1
            br = check_relations(lat)
            ch = {}
            for w in wts:
                ch[w] = ch.get(w, 0) + 1
            bc = (ch != donkin_char(lam, p)) + (len(wts) != dimT(lam, p)) + (max(wts) != lam)
            ig = divided_power_integrality(lat, p)
            bi = ig['E'][1] + ig['F'][1]
            for nm in 'EF':
                minv[nm] = min(minv[nm], ig[nm][0])
            tot_bad_rel += br; tot_bad_char += bc; tot_bad_int += bi
            if br or bc or bi:
                print('FAIL p', p, 'lam', lam, 'rel', br, 'char', bc, 'int', ig)
        print(f'p={p}: lattices {nlat} (lam <= {max(lams)}), relation failures {tot_bad_rel}, '
              f'character/rank failures {tot_bad_char}, integrality failures {tot_bad_int}, '
              f'min over all r of v_p(X^r)-v_p(r!): E {minv["E"]}, F {minv["F"]}  [{time.time()-t0:.1f}s]')
        sys.stdout.flush()
