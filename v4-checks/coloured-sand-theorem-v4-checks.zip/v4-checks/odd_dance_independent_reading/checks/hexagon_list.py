# hexagon_list.py — list EVERY Hexagon deposit through its public read-only API (paginated), save the
# metadata, and flag deposits whose title/abstract touches the topics of the mission.
import json, subprocess, urllib.parse, time, re
allw = []; cursor = None
while True:
    url = 'https://hexagonmath.org/api/v1/works?limit=100' + (('&cursor=' + urllib.parse.quote(cursor)) if cursor else '')
    r = subprocess.run(['curl', '-sS', '-m', '60', url], capture_output=True, text=True)
    d = json.loads(r.stdout)
    allw += d['works']
    pg = d['page']
    if not pg.get('has_more'): break
    cursor = pg['next_cursor']; time.sleep(1)
json.dump(allw, open('lit/hexagon_all_works.json', 'w'), indent=1)
print('total listed', len(allw), '(API says', pg.get('total'), ')')
kw = re.compile(r'sandpile|critical group|chip|smith|hamming|rook|boolean lattice|tilting|SL_?\(?2|sl_2|sl2|jacobian of|laplacian|elementary divisor|inclusion matri|hypercube|cube|weyl module|frobenius twist|modular represent|p-adic|lattice', re.I)
for w in sorted(allw, key=lambda w: w['identifier']):
    t = w.get('title', ''); a = w.get('abstract', '') or ''
    auth = w.get('authors') or w.get('contributors') or w.get('creator') or ''
    if isinstance(auth, list):
        auth = '; '.join(x.get('name', str(x)) if isinstance(x, dict) else str(x) for x in auth)
    flag = 'FLAG' if kw.search(t + ' ' + a) else '    '
    print(f'{flag} {w["identifier"]} | {str(auth)[:60]} | {t[:150]}')
