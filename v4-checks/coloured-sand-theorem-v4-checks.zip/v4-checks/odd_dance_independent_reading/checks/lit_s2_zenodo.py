# lit_s2_zenodo.py — Semantic Scholar (paced 15 s, retried on 429) and Zenodo (page size 25) for the queries.
import json, subprocess, sys, time, urllib.parse
QUERIES = json.load(open(sys.argv[1])); tag = sys.argv[2]
def get(url):
    return subprocess.run(['curl', '-sS', '-m', '60', '--compressed', url], capture_output=True, text=True).stdout
for k, q in enumerate(QUERIES, 1):
    qq = urllib.parse.quote(q)
    for attempt in range(4):
        s = get(f'https://api.semanticscholar.org/graph/v1/paper/search?query={qq}&limit=50&fields=title,year,externalIds')
        if '"code": "429"' in s or 'Too Many Requests' in s:
            time.sleep(30); continue
        break
    open(f'lit/{tag}_{k:02d}_s2.json', 'w').write(s)
    try:
        d = json.loads(s); res = d.get('data', []) or []
        print(f'[S2] {q!r}: total {d.get("total")} (attempts {attempt+1})')
        for r in res[:30]:
            print(f'     {r.get("year")} | {r.get("title")} | {(r.get("externalIds") or {}).get("ArXiv","")}'[:190])
    except Exception as ex:
        print(f'[S2] {q!r}: ERR {s[:150]}')
    sys.stdout.flush(); time.sleep(15)
    s = get(f'https://zenodo.org/api/records?q={urllib.parse.quote(q)}&size=25')
    open(f'lit/{tag}_{k:02d}_zenodo.json', 'w').write(s)
    try:
        d = json.loads(s); res = d.get('hits', {}).get('hits', [])
        print(f'[Zenodo] {q!r}: total {d.get("hits",{}).get("total")}')
        for r in res[:25]:
            m = r.get('metadata', {})
            print(f'     {m.get("publication_date","")} | {m.get("title")} | {r.get("doi","")} | {"; ".join(c.get("name","") for c in m.get("creators",[])[:3])}'[:190])
    except Exception as ex:
        print(f'[Zenodo] {q!r}: ERR {s[:150]}')
    sys.stdout.flush(); time.sleep(2)
