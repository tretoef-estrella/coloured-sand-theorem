# k4_run.py — K4 comparisons (modes given on the command line).
import sys, random, re, time
from collections import Counter
from fractions import Fraction
from k4_formula import (Fam, Y_total, Y_theoremG, Y_dst_raw, Y_dst_alpha, carries, int_antitonic_fit,
                        real_antitonic_fit, syl_hamming)
from k4_mp import M_moves, M_windows, smith_padic, vpq, q_poly, c_poly, cpow
from k4_formula import vp

INF = float('inf')


def group_from_M(lam, i, e, p, which='moves'):
    """Theorem D_p: S_p(lam) + coker(p^k M)."""
    F = Fam(lam, p)
    M, _ = (M_moves if which == 'moves' else M_windows)(lam, i, e, p)
    ex = smith_padic(M, p)
    G = F.small(); free = 0
    for v in ex:
        if v == INF:
            free += 1
        else:
            G[F.k + v] += 1
    return +G, free


def fmt(G):
    g, fr = G
    return '{' + ', '.join(f'{a}: {c}' for a, c in sorted(g.items())) + '}' + f' free={fr}'


def mode_windows(P, LAMMAX, ES, IS):
    """windows == moves entrywise; deficit law; normalization c = a^((p^h-1)/(p-1)) q_h(y); cost form."""
    nbad = Counter(); ncell = 0; nentries = 0; nfam = 0
    for p in P:
        for lam in range(0, LAMMAX[p] + 1):
            F = Fam(lam, p)
            # deficit law and normalization (independent of e, i)
            q = q_poly(F, p)
            qd = cpow({S: Fraction(v) for S, v in q.items()}, F.dk, F.I)
            nfam += 1
            for D in F.dancers:
                val = vpq(qd.get(D, 0), p)
                want = 0 if not D else F.k - len(D) - min(D)
                if val != want:
                    nbad['deficit'] += 1
            c = c_poly(F, 1, p)
            a = Fraction(-1, p)   # (-1)^(p-1)/(u p), u = -1
            for D in F.dancers:
                yfac = Fraction(1)
                for t in D:
                    b_t = Fraction((-1) ** (p - F.d[t]), -1)
                    yfac *= -b_t * Fraction(-p) ** (1 + F.d[t] * (p ** t - 1) // (p - 1))
                lhs = c.get(D, 0)
                rhs = a ** ((p ** F.k - 1) // (p - 1)) * q.get(D, 0) * yfac
                if lhs != rhs:
                    nbad['normalization'] += 1
            for e in ES:
                for i in IS:
                    Mm, slots = M_moves(lam, i, e, p)
                    Mw, Ds = M_windows(lam, i, e, p)
                    pos = {D: x for x, D in enumerate(slots)}
                    ncell += 1
                    for x, D in enumerate(Ds):
                        for y, Dp in enumerate(Ds):
                            nentries += 1
                            if Mw[x][y] != Mm[pos[D]][pos[Dp]]:
                                nbad['windows!=moves'] += 1
                            # cost form
                            if Dp <= D and Mw[x][y] != 0:
                                v = vpq(Mw[x][y], p)
                                if i >= 1:
                                    m = i - 1
                                    pred = (e * F.K + carries(m, F.K, p) + F.R(m, D, e) - F.R(m + F.K, Dp, e)
                                            + F.gamma(D - Dp))
                                else:
                                    pred = e * F.K + F.Rsharp(D, e) - F.Rsharp(Dp, e) + F.gamma(D - Dp)
                                if v != pred:
                                    nbad['costform'] += 1
                            if Dp <= D and Mw[x][y] == 0 and not (i == 0 and not D):
                                nbad['zero entry in support'] += 1
                            if (not Dp <= D) and Mw[x][y] != 0:
                                nbad['nonzero outside support'] += 1
        print(f'p={p} done: families {nfam}, cells {ncell}, entries {nentries}, failures {dict(nbad)}')
        sys.stdout.flush()
    return nbad


def mode_fit(P, LAMMAX, ES, IS, which='moves'):
    """Theorem 4.4 / TOTAL: Smith of M (moves) + small part vs the closed formula; also integrality of
    the real fits and monotonicity."""
    nbad = 0; ncell = 0; nonint = 0
    for p in P:
        for lam in range(LAMMAX[0], LAMMAX[1] + 1):
            F = Fam(lam, p)
            for e in ES:
                for i in IS:
                    G1 = group_from_M(lam, i, e, p, which)
                    G2 = Y_total(lam, i, e, p)
                    ncell += 1
                    if G1 != G2:
                        nbad += 1
                        if nbad <= 20:
                            print('MISMATCH p', p, 'lam', lam, 'e', e, 'i', i, fmt(G1), 'vs', fmt(G2))
                    # real fit integrality
                    if i >= 1:
                        m = i - 1
                        x = [F.R(m, D, e) - F.R(m + F.K, F.Iset - D, e) for D in F.dancers]
                    else:
                        x = [F.Rsharp(D, e) - F.Rsharp(F.Iset - D, e) for D in F.dancers[1:]]
                    z = real_antitonic_fit(x)
                    if any(v.denominator != 1 for v in z):
                        nonint += 1
        print(f'p={p}: cells {ncell}, mismatches {nbad}, non-integral real fits {nonint}'); sys.stdout.flush()


def mode_theoremG(P, ES, IS):
    nbad = 0; n = 0
    for p in P:
        for lam in range(0, p * p + p):
            for e in ES:
                for i in IS:
                    n += 1
                    a, b = Y_total(lam, i, e, p), Y_theoremG(lam, i, e, p)
                    if a != b:
                        nbad += 1
                        if nbad <= 20:
                            print('MISMATCH G p', p, 'lam', lam, 'e', e, 'i', i, fmt(a), fmt(b))
        print(f'p={p}: closed formula vs Theorem G: cells {n}, mismatches {nbad}'); sys.stdout.flush()


def mode_dst(LAM, AL, IS):
    n = 0; bad_raw = 0; bad_alpha = 0
    for lam in range(0, LAM + 1):
        for i in IS:
            n_raw = Y_dst_raw(lam, i)
            for al in AL:
                n += 1
                t = Y_total(lam, i, al, 2)
                if t != Y_dst_alpha(lam, i, al):
                    bad_alpha += 1
                if al == 1 and t != n_raw:
                    bad_raw += 1
                    if bad_raw <= 10:
                        print('MISMATCH raw', lam, i, fmt(t), fmt(n_raw))
    print(f'p=2: cells {n}; vs DST R-form (alpha={AL}) mismatches {bad_alpha}; '
          f'vs DST raw-clock rule (alpha=1 cells) mismatches {bad_raw}')


def parse_sealed(path):
    out = []
    for l in open(path, encoding='utf-8'):
        m = re.match(r'p=(\d+) lam=(\d+) e=(\d+) i=(\d+) : \{(.*?)\} free=(\d+)', l)
        if m:
            p, lam, e, i = map(int, m.groups()[:4])
            g = Counter()
            if m.group(5).strip():
                for kv in m.group(5).split(','):
                    a, c = kv.split(':')
                    g[int(a)] += int(c)
            out.append(((p, lam, e, i), (+g, int(m.group(6)))))
    return out


def mode_sealed2(N, seed):
    cells = parse_sealed('../material/SEALED_2.txt')
    random.seed(seed)
    pick = random.sample(cells, N) if N < len(cells) else cells
    bad = 0
    for (p, lam, e, i), G in pick:
        if Y_total(lam, i, e, p) != G:
            bad += 1
            print('SEALED_2 MISMATCH', p, lam, e, i)
    print(f'SEALED_2: {len(pick)} cells (seed {seed}), my closed formula == sealed in {len(pick) - bad}, mismatches {bad}')


def mode_sealed1():
    cells = parse_sealed('../material/SEALED_1.txt')
    bad = 0
    for (p, lam, e, i), G in cells:
        if group_from_M(lam, i, e, p, 'moves') != G:
            bad += 1
            print('SEALED_1 MISMATCH', p, lam, e, i)
    print(f'SEALED_1: {len(cells)} cells, my Theorem D_p (moves) == sealed: {len(cells) - bad}, mismatches {bad}')


if __name__ == '__main__':
    mode = sys.argv[1]
    t0 = time.time()
    if mode == 'smoke':
        mode_windows([3, 5], {3: 40, 5: 40}, [1, 2], [0, 1, 4])
        mode_fit([3, 5], (0, 40), [1, 2], [0, 1, 4])
        mode_theoremG([3, 5], [1, 2], [0, 1, 2, 3])
        mode_dst(30, [1, 2], [0, 1, 2, 3])
    elif mode == 'windows':
        mode_windows([3, 5, 7], {3: 120, 5: 160, 7: 120}, [1, 2], [0, 1, 2, 3, 5, 9])
    elif mode == 'fit':
        P = [int(x) for x in sys.argv[2].split(',')]
        lo = int(sys.argv[3]); hi = int(sys.argv[4])
        mode_fit(P, (lo, hi), [1, 2, 3], [0, 1, 2, 3, 4, 7, 10, 26, 27, 28, 80, 81, 82, 242, 243])
    elif mode == 'G':
        mode_theoremG([3, 5, 7, 11, 13], [1, 2, 3], list(range(0, 15)))
    elif mode == 'dst':
        mode_dst(200, [1, 2, 3, 4], list(range(0, 9)))
    elif mode == 'sealed2':
        mode_sealed2(int(sys.argv[2]), int(sys.argv[3]))
    elif mode == 'sealed1':
        mode_sealed1()
    print(f'[{time.time() - t0:.1f}s]')
