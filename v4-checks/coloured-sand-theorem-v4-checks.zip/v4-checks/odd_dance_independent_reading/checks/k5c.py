# the blocks extracted by the previous reader (PREVIOUS_COLD_READING_OF_v3.md, K9) vs my closed formula
from collections import Counter
from k4_formula import Y_total
data = [  # (lam, q, c, e, {exp: count}, free)
 (12, 9, 0, 2, {1: 8, 12: 1, 17: 1, 23: 1}, 1), (12, 9, 1, 2, {1: 8, 14: 1, 16: 1, 24: 1, 26: 1}, 0),
 (12, 9, 2, 2, {1: 8, 14: 1, 16: 1, 24: 1, 26: 1}, 0), (12, 9, 3, 2, {1: 8, 13: 1, 17: 1, 23: 1, 27: 1}, 0),
 (12, 3, 4, 1, {1: 8, 9: 2, 13: 2}, 0), (12, 3, 5, 1, {1: 8, 9: 2, 13: 2}, 0), (12, 3, 6, 1, {1: 8, 7: 1, 10: 1, 12: 1, 15: 1}, 0),
 (12, 27, 2, 3, {1: 8, 19: 1, 23: 1, 35: 1, 39: 1}, 0),
 (12, 3, 0, 1, {1: 8, 7: 1, 10: 1, 12: 1}, 1), (12, 3, 1, 1, {1: 8, 9: 2, 13: 2}, 0), (12, 6, 3, 1, {1: 8, 8: 1, 10: 1, 12: 1, 14: 1}, 0),
 (13, 3, 0, 1, {1: 8, 6: 1, 11: 2}, 1), (13, 3, 1, 1, {1: 8, 8: 1, 10: 1, 12: 1, 14: 1}, 0), (13, 9, 1, 2, {1: 8, 12: 1, 18: 1, 22: 1, 28: 1}, 0)]
ok = 0
for lam, q, c, e, g, fr in data:
    mine = Y_total(lam, c, e, 3)   # block at k0 = 0, so i = c
    good = (mine == (Counter(g), fr))
    ok += good
    print(lam, q, c, e, 'previous reader', g, fr, '| closed formula', dict(sorted(mine[0].items())), mine[1], '|', 'AGREE' if good else 'DISAGREE')
print(f'{ok}/{len(data)} agree')
