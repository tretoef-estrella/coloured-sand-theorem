
Summary of my computations (every engine is my own, written from the printed definitions; logs end with `VIGIA-FIN-OK` unless stated; details, estimates and slips are in the step log below):
- **K1** — `checks/lat.py`, `k1.py`, `k1_controls.py`, `k1b.py`: 569 lattices, all checks 0 failures; controls fire (coupling p² / 0: 84/84 each; twist without p: 18/23, 5 vacuous). Closed `E^{(r)}` and reductions: 273812 pairs.
- **K2** — `checks/k2.py`: 62/62 identified as `T(λ)` by tilting + local End (no Donkin); controls fire.
- **K3** — `checks/psmith.c`, `psmith128.c`, `k3.py`: predictions sealed in `checks/K3_PREDICTIONS.txt` (22:12:35, md5 `fb7cf75162e4f9dadfa0224f4180b862`) then computed: **31/31 agree, 0 disagree**; engine validated on 41 + 16 + 40 proved-range cells.
- **K4** — `checks/k4_formula.py`, `k4_mp.py`, `k4_run.py`, `k4_fast.py`, `k4_control.py`: formula = Theorem G (18540), = DST (7236), = SEALED_2 (all 10710; random 300), SEALED_1 = my moves (1520/1520), windows = moves (4836 cells), Smith(`M_p`) + small part = formula on ≈ 34000 cells (p = 3: λ ≤ 360 and 381–390 plus the parts of 361–400 listed in STEP 6c; p = 5, 7: λ ≤ 400); 0 mismatches; controls fire.
- **K5** — `checks/k5.py`: 12/12 Hamming groups (d ≥ p²+p) match Kirchhoff + 𝔽_p-rank; control fires; `k5b`, `k5c`: report's H(12,3), [CS3] §10, previous reader's 14 blocks reproduced.
- **K6** — `checks/k6.py`: 47310 houses, 0 failures, four types occur, controls fire.
- **K7** — `checks/k7_md5.py`: md5 match.
