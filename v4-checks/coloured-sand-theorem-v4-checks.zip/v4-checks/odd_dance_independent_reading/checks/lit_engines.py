# lit_engines.py — keyword searches in several open scholarly APIs; raw answers saved in checks/lit/,
# hit counts and titles printed.  Engines: zbMATH Open, Semantic Scholar, Zenodo, HAL, StackExchange
# (MathOverflow, Math.SE), GitHub (repositories), OpenAlex (search).  No personal data is sent.
import json, subprocess, sys, time, urllib.parse
QUERIES = json.load(open(sys.argv[1])); tag = sys.argv[2]
def get(url, hdr=None):
    cmd = ['curl', '-sS', '-m', '60', '--compressed', url]
    if hdr: cmd[1:1] = ['-H', hdr]
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.stdout
def show(eng, q, n, items, path):
    print(f'[{eng}] {q!r}: {n} hits  (saved {path})')
    for it in items[:25]: print('     ' + str(it)[:190])
    sys.stdout.flush()
k = 0
for q in QUERIES:
    k += 1; qq = urllib.parse.quote(q)
    # zbMATH Open
    p = f'lit/{tag}_{k:02d}_zbmath.json'; s = get(f'https://api.zbmath.org/v1/document/_search?search_string={qq}&page=0&results_per_page=50'); open(p, 'w').write(s)
    try:
        d = json.loads(s); res = d.get('result', []) or []; n = d.get('status', {}).get('nr_total_results', len(res))
        items = [f"{r.get('year','')} | {(r.get('title') or {}).get('title','') if isinstance(r.get('title'),dict) else r.get('title')} | {r.get('identifier','')}" for r in res]
    except Exception as ex:
        n, items = f'ERR {ex}', [s[:200]]
    show('zbMATH', q, n, items, p); time.sleep(1)
    # Semantic Scholar
    p = f'lit/{tag}_{k:02d}_s2.json'; s = get(f'https://api.semanticscholar.org/graph/v1/paper/search?query={qq}&limit=50&fields=title,year,externalIds'); open(p, 'w').write(s)
    try:
        d = json.loads(s); res = d.get('data', []) or []; n = d.get('total', len(res))
        items = [f"{r.get('year')} | {r.get('title')} | {(r.get('externalIds') or {}).get('ArXiv','')}" for r in res]
    except Exception as ex:
        n, items = f'ERR {ex}', [s[:200]]
    show('SemanticScholar', q, n, items, p); time.sleep(3)
    # Zenodo
    p = f'lit/{tag}_{k:02d}_zenodo.json'; s = get(f'https://zenodo.org/api/records?q={urllib.parse.quote(chr(34)+q+chr(34))}&size=50'); open(p, 'w').write(s)
    try:
        d = json.loads(s); res = d.get('hits', {}).get('hits', []); n = d.get('hits', {}).get('total')
        items = [f"{r.get('metadata',{}).get('publication_date','')} | {r.get('metadata',{}).get('title')} | {r.get('doi','')}" for r in res]
    except Exception as ex:
        n, items = f'ERR {ex}', [s[:200]]
    show('Zenodo', q, n, items, p); time.sleep(1)
    # HAL
    p = f'lit/{tag}_{k:02d}_hal.json'; s = get(f'https://api.archives-ouvertes.fr/search/?q={urllib.parse.quote(chr(34)+q+chr(34))}&rows=50&fl=title_s,producedDateY_i,uri_s&wt=json'); open(p, 'w').write(s)
    try:
        d = json.loads(s); res = d.get('response', {}).get('docs', []); n = d.get('response', {}).get('numFound')
        items = [f"{r.get('producedDateY_i','')} | {(r.get('title_s') or [''])[0]} | {r.get('uri_s','')}" for r in res]
    except Exception as ex:
        n, items = f'ERR {ex}', [s[:200]]
    show('HAL', q, n, items, p); time.sleep(1)
    # StackExchange: MathOverflow and Math.SE
    for site in ('mathoverflow', 'math'):
        p = f'lit/{tag}_{k:02d}_se_{site}.json'; s = get(f'https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q={qq}&site={site}&pagesize=50'); open(p, 'w').write(s)
        try:
            d = json.loads(s); res = d.get('items', []); n = len(res)
            items = [f"{r.get('creation_date')} | {r.get('title')} | {r.get('link')}" for r in res]
        except Exception as ex:
            n, items = f'ERR {ex}', [s[:200]]
        show('SE-' + site, q, n, items, p); time.sleep(1)
    # GitHub repositories
    p = f'lit/{tag}_{k:02d}_github.json'; s = get(f'https://api.github.com/search/repositories?q={qq}&per_page=50', 'Accept: application/vnd.github+json'); open(p, 'w').write(s)
    try:
        d = json.loads(s); res = d.get('items', []); n = d.get('total_count')
        items = [f"{r.get('full_name')} | {r.get('description')}" for r in res]
    except Exception as ex:
        n, items = f'ERR {ex}', [s[:200]]
    show('GitHub', q, n, items, p); time.sleep(6)
