# k4_control.py — controls for K4: deliberately wrong variants of the closed formula must disagree with the
# Smith form of M_p (moves): (a) no pooling (raw clocks); (b) K := p^k instead of d_k p^k; (c) kappa_p(i, K)
# instead of kappa_p(i-1, K); (d) small part without the (Z/p^k)^{(d_k-1)2^|I|} term.
import sys
from collections import Counter
from k4_formula import Fam, carries, int_antitonic_fit
from k4_run import group_from_M

def Y_variant(lam, i, e, p, var):
    F = Fam(lam, p)
    G = F.small()
    if var == 'd':
        if F.k >= 1 and F.dk > 1:
            G[F.k] -= (F.dk - 1) * 2 ** len(F.I)
    K = p ** F.k if var == 'b' else F.K
    if i >= 1:
        m = i - 1
        x = [F.R(m, D, e) - F.R(m + K, F.Iset - D, e) for D in F.dancers]
        y = x if var == 'a' else int_antitonic_fit(x)
        base = F.k + e * K + carries(m + (1 if var == 'c' else 0), K, p)
        for v in y:
            G[base + v] += 1
        return +G, 0
    x = [F.Rsharp(D, e) - F.Rsharp(F.Iset - D, e) for D in F.dancers[1:]]
    y = x if var == 'a' else int_antitonic_fit(x)
    for v in y:
        G[F.k + e * K + v] += 1
    return +G, 1

for var in 'abcd':
    n = 0; bad = 0
    for p in (3, 5):
        for lam in range(0, 120 if p == 3 else 160):
            for e in (1, 2):
                for i in (0, 1, 2, 4, 9):
                    n += 1
                    if Y_variant(lam, i, e, p, var) != group_from_M(lam, i, e, p):
                        bad += 1
    print(f'control {var}: {bad} of {n} cells differ from Smith(M_p) + small part')
    sys.stdout.flush()
