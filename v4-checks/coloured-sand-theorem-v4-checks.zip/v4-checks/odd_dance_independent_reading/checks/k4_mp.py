# k4_mp.py — Grepy el Jurado.  The final matrix M_p(lam, i, e) two ways, exact rationals:
#   (moves)   the recursion of Props 2.1 (twist), 2.2 (split), 2.3 (last level) as printed;
#   (windows) Theorem 4.1: c^(h) recursion, windows of payments, last power d_k;
# plus the q-polynomial normalization, the deficit law (Lemma 4.2), the cost form (Prop 4.3),
# and an exact p-adic Smith form.  u = -1.
from fractions import Fraction
from functools import lru_cache
from math import factorial
from k4_formula import Fam, carries, vp as vpi

U = -1


def vpq(x, p):
    """p-adic valuation of a rational (inf for 0)."""
    if x == 0:
        return float('inf')
    x = Fraction(x)
    return vpi(x.numerator, p) - vpi(x.denominator, p)


def matmul(A, B):
    n, m, l = len(A), len(B), len(B[0])
    return [[sum(A[a][c] * B[c][b] for c in range(m) if A[a][c] and B[c][b]) for b in range(l)] for a in range(n)]


def M_moves(lam, i, e, p):
    """returns (M, slot list of dancers) — M rows = generator slots, cols = relation slots."""
    F = Fam(lam, p)
    k, d = F.k, F.d
    a = Fraction((-1) ** (p - 1), U * p)
    # slots after h moves: list of dancers (frozensets) in the order produced by the moves
    slots = [frozenset()]
    levels = []  # (type, r) per digit t
    for t in range(k):
        levels.append(('twist', 0) if d[t] == 0 else ('split', d[t]))

    @lru_cache(maxsize=None)
    def P(h, f):
        if h == 0:
            return ((Fraction(p ** e * (f + i)),),)
        typ, r = levels[h - 1]
        prev = lambda g: [list(row) for row in P(h - 1, g)]
        if typ == 'twist':
            X = prev(p * f)
            for j in range(1, p):
                X = matmul(X, prev(p * f + j))
            return tuple(tuple(a * x for x in row) for row in X)
        QA = prev(p * f)
        for j in range(1, p):
            QA = matmul(QA, prev(p * f + j))
        QC = prev(p * f + r)
        for j in range(1, p):
            QC = matmul(QC, prev(p * f + r + j))
        KK = prev(p * f + r)
        for j in range(r + 1, p):
            KK = matmul(KK, prev(p * f + j))
        b = Fraction((-1) ** (p - r), U)
        R = len(QA)
        out = [[Fraction(0)] * (2 * R) for _ in range(2 * R)]
        for x in range(R):
            for y in range(R):
                out[x][y] = a * QA[x][y]
                out[R + x][R + y] = a * QC[x][y]
                out[R + x][y] = b * KK[x][y]
        return tuple(tuple(row) for row in out)

    for t in range(k):
        typ, r = levels[t]
        if typ == 'split':
            slots = slots + [s | {t} for s in slots]
    dk = d[k]
    M = [list(row) for row in P(k, 0)]
    for f in range(1, dk):
        M = matmul(M, [list(row) for row in P(k, f)])
    sc = Fraction((-1) ** (dk - 1), factorial(dk - 1))
    M = [[sc * x for x in row] for row in M]
    return M, slots


def cpow(c, n, I):
    """power in Q[x_t]/(x_t^2), c a dict frozenset -> Fraction."""
    out = {frozenset(): Fraction(1)}
    for _ in range(n):
        new = {}
        for A_, ca in out.items():
            for B_, cb in c.items():
                if A_ & B_:
                    continue
                S = A_ | B_
                new[S] = new.get(S, 0) + ca * cb
        out = {S: v for S, v in new.items() if v != 0}
    return out


def c_poly(F, e, p):
    a = Fraction((-1) ** (p - 1), U * p)
    c = {frozenset(): Fraction(1)}
    for h in range(F.k):
        cp = cpow(c, p, F.I)
        new = {S: a * v for S, v in cp.items()}
        if h in F.I:
            b = Fraction((-1) ** (p - F.d[h]), U)
            cq = cpow(c, p - F.d[h], F.I)
            for S, v in cq.items():
                S2 = S | {h}
                new[S2] = new.get(S2, 0) + b * v
        c = {S: v for S, v in new.items() if v != 0}
    return c


def q_poly(F, p):
    q = {frozenset(): 1}
    for t in range(F.k):
        qp = cpow(q, p, F.I)
        new = dict(qp)
        if t in F.I:
            qq = cpow(q, p - F.d[t], F.I)
            for S, v in qq.items():
                new[S | {t}] = new.get(S | {t}, 0) - v
        q = {S: v for S, v in new.items() if v != 0}
    return q


def M_windows(lam, i, e, p):
    F = Fam(lam, p)
    c = c_poly(F, e, p)
    cd = cpow(c, F.dk, F.I)
    sc = Fraction((-1) ** (F.dk - 1), factorial(F.dk - 1))
    Ds = F.dancers
    M = [[Fraction(0)] * len(Ds) for _ in Ds]
    for x, D in enumerate(Ds):
        for y, Dp in enumerate(Ds):
            if not Dp <= D:
                continue
            coef = cd.get(D - Dp, 0)
            prod = Fraction(1)
            for dd in range(F.o(D), F.o(Dp) + F.K):
                prod *= p ** e * (i + dd)
            M[x][y] = sc * coef * prod
    return M, Ds


def smith_padic(M, p):
    """exact p-adic Smith exponents of a rational square matrix (inf for zero invariant factors)."""
    A = [[Fraction(x) for x in row] for row in M]
    n = len(A)
    ex = []
    rows = list(range(n)); cols = list(range(n))
    while rows:
        best = None
        for r_ in rows:
            for c_ in cols:
                if A[r_][c_] != 0:
                    v = vpq(A[r_][c_], p)
                    if best is None or v < best[0]:
                        best = (v, r_, c_)
        if best is None:
            ex += [float('inf')] * len(rows)
            break
        v, r0, c0 = best
        ex.append(v)
        piv = A[r0][c0]
        for r_ in rows:
            if r_ != r0 and A[r_][c0] != 0:
                f = A[r_][c0] / piv
                A[r_] = [A[r_][c] - f * A[r0][c] for c in range(n)]
        rows.remove(r0); cols.remove(c0)
    return sorted(ex)
