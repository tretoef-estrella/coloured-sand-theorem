# openalex_cites.py — for each seed work (searched by title in OpenAlex), list every work citing it
# (OpenAlex filter cites:W...), save the lists in checks/lit/, print titles.  No personal data is sent.
import json, sys, time, subprocess, urllib.parse
seeds = json.load(open(sys.argv[1])); tag = sys.argv[2]
def get(url):
    r = subprocess.run(['curl', '-sS', '-m', '60', url], capture_output=True, text=True)
    return json.loads(r.stdout)
for n, (label, title) in enumerate(seeds, 1):
    q = get('https://api.openalex.org/works?' + urllib.parse.urlencode({'search': title, 'per-page': 5}))
    res = q.get('results', [])
    if not res:
        print(f'[{tag}{n}] {label}: seed NOT FOUND in OpenAlex'); continue
    w = res[0]
    wid = w['id'].split('/')[-1]
    print(f'[{tag}{n}] {label}: seed {wid} «{w.get("display_name")}» ({w.get("publication_year")}), cited_by_count {w.get("cited_by_count")}')
    cites = []; cursor = '*'
    while cursor:
        r = get('https://api.openalex.org/works?' + urllib.parse.urlencode({'filter': f'cites:{wid}', 'per-page': 200, 'cursor': cursor}))
        cites += r.get('results', [])
        cursor = r.get('meta', {}).get('next_cursor')
        if not r.get('results'): break
        time.sleep(0.5)
    lines = []
    for c in sorted(cites, key=lambda c: c.get('publication_year') or 0):
        doi = c.get('doi') or ''
        lines.append(f'{c.get("publication_year")} | {c.get("display_name")} | {doi} | {c["id"].split("/")[-1]}')
    open(f'lit/{tag}{n:02d}_{label}.txt', 'w').write(f'seed {wid} {w.get("display_name")}\n' + '\n'.join(lines) + '\n')
    print(f'    citing works found: {len(cites)}')
    for l in lines:
        print('    ' + l[:180])
    sys.stdout.flush(); time.sleep(1)
