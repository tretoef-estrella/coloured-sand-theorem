# DOWNLOADS — Grepy el Jurado, COLOURED_SAND_2 (JOB 3)
Every file I downloaded (each in its own folder under `checks/downloads/`), with the time from `date` taken in the same command, and its md5. Nothing downloaded was executed; PDFs were only converted to text with `pdftotext` (under the watchdog). Raw API answers (JSON/XML search results, metadata) are under `checks/lit/` and listed in `checks/SEARCHES.md`, not here.

| # | time (date) | URL | local file | md5 | what / why |
|---|---|---|---|---|---|
| D1 | Tue Oct 13 22:47:24 CEST 2026 | https://www.numdam.org/item/ASENS_1997_4_30_3_353_0.pdf | `checks/downloads/Andersen1997/ASENS_1997_4_30_3_353_0.pdf` | 2b9cc4a1c4519ae710d4daab8f111bc4 | H. H. Andersen, «Filtrations and tilting modules», Ann. Sci. ÉNS (4) 30 (1997) 353–366 (Numdam, open). §1.2: lifts of Weyl, induced and tilting modules to G over Z_p; T_{Z_p}(λ) unique, T_{Z_p}(λ) ⊗ k ≅ T_k(λ), every tilting G_{Z_p}-module decomposes uniquely; «the Ringel construction (which even works over Z, see [Do])». §1.3–1.4: a Jantzen-type filtration of Hom(V_{Z_p}(λ), Q) defined by elementary divisors of a pairing. |
