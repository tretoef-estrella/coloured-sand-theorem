# k4_formula.py — Grepy el Jurado.  Theorem TOTAL re-implemented from the notation of PASO 4 of
# material/REPORT_ODD_DANCE.md ONLY (lines 178, 201-205), plus independent references:
#   * Theorem G of [CS3] §6 (block groups G_c(m, lam), lam <= p^2+p-1), my implementation from the text;
#   * [DST] §1.2 raw-clock rule (alpha = 1, p = 2) and the R-form of [DST] Thm 7.10 / [CS3] §7 (any alpha);
#   * n_lam(m) by peeling Donkin characters off (z + 1/z)^m.
# Groups are returned as (Counter {exponent: count}, free) with zero exponents dropped.
from fractions import Fraction
from collections import Counter
from math import comb


def digits(x, p):
    d = []
    while x:
        d.append(x % p); x //= p
    return d


def vp(x, p):
    if x == 0:
        return float('inf')
    v = 0
    while x % p == 0:
        x //= p; v += 1
    return v


def carries(a, b, p):
    """kappa_p(a, b): number of carries of a + b in base p (a, b >= 0)."""
    c = 0; n = 0
    while a or b or c:
        s = a % p + b % p + c
        c = 1 if s >= p else 0
        n += c
        a //= p; b //= p
    return n


def int_antitonic_fit(x):
    """[DST] §1.2: PAVA into consecutive blocks with strictly decreasing means (equal means merged),
    then each block of n positions with sum S -> (S mod n) copies of ceil(S/n), then floors."""
    blocks = []  # [sum, count]
    for v in x:
        blocks.append([v, 1])
        while len(blocks) >= 2 and blocks[-2][0] * blocks[-1][1] <= blocks[-1][0] * blocks[-2][1]:
            s, c = blocks.pop()
            blocks[-1][0] += s; blocks[-1][1] += c
    out = []
    for S, n in blocks:
        q, r = divmod(S, n)
        out += [q + 1] * r + [q] * (n - r)
    return out


def real_antitonic_fit(x):
    blocks = []
    for v in x:
        blocks.append([Fraction(v), 1])
        while len(blocks) >= 2 and blocks[-2][0] * blocks[-1][1] <= blocks[-1][0] * blocks[-2][1]:
            s, c = blocks.pop()
            blocks[-1][0] += s; blocks[-1][1] += c
    out = []
    for S, n in blocks:
        out += [S / n] * n
    return out


class Fam:
    """the data of PASO 4: lam+1 = sum d_t p^t, K = d_k p^k, I, h_t, o_D, dancers in o-order."""
    def __init__(self, lam, p):
        self.lam, self.p = lam, p
        d = digits(lam + 1, p)
        self.d = d; self.k = k = len(d) - 1; self.dk = d[k]
        self.K = d[k] * p ** k
        self.I = [t for t in range(k) if d[t] != 0]
        nxt = {}
        for a, t in enumerate(self.I):
            nxt[t] = self.I[a + 1] if a + 1 < len(self.I) else k
        self.h = {t: nxt[t] - t for t in self.I}
        D = []
        for mask in range(1 << len(self.I)):
            D.append(frozenset(self.I[j] for j in range(len(self.I)) if mask >> j & 1))
        self.o = lambda E: sum(d[t] * p ** t for t in E)
        D.sort(key=self.o)
        self.dancers = D
        self.Iset = frozenset(self.I)

    def small(self):
        p, k, dk, nI = self.p, self.k, self.dk, len(self.I)
        S = Counter()
        for h in range(1, k):
            S[h] += (p - 1) * dk * p ** (k - h - 1) * 2 ** nI
        if k >= 1 and dk > 1:
            S[k] += (dk - 1) * 2 ** nI
        return +S

    def R(self, mu, E, e):
        return sum(self.h[t] - e * self.d[t] * self.p ** t for t in E) - carries(mu, self.o(E), self.p)

    def Rsharp(self, E, e):
        if not E:
            return 0
        return sum(self.h[t] - e * self.d[t] * self.p ** t for t in E) - (self.k - min(E))

    def gamma(self, Dl):
        if not Dl:
            return 0
        mn = min(Dl)
        return sum(self.h[u] for u in self.I if u not in Dl and u > mn)


def Y_total(lam, i, e, p):
    """Theorem TOTAL (report PASO 4(c)), from the printed notation."""
    F = Fam(lam, p)
    G = F.small()
    free = 0
    if i >= 1:
        m = i - 1
        x = [F.R(m, D, e) - F.R(m + F.K, F.Iset - D, e) for D in F.dancers]
        y = int_antitonic_fit(x)
        base = F.k + e * F.K + carries(m, F.K, p)
        for v in y:
            G[base + v] += 1
    else:
        free = 1
        Ds = F.dancers[1:]
        x = [F.Rsharp(D, e) - F.Rsharp(F.Iset - D, e) for D in Ds]
        y = int_antitonic_fit(x)
        for v in y:
            G[F.k + e * F.K + v] += 1
    return +G, free


# ---------------- Theorem G of [CS3] §6 (my implementation from the text) -----------------
def Y_theoremG(lam, i, e, p):
    """Y_p(lam, i, e) for lam <= p^2+p-1 by [CS3] (T2), Lemma 8 and the definition of G_c(m, lam),
    with v_t = e + v_p(i + t) (i = c + k), v_0 = inf when i = 0."""
    assert lam <= p * p + p - 1
    INF = float('inf')
    v = [e + vp(i + t, p) if (i + t) != 0 else INF for t in range(lam + 1)]
    A = sum(v)
    zero = (i == 0)
    if lam <= p - 1:
        return (Counter(), 1) if zero else (Counter({A: 1}), 0)
    if (lam + 1) % p == 0 and lam <= p * p - 1:
        a = (lam + 1) // p - 1
        G = Counter({1: a}) if a else Counter()
        if zero:
            return +G, 1
        G[A - a] += 1
        return +G, 0
    # two Weyl factors: lam = p-1+r+p a, 1 <= r <= p (r = p only for lam = p^2+p-1)
    if lam == p * p + p - 1:
        r, a = p, p - 1
    else:
        r = (lam - (p - 1)) % p
        a = (lam - (p - 1)) // p
        assert 1 <= r <= p - 1 and 0 <= a <= p - 1
    lm = lam - 2 * r
    Ap = sum(v[r:r + lm + 1])
    alpha = sum(v[(a + 1) * p:lam + 1])
    tau = 1 + (a == p - 1)
    E12 = Ap - a + tau
    E22 = Ap - a + alpha
    G = Counter({1: 2 * a}) if a else Counter()
    if zero:
        G[min(E12, E22)] += 1
        return +G, 1
    E11 = A - alpha - a
    x = min(E11, E12, E22); y = E11 + E22 - x
    G[x] += 1; G[y] += 1
    return +G, 0


# ---------------- [DST] rules, p = 2 -----------------
def phi2(x):
    return x + vp(x, 2)


def Y_dst_raw(lam, i):
    """[DST] §1.2 (alpha = 1): small clocks and raw clocks u_i(D) = phi(xi_D) + kappa(i+o_D-1, xi_D) + h(D),
    xi_D = lam + 1 - 2 o_D, pooled in o-order; u_0(empty) = inf stands first, not pooled."""
    F = Fam(lam, 2)
    G = Counter()
    for a in range(1, F.k):
        G[a] += 2 ** (len(F.I) + F.k - 1 - a)
    u = []
    for D in F.dancers:
        if i == 0 and not D:
            continue
        xi = lam + 1 - 2 * F.o(D)
        u.append(phi2(xi) + carries(i + F.o(D) - 1, xi, 2) + sum(F.h[t] for t in D))
    for v in int_antitonic_fit(u):
        G[v] += 1
    return +G, (1 if i == 0 else 0)


def Y_dst_alpha(lam, i, alpha):
    """[DST] Thm D + Thm 7.10 (as transcribed in [CS3] §7), any alpha >= 1."""
    F = Fam(lam, 2)
    G = Counter()
    for a in range(1, F.k):
        G[a] += 2 ** (len(F.I) + F.k - 1 - a)
    K = F.K
    def R(mu, E):
        return sum(F.h[t] - alpha * 2 ** t for t in E) - carries(mu, F.o(E), 2)
    if i >= 1:
        m = i - 1
        x = [R(m, D) - R(m + K, F.Iset - D) for D in F.dancers]
        for v in int_antitonic_fit(x):
            G[F.k + alpha * K + carries(m, K, 2) + v] += 1
        return +G, 0
    def Rs(E):
        return sum(F.h[t] - alpha * 2 ** t for t in E) - carries(K - 1, F.o(E), 2)
    x = [Rs(D) - Rs(F.Iset - D) for D in F.dancers[1:]]
    for v in int_antitonic_fit(x):
        G[F.k + alpha * K + v] += 1
    return +G, 1


# ---------------- multiplicities and the Hamming assembly -----------------
def ch_T(lam, p):
    d = digits(lam + 1, p); k = len(d) - 1
    ch = Counter({0: 1})
    def mul(a, b):
        out = Counter()
        for x, c in a.items():
            for y, e_ in b.items():
                out[x + y] += c * e_
        return +out
    for t in range(k):
        ch = mul(ch, Counter({p ** t * (p - 1 - 2 * j): 1 for j in range(p)}))
        if d[t]:
            ch = mul(ch, Counter({d[t] * p ** t: 1, -d[t] * p ** t: 1}))
    ch = mul(ch, Counter({p ** k * (d[k] - 1 - 2 * j): 1 for j in range(d[k])}))
    return ch


_nl_cache = {}
def n_lambda(m, p):
    if (m, p) in _nl_cache:
        return _nl_cache[(m, p)]
    ch = Counter({m - 2 * s: comb(m, s) for s in range(m + 1)})
    out = {}
    for lam in range(m, -1, -2):
        c = ch.get(lam, 0)
        if c < 0:
            raise ValueError('negative multiplicity')
        if c:
            out[lam] = c
            for w, mult in ch_T(lam, p).items():
                ch[w] -= c * mult
    assert all(v == 0 for v in ch.values())
    _nl_cache[(m, p)] = out
    return out


def syl_hamming(d, q, p, Yfun=Y_total, e_override=None):
    """Theorem TOTAL assembly: Z_p + Syl_p K(H(d,q)); returns (Counter, free)."""
    e = vp(q, p) if e_override is None else e_override
    assert e >= 1
    tot = Counter(); free = 0
    for j in range(d + 1):
        mult_j = comb(d, j) * (q - 2) ** j
        if mult_j == 0:
            continue
        m = d - j
        for lam, nl in n_lambda(m, p).items():
            i = j + (m - lam) // 2
            G, fr = Yfun(lam, i, e, p)
            for a, c in G.items():
                tot[a] += c * nl * mult_j
            free += fr * nl * mult_j
    return +tot, free
