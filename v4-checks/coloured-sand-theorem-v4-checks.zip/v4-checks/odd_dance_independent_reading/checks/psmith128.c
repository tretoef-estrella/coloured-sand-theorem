/* psmith128.c — Grepy el Jurado, COLOURED_SAND_2, K3.  Same algorithm as psmith.c (exact p-adic Smith form of
   q(c+H)+U on B_m, level-by-level unit-pivot elimination, Markowitz-like choice), but with 128-bit storage and
   Montgomery arithmetic modulo N = p^M < 2^127 (p odd), so that exponents up to M-1 (M = 80 for p = 3) are
   computed directly, without the inverse matrix.  Values are kept in Montgomery form xR mod N (R = 2^128); since R
   is a unit mod p, valuations and divisibility by p are read off the Montgomery representative directly.
   usage: psmith128 p M m c q        output: "exp count" lines, "ge_M count", "time t". */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

typedef unsigned __int128 u128;
static u128 N, NP, R1, R2, R3, TWO;   /* NP = -N^{-1} mod 2^128; R1 = R mod N; R2 = R^2 mod N; R3 = R^3 mod N */
static uint64_t P; static int MM;

static inline void mul128(u128 a, u128 b, u128 *hi, u128 *lo) {
    uint64_t a0 = (uint64_t)a, a1 = (uint64_t)(a >> 64), b0 = (uint64_t)b, b1 = (uint64_t)(b >> 64);
    u128 p00 = (u128)a0 * b0, p01 = (u128)a0 * b1, p10 = (u128)a1 * b0, p11 = (u128)a1 * b1;
    u128 mid = (p00 >> 64) + (uint64_t)p01 + (uint64_t)p10;
    *lo = (mid << 64) | (uint64_t)p00;
    *hi = p11 + (p01 >> 64) + (p10 >> 64) + (mid >> 64);
}
static inline u128 mullo(u128 a, u128 b) { /* a*b mod 2^128 */
    uint64_t a0 = (uint64_t)a, a1 = (uint64_t)(a >> 64), b0 = (uint64_t)b, b1 = (uint64_t)(b >> 64);
    u128 p00 = (u128)a0 * b0;
    u128 cross = (u128)((uint64_t)((u128)a0 * b1) + (uint64_t)((u128)a1 * b0));
    return p00 + (cross << 64);
}
static inline u128 mont(u128 a, u128 b) {
    u128 hi, lo; mul128(a, b, &hi, &lo);
    u128 m = mullo(lo, NP);
    u128 mh, ml; mul128(m, N, &mh, &ml);
    u128 s = lo + ml; u128 carry = (s < lo) ? 1 : 0;   /* s == 0 by construction; carry iff lo != 0 */
    u128 u = hi + mh + carry;                            /* < 2N < 2^128 since N < 2^127 */
    if (u >= N) u -= N;
    return u;
}
static inline u128 addm(u128 a, u128 b) { u128 s = a + b; if (s >= N) s -= N; return s; }
static inline u128 subm(u128 a, u128 b) { return a >= b ? a - b : a + N - b; }
static u128 to_mont(u128 x) { return mont(x % N, R2); }
static int vp128(u128 x) { if (x == 0) return 1000; int v = 0; while (x % P == 0) { x /= P; v++; } return v; }
static u128 mont_inv(u128 xt) {
    /* unit x (Montgomery form xt); find yt with mont(xt, yt) = R1. Start mod p, Newton. */
    uint64_t xr = (uint64_t)(xt % P);                 /* = x R mod p */
    uint64_t rp = (uint64_t)(R1 % P);                 /* R mod p */
    uint64_t rinv = 1, b = rp, e = P - 2; while (e) { if (e & 1) rinv = rinv * b % P; b = b * b % P; e >>= 1; }
    uint64_t x = xr * rinv % P;                       /* x mod p */
    uint64_t xi = 1; b = x; e = P - 2; while (e) { if (e & 1) xi = xi * b % P; b = b * b % P; e >>= 1; }
    u128 yt = (u128)(xi * rp % P);                    /* x^{-1} R mod p */
    for (int it = 0; it < 8; it++) { u128 t = mont(xt, yt); yt = mont(yt, subm(TWO, t)); }
    return yt;
}

int main(int argc, char **argv) {
    if (argc < 6) { fprintf(stderr, "usage: psmith128 p M m c q\n"); return 1; }
    P = strtoull(argv[1], 0, 10); MM = atoi(argv[2]); int m = atoi(argv[3]); long long c = atoll(argv[4]); long long q = atoll(argv[5]);
    if (P % 2 == 0) { fprintf(stderr, "p must be odd\n"); return 1; }
    N = 1; for (int i = 0; i < MM; i++) { if (N > (((u128)1 << 126) / P)) { fprintf(stderr, "p^M too large\n"); return 1; } N *= P; }
    /* NP = -N^{-1} mod 2^128 by Newton (N odd) */
    u128 inv = 1; for (int i = 0; i < 8; i++) inv = mullo(inv, (u128)2 - mullo(N, inv));
    NP = (u128)0 - inv;
    /* R1 = 2^128 mod N, R2 = R^2 mod N, R3 */
    R1 = ((u128)0 - N) % N;  /* (2^128 - N) mod N = 2^128 mod N */
    { u128 r = R1; for (int i = 0; i < 128; i++) r = addm(r, r); R2 = r; }   /* R * 2^128 mod N */
    R3 = mont(R2, R2);  /* R^2 R^2 / R = R^3 */
    TWO = addm(R1, R1);
    int n = 1 << m;
    clock_t t0 = clock();
    u128 *a = calloc((size_t)n * n, sizeof(u128));
    if (!a) { fprintf(stderr, "alloc failed\n"); return 1; }
    u128 ONE = R1;
    for (int S = 0; S < n; S++) {
        int s = __builtin_popcount(S);
        long long d = q * (c + s); u128 dv = (u128)(d % (long long)1); (void)dv;
        u128 val = (u128)(unsigned long long)(d >= 0 ? d : -d);
        u128 vm = to_mont(val); if (d < 0) vm = subm(0, vm);
        a[(size_t)S * n + S] = vm;
        for (int x = 0; x < m; x++) if (!(S >> x & 1)) a[(size_t)(S | 1 << x) * n + S] = ONE;
    }
    char *rowact = malloc(n), *colact = malloc(n);
    memset(rowact, 1, n); memset(colact, 1, n);
    int *rowcnt = calloc(n, sizeof(int)), *colcnt = calloc(n, sizeof(int));
    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) if (a[(size_t)i * n + j]) { rowcnt[i]++; colcnt[j]++; }
    int *cnt = calloc(MM + 1, sizeof(int)); int remaining = n; int level = 0;
    int *nzc = malloc(sizeof(int) * n); int *order = malloc(sizeof(int) * n);
    long long npiv = 0;
    while (remaining > 0 && level < MM) {
        int found_any = 1;
        while (found_any && remaining > 0) {
            found_any = 0;
            int no = 0;
            for (int j = 0; j < n; j++) if (colact[j]) order[no++] = j;
            {
                int maxc = 0; for (int t = 0; t < no; t++) if (colcnt[order[t]] > maxc) maxc = colcnt[order[t]];
                int *b = calloc(maxc + 2, sizeof(int)); int *tmp = malloc(sizeof(int) * (no + 1));
                for (int t = 0; t < no; t++) b[colcnt[order[t]] + 1]++;
                for (int t = 1; t <= maxc + 1; t++) b[t] += b[t - 1];
                for (int t = 0; t < no; t++) tmp[b[colcnt[order[t]]]++] = order[t];
                memcpy(order, tmp, sizeof(int) * no); free(b); free(tmp);
            }
            for (int oi = 0; oi < no; oi++) {
                int j = order[oi]; if (!colact[j]) continue;
                int best = -1, bc = 1 << 30;
                for (int r = 0; r < n; r++) if (rowact[r]) { u128 x = a[(size_t)r * n + j]; if (x && x % P) { if (rowcnt[r] < bc) { bc = rowcnt[r]; best = r; } } }
                if (best < 0) continue;
                int i = best; found_any = 1; npiv++;
                u128 *ri = a + (size_t)i * n;
                u128 pinv = mont_inv(ri[j]);
                int nn = 0; for (int k = 0; k < n; k++) if (colact[k] && k != j && ri[k]) nzc[nn++] = k;
                for (int r = 0; r < n; r++) {
                    if (!rowact[r] || r == i) continue;
                    u128 *rr = a + (size_t)r * n;
                    if (!rr[j]) continue;
                    u128 f = mont(rr[j], pinv);
                    rr[j] = 0; rowcnt[r]--; colcnt[j]--;
                    for (int t = 0; t < nn; t++) {
                        int k = nzc[t]; u128 old = rr[k];
                        u128 nw = subm(old, mont(f, ri[k]));
                        rr[k] = nw;
                        if (!old && nw) { rowcnt[r]++; colcnt[k]++; }
                        else if (old && !nw) { rowcnt[r]--; colcnt[k]--; }
                    }
                }
                for (int k = 0; k < n; k++) if (colact[k] && ri[k]) colcnt[k]--;
                rowact[i] = 0; colact[j] = 0; remaining--; cnt[level]++;
            }
        }
        if (remaining == 0) break;
        level++;
        for (int r = 0; r < n; r++) if (rowact[r]) { u128 *rr = a + (size_t)r * n; for (int k = 0; k < n; k++) if (colact[k] && rr[k]) { u128 x = rr[k]; if (x % P) { fprintf(stderr, "BUG: non-divisible entry at level %d\n", level); return 2; } rr[k] = x / P; if (!rr[k]) { rowcnt[r]--; colcnt[k]--; } } }
        fprintf(stderr, "level %d reached, remaining %d, pivots so far %lld, %.1fs\n", level, remaining, npiv, (double)(clock() - t0) / CLOCKS_PER_SEC);
    }
    for (int v = 0; v < MM; v++) if (cnt[v]) printf("%d %d\n", v, cnt[v]);
    printf("ge_M %d\n", remaining);
    printf("time %.1f\n", (double)(clock() - t0) / CLOCKS_PER_SEC);
    (void)R3; (void)vp128;
    return 0;
}
