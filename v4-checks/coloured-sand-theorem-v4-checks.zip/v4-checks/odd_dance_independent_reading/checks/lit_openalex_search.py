# lit_openalex_search.py — OpenAlex keyword search (title+abstract+fulltext where indexed), optionally only
# dissertations; prints total and the first 40 titles.
import json, subprocess, sys, time, urllib.parse
qs = json.load(open(sys.argv[1])); tag = sys.argv[2]; extra = sys.argv[3] if len(sys.argv) > 3 else ''
for k, q in enumerate(qs, 1):
    params = {'search': q, 'per-page': 40}
    if extra: params['filter'] = extra
    url = 'https://api.openalex.org/works?' + urllib.parse.urlencode(params)
    s = subprocess.run(['curl', '-sS', '-m', '60', url], capture_output=True, text=True).stdout
    open(f'lit/{tag}_{k:02d}_oa.json', 'w').write(s)
    try:
        d = json.loads(s)
        print(f'[OpenAlex{(" " + extra) if extra else ""}] {q!r}: total {d.get("meta",{}).get("count")}')
        for r in d.get('results', [])[:40]:
            print(f'     {r.get("publication_year")} | {(r.get("display_name") or "")[:130]} | {r.get("type")} | {r.get("doi") or r["id"].split("/")[-1]}')
    except Exception:
        print(f'[OpenAlex] {q!r}: ERR {s[:200]}')
    sys.stdout.flush(); time.sleep(1.5)
