# k5.py — K5: whole Hamming groups Syl_p K(H(d,q)) from the report's closed formula (Theorem TOTAL assembled,
# checks/k4_formula.syl_hamming) against two invariants that use no lattice:
#  (I1) Kirchhoff: |K(G)| = (1/n) prod of the non-zero Laplacian eigenvalues; for H(d,q) these are q j with
#       multiplicity C(d,j)(q-1)^j (1 <= j <= d), n = q^d.  So v_p|K| = sum_j C(d,j)(q-1)^j (e + v_p(j)) - d e.
#  (I2) the number of cyclic factors of Syl_p K = dim_Fp coker(L mod p) - 1.  Justification (mod p, no lattice):
#       K_q = qI - J = -J (mod p) with J the all-ones matrix, J^2 = qJ = 0; over F_p, F_p^q = (2-dim Jordan block
#       of J) + (q-2) one-dim zero blocks.  L = sum_i K_q^(i) = -sum_i J_i on (F_p^q)^{(x)d}, so
#       (F_p^q)^{(x)d} = sum_j C(d,j)(q-2)^j  V^{(x)(d-j)} (x) (trivial), with -sum J_i acting as -U = -sum e_i on
#       V^{(x)m}, U the up operator of B_m (m = d-j).  Hence
#       dim coker(L mod p) = sum_j C(d,j)(q-2)^j (2^m - rank_Fp(U on B_m)),  rank(U on B_m) = sum_s rank W_{s,s+1}.
#       rank_Fp W_{s,s+1} is computed (a) directly, by FLINT nmod_mat rank of the 0/1 inclusion matrix, for m <= 15,
#       and (b) by Wilson's diagonal form [Wil90, Thm 2] for t <= min(k, m-k): rank = sum over 0<=i<=t with
#       p not dividing C(k-i, t-i) of (C(m,i) - C(m,i-1)) (with (t,k) = (s, s+1) or, by complementation,
#       (m-1-s, m-s)); (a) and (b) are compared wherever both are computed.
# Control: the formula with e+1 instead of e must contradict (I1).
import sys, itertools, time
from math import comb
from collections import Counter
import flint
from k4_formula import syl_hamming, vp, Y_total

def rank_W_direct(m, s, p):
    rows = list(itertools.combinations(range(m), s + 1)); cols = list(itertools.combinations(range(m), s))
    if not rows or not cols:
        return 0
    cidx = {c: j for j, c in enumerate(cols)}
    A = flint.nmod_mat(len(rows), len(cols), p)
    for i, r in enumerate(rows):
        for x in range(s + 1):
            A[i, cidx[r[:x] + r[x + 1:]]] = 1
    return A.rank()

def rank_W_wilson(m, s, p):
    if 2 * s <= m - 1:
        t, k = s, s + 1
    else:
        t, k = m - 1 - s, m - s
    return sum(comb(m, i) - (comb(m, i - 1) if i >= 1 else 0) for i in range(t + 1) if comb(k - i, t - i) % p)

def corank_U(m, p, direct):
    rw = sum(rank_W_wilson(m, s, p) for s in range(m))
    if direct:
        rd = sum(rank_W_direct(m, s, p) for s in range(m))
        if rd != rw:
            raise RuntimeError(f'Wilson rank {rw} != direct rank {rd} for m={m}, p={p}')
    return 2 ** m - rw

def invariants(d, q, p, direct_max):
    e = vp(q, p)
    length = sum(comb(d, j) * (q - 1) ** j * (e + vp(j, p)) for j in range(1, d + 1)) - d * e
    cok = sum(comb(d, j) * (q - 2) ** j * corank_U(d - j, p, (d - j) <= direct_max) for j in range(d + 1) if comb(d, j) * (q - 2) ** j)
    return length, cok - 1

if __name__ == '__main__':
    t0 = time.time()
    cells = [(3, 12, 3), (3, 13, 3), (3, 14, 6), (3, 15, 9), (3, 16, 3), (3, 20, 3), (3, 24, 27), (5, 30, 5),
             (5, 31, 10), (5, 35, 25), (7, 56, 7), (7, 60, 14)]
    direct_max = int(sys.argv[1]) if len(sys.argv) > 1 else 15
    bad = 0
    for (p, d, q) in cells:
        G, free = syl_hamming(d, q, p)
        flen = sum(a * c for a, c in G.items()); fnum = sum(G.values())
        ilen, inum = invariants(d, q, p, direct_max)
        e = vp(q, p)
        # control: the closed formula with e+1 instead of e (q replaced by q*p keeps p | q and raises e by one)
        Gc, _ = syl_hamming(d, q, p, e_override=e + 1)
        clen = sum(a * c for a, c in Gc.items())
        ok = (flen == ilen and fnum == inum and free == 1)
        bad += not ok
        print(f'p={p} d={d} q={q} (e={e}): formula length {flen} vs Kirchhoff {ilen} | cyclic factors {fnum} vs rank count {inum} | '
              f'free {free} | {"AGREE" if ok else "DISAGREE"} | control (formula with e+1): length {clen} {"!= Kirchhoff (fires)" if clen != ilen else "== Kirchhoff (DOES NOT FIRE)"}  [{time.time()-t0:.1f}s]')
        sys.stdout.flush()
    print(f'K5: {len(cells)} cells, {bad} disagreements')
